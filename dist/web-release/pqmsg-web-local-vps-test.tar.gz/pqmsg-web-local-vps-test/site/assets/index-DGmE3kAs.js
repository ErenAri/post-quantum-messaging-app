var _d=Object.defineProperty;var wd=(e,t,s)=>t in e?_d(e,t,{enumerable:!0,configurable:!0,writable:!0,value:s}):e[t]=s;var bt=(e,t,s)=>wd(e,typeof t!="symbol"?t+"":t,s);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const a of r)if(a.type==="childList")for(const i of a.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&n(i)}).observe(document,{childList:!0,subtree:!0});function s(r){const a={};return r.integrity&&(a.integrity=r.integrity),r.referrerPolicy&&(a.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?a.credentials="include":r.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(r){if(r.ep)return;r.ep=!0;const a=s(r);fetch(r.href,a)}})();const Us=typeof globalThis=="object"&&"crypto"in globalThis?globalThis.crypto:void 0;/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */function jn(e){return e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name==="Uint8Array"}function kd(e){if(!Number.isSafeInteger(e)||e<0)throw new Error("positive integer expected, got "+e)}function Bt(e,...t){if(!jn(e))throw new Error("Uint8Array expected");if(t.length>0&&!t.includes(e.length))throw new Error("Uint8Array expected of length "+t+", got length="+e.length)}function bi(e,t=!0){if(e.destroyed)throw new Error("Hash instance has been destroyed");if(t&&e.finished)throw new Error("Hash#digest() has already been called")}function xd(e,t){Bt(e);const s=t.outputLen;if(e.length<s)throw new Error("digestInto() expects output buffer of length at least "+s)}function Bn(...e){for(let t=0;t<e.length;t++)e[t].fill(0)}function sa(e){return new DataView(e.buffer,e.byteOffset,e.byteLength)}function It(e,t){return e<<32-t|e>>>t}const io=typeof Uint8Array.from([]).toHex=="function"&&typeof Uint8Array.fromHex=="function",Sd=Array.from({length:256},(e,t)=>t.toString(16).padStart(2,"0"));function qr(e){if(Bt(e),io)return e.toHex();let t="";for(let s=0;s<e.length;s++)t+=Sd[e[s]];return t}const Dt={_0:48,_9:57,A:65,F:70,a:97,f:102};function _i(e){if(e>=Dt._0&&e<=Dt._9)return e-Dt._0;if(e>=Dt.A&&e<=Dt.F)return e-(Dt.A-10);if(e>=Dt.a&&e<=Dt.f)return e-(Dt.a-10)}function oo(e){if(typeof e!="string")throw new Error("hex string expected, got "+typeof e);if(io)return Uint8Array.fromHex(e);const t=e.length,s=t/2;if(t%2)throw new Error("hex string expected, got unpadded hex of length "+t);const n=new Uint8Array(s);for(let r=0,a=0;r<s;r++,a+=2){const i=_i(e.charCodeAt(a)),o=_i(e.charCodeAt(a+1));if(i===void 0||o===void 0){const c=e[a]+e[a+1];throw new Error('hex string expected, got non-hex character "'+c+'" at index '+a)}n[r]=i*16+o}return n}function Dr(e){if(typeof e!="string")throw new Error("string expected");return new Uint8Array(new TextEncoder().encode(e))}function co(e){return typeof e=="string"&&(e=Dr(e)),Bt(e),e}function ss(...e){let t=0;for(let n=0;n<e.length;n++){const r=e[n];Bt(r),t+=r.length}const s=new Uint8Array(t);for(let n=0,r=0;n<e.length;n++){const a=e[n];s.set(a,r),r+=a.length}return s}class Id{}function lo(e){const t=n=>e().update(co(n)).digest(),s=e();return t.outputLen=s.outputLen,t.blockLen=s.blockLen,t.create=()=>e(),t}function uo(e=32){if(Us&&typeof Us.getRandomValues=="function")return Us.getRandomValues(new Uint8Array(e));if(Us&&typeof Us.randomBytes=="function")return Uint8Array.from(Us.randomBytes(e));throw new Error("crypto.getRandomValues must be defined")}function Ed(e,t,s,n){if(typeof e.setBigUint64=="function")return e.setBigUint64(t,s,n);const r=BigInt(32),a=BigInt(4294967295),i=Number(s>>r&a),o=Number(s&a),c=n?4:0,d=n?0:4;e.setUint32(t+c,i,n),e.setUint32(t+d,o,n)}function Cd(e,t,s){return e&t^~e&s}function Ad(e,t,s){return e&t^e&s^t&s}class po extends Id{constructor(t,s,n,r){super(),this.finished=!1,this.length=0,this.pos=0,this.destroyed=!1,this.blockLen=t,this.outputLen=s,this.padOffset=n,this.isLE=r,this.buffer=new Uint8Array(t),this.view=sa(this.buffer)}update(t){bi(this),t=co(t),Bt(t);const{view:s,buffer:n,blockLen:r}=this,a=t.length;for(let i=0;i<a;){const o=Math.min(r-this.pos,a-i);if(o===r){const c=sa(t);for(;r<=a-i;i+=r)this.process(c,i);continue}n.set(t.subarray(i,i+o),this.pos),this.pos+=o,i+=o,this.pos===r&&(this.process(s,0),this.pos=0)}return this.length+=t.length,this.roundClean(),this}digestInto(t){bi(this),xd(t,this),this.finished=!0;const{buffer:s,view:n,blockLen:r,isLE:a}=this;let{pos:i}=this;s[i++]=128,Bn(this.buffer.subarray(i)),this.padOffset>r-i&&(this.process(n,0),i=0);for(let h=i;h<r;h++)s[h]=0;Ed(n,r-8,BigInt(this.length*8),a),this.process(n,0);const o=sa(t),c=this.outputLen;if(c%4)throw new Error("_sha2: outputLen should be aligned to 32bit");const d=c/4,l=this.get();if(d>l.length)throw new Error("_sha2: outputLen bigger than state");for(let h=0;h<d;h++)o.setUint32(4*h,l[h],a)}digest(){const{buffer:t,outputLen:s}=this;this.digestInto(t);const n=t.slice(0,s);return this.destroy(),n}_cloneInto(t){t||(t=new this.constructor),t.set(...this.get());const{blockLen:s,buffer:n,length:r,finished:a,destroyed:i,pos:o}=this;return t.destroyed=i,t.finished=a,t.length=r,t.pos=o,r%s&&t.buffer.set(n),t}clone(){return this._cloneInto()}}const Xt=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),qe=Uint32Array.from([1779033703,4089235720,3144134277,2227873595,1013904242,4271175723,2773480762,1595750129,1359893119,2917565137,2600822924,725511199,528734635,4215389547,1541459225,327033209]),cr=BigInt(2**32-1),wi=BigInt(32);function $d(e,t=!1){return t?{h:Number(e&cr),l:Number(e>>wi&cr)}:{h:Number(e>>wi&cr)|0,l:Number(e&cr)|0}}function Td(e,t=!1){const s=e.length;let n=new Uint32Array(s),r=new Uint32Array(s);for(let a=0;a<s;a++){const{h:i,l:o}=$d(e[a],t);[n[a],r[a]]=[i,o]}return[n,r]}const ki=(e,t,s)=>e>>>s,xi=(e,t,s)=>e<<32-s|t>>>s,qs=(e,t,s)=>e>>>s|t<<32-s,Ds=(e,t,s)=>e<<32-s|t>>>s,dr=(e,t,s)=>e<<64-s|t>>>s-32,lr=(e,t,s)=>e>>>s-32|t<<64-s;function Rt(e,t,s,n){const r=(t>>>0)+(n>>>0);return{h:e+s+(r/2**32|0)|0,l:r|0}}const Ld=(e,t,s)=>(e>>>0)+(t>>>0)+(s>>>0),Pd=(e,t,s,n)=>t+s+n+(e/2**32|0)|0,Md=(e,t,s,n)=>(e>>>0)+(t>>>0)+(s>>>0)+(n>>>0),Bd=(e,t,s,n,r)=>t+s+n+r+(e/2**32|0)|0,Ud=(e,t,s,n,r)=>(e>>>0)+(t>>>0)+(s>>>0)+(n>>>0)+(r>>>0),qd=(e,t,s,n,r,a)=>t+s+n+r+a+(e/2**32|0)|0,Dd=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),Zt=new Uint32Array(64);class Rd extends po{constructor(t=32){super(64,t,8,!1),this.A=Xt[0]|0,this.B=Xt[1]|0,this.C=Xt[2]|0,this.D=Xt[3]|0,this.E=Xt[4]|0,this.F=Xt[5]|0,this.G=Xt[6]|0,this.H=Xt[7]|0}get(){const{A:t,B:s,C:n,D:r,E:a,F:i,G:o,H:c}=this;return[t,s,n,r,a,i,o,c]}set(t,s,n,r,a,i,o,c){this.A=t|0,this.B=s|0,this.C=n|0,this.D=r|0,this.E=a|0,this.F=i|0,this.G=o|0,this.H=c|0}process(t,s){for(let h=0;h<16;h++,s+=4)Zt[h]=t.getUint32(s,!1);for(let h=16;h<64;h++){const u=Zt[h-15],f=Zt[h-2],m=It(u,7)^It(u,18)^u>>>3,w=It(f,17)^It(f,19)^f>>>10;Zt[h]=w+Zt[h-7]+m+Zt[h-16]|0}let{A:n,B:r,C:a,D:i,E:o,F:c,G:d,H:l}=this;for(let h=0;h<64;h++){const u=It(o,6)^It(o,11)^It(o,25),f=l+u+Cd(o,c,d)+Dd[h]+Zt[h]|0,w=(It(n,2)^It(n,13)^It(n,22))+Ad(n,r,a)|0;l=d,d=c,c=o,o=i+f|0,i=a,a=r,r=n,n=f+w|0}n=n+this.A|0,r=r+this.B|0,a=a+this.C|0,i=i+this.D|0,o=o+this.E|0,c=c+this.F|0,d=d+this.G|0,l=l+this.H|0,this.set(n,r,a,i,o,c,d,l)}roundClean(){Bn(Zt)}destroy(){this.set(0,0,0,0,0,0,0,0),Bn(this.buffer)}}const ho=Td(["0x428a2f98d728ae22","0x7137449123ef65cd","0xb5c0fbcfec4d3b2f","0xe9b5dba58189dbbc","0x3956c25bf348b538","0x59f111f1b605d019","0x923f82a4af194f9b","0xab1c5ed5da6d8118","0xd807aa98a3030242","0x12835b0145706fbe","0x243185be4ee4b28c","0x550c7dc3d5ffb4e2","0x72be5d74f27b896f","0x80deb1fe3b1696b1","0x9bdc06a725c71235","0xc19bf174cf692694","0xe49b69c19ef14ad2","0xefbe4786384f25e3","0x0fc19dc68b8cd5b5","0x240ca1cc77ac9c65","0x2de92c6f592b0275","0x4a7484aa6ea6e483","0x5cb0a9dcbd41fbd4","0x76f988da831153b5","0x983e5152ee66dfab","0xa831c66d2db43210","0xb00327c898fb213f","0xbf597fc7beef0ee4","0xc6e00bf33da88fc2","0xd5a79147930aa725","0x06ca6351e003826f","0x142929670a0e6e70","0x27b70a8546d22ffc","0x2e1b21385c26c926","0x4d2c6dfc5ac42aed","0x53380d139d95b3df","0x650a73548baf63de","0x766a0abb3c77b2a8","0x81c2c92e47edaee6","0x92722c851482353b","0xa2bfe8a14cf10364","0xa81a664bbc423001","0xc24b8b70d0f89791","0xc76c51a30654be30","0xd192e819d6ef5218","0xd69906245565a910","0xf40e35855771202a","0x106aa07032bbd1b8","0x19a4c116b8d2d0c8","0x1e376c085141ab53","0x2748774cdf8eeb99","0x34b0bcb5e19b48a8","0x391c0cb3c5c95a63","0x4ed8aa4ae3418acb","0x5b9cca4f7763e373","0x682e6ff3d6b2b8a3","0x748f82ee5defb2fc","0x78a5636f43172f60","0x84c87814a1f0ab72","0x8cc702081a6439ec","0x90befffa23631e28","0xa4506cebde82bde9","0xbef9a3f7b2c67915","0xc67178f2e372532b","0xca273eceea26619c","0xd186b8c721c0c207","0xeada7dd6cde0eb1e","0xf57d4f7fee6ed178","0x06f067aa72176fba","0x0a637dc5a2c898a6","0x113f9804bef90dae","0x1b710b35131c471b","0x28db77f523047d84","0x32caab7b40c72493","0x3c9ebe0a15c9bebc","0x431d67c49c100d4c","0x4cc5d4becb3e42b6","0x597f299cfc657e2a","0x5fcb6fab3ad6faec","0x6c44198c4a475817"].map(e=>BigInt(e))),Nd=ho[0],Hd=ho[1],Qt=new Uint32Array(80),es=new Uint32Array(80);class Od extends po{constructor(t=64){super(128,t,16,!1),this.Ah=qe[0]|0,this.Al=qe[1]|0,this.Bh=qe[2]|0,this.Bl=qe[3]|0,this.Ch=qe[4]|0,this.Cl=qe[5]|0,this.Dh=qe[6]|0,this.Dl=qe[7]|0,this.Eh=qe[8]|0,this.El=qe[9]|0,this.Fh=qe[10]|0,this.Fl=qe[11]|0,this.Gh=qe[12]|0,this.Gl=qe[13]|0,this.Hh=qe[14]|0,this.Hl=qe[15]|0}get(){const{Ah:t,Al:s,Bh:n,Bl:r,Ch:a,Cl:i,Dh:o,Dl:c,Eh:d,El:l,Fh:h,Fl:u,Gh:f,Gl:m,Hh:w,Hl:x}=this;return[t,s,n,r,a,i,o,c,d,l,h,u,f,m,w,x]}set(t,s,n,r,a,i,o,c,d,l,h,u,f,m,w,x){this.Ah=t|0,this.Al=s|0,this.Bh=n|0,this.Bl=r|0,this.Ch=a|0,this.Cl=i|0,this.Dh=o|0,this.Dl=c|0,this.Eh=d|0,this.El=l|0,this.Fh=h|0,this.Fl=u|0,this.Gh=f|0,this.Gl=m|0,this.Hh=w|0,this.Hl=x|0}process(t,s){for(let k=0;k<16;k++,s+=4)Qt[k]=t.getUint32(s),es[k]=t.getUint32(s+=4);for(let k=16;k<80;k++){const I=Qt[k-15]|0,L=es[k-15]|0,B=qs(I,L,1)^qs(I,L,8)^ki(I,L,7),$=Ds(I,L,1)^Ds(I,L,8)^xi(I,L,7),U=Qt[k-2]|0,A=es[k-2]|0,E=qs(U,A,19)^dr(U,A,61)^ki(U,A,6),G=Ds(U,A,19)^lr(U,A,61)^xi(U,A,6),N=Md($,G,es[k-7],es[k-16]),M=Bd(N,B,E,Qt[k-7],Qt[k-16]);Qt[k]=M|0,es[k]=N|0}let{Ah:n,Al:r,Bh:a,Bl:i,Ch:o,Cl:c,Dh:d,Dl:l,Eh:h,El:u,Fh:f,Fl:m,Gh:w,Gl:x,Hh:_,Hl:y}=this;for(let k=0;k<80;k++){const I=qs(h,u,14)^qs(h,u,18)^dr(h,u,41),L=Ds(h,u,14)^Ds(h,u,18)^lr(h,u,41),B=h&f^~h&w,$=u&m^~u&x,U=Ud(y,L,$,Hd[k],es[k]),A=qd(U,_,I,B,Nd[k],Qt[k]),E=U|0,G=qs(n,r,28)^dr(n,r,34)^dr(n,r,39),N=Ds(n,r,28)^lr(n,r,34)^lr(n,r,39),M=n&a^n&o^a&o,O=r&i^r&c^i&c;_=w|0,y=x|0,w=f|0,x=m|0,f=h|0,m=u|0,{h,l:u}=Rt(d|0,l|0,A|0,E|0),d=o|0,l=c|0,o=a|0,c=i|0,a=n|0,i=r|0;const Z=Ld(E,N,O);n=Pd(Z,A,G,M),r=Z|0}({h:n,l:r}=Rt(this.Ah|0,this.Al|0,n|0,r|0)),{h:a,l:i}=Rt(this.Bh|0,this.Bl|0,a|0,i|0),{h:o,l:c}=Rt(this.Ch|0,this.Cl|0,o|0,c|0),{h:d,l}=Rt(this.Dh|0,this.Dl|0,d|0,l|0),{h,l:u}=Rt(this.Eh|0,this.El|0,h|0,u|0),{h:f,l:m}=Rt(this.Fh|0,this.Fl|0,f|0,m|0),{h:w,l:x}=Rt(this.Gh|0,this.Gl|0,w|0,x|0),{h:_,l:y}=Rt(this.Hh|0,this.Hl|0,_|0,y|0),this.set(n,r,a,i,o,c,d,l,h,u,f,m,w,x,_,y)}roundClean(){Bn(Qt,es)}destroy(){Bn(this.buffer),this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)}}const ce=lo(()=>new Rd),yr=lo(()=>new Od);/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const Da=BigInt(0),fa=BigInt(1);function ma(e,t=""){if(typeof e!="boolean"){const s=t&&`"${t}"`;throw new Error(s+"expected boolean, got type="+typeof e)}return e}function fr(e,t,s=""){const n=jn(e),r=e==null?void 0:e.length,a=t!==void 0;if(!n||a&&r!==t){const i=s&&`"${s}" `,o=a?` of length ${t}`:"",c=n?`length=${r}`:`type=${typeof e}`;throw new Error(i+"expected Uint8Array"+o+", got "+c)}return e}function vo(e){if(typeof e!="string")throw new Error("hex string expected, got "+typeof e);return e===""?Da:BigInt("0x"+e)}function Gd(e){return vo(qr(e))}function ps(e){return Bt(e),vo(qr(Uint8Array.from(e).reverse()))}function fo(e,t){return oo(e.toString(16).padStart(t*2,"0"))}function mo(e,t){return fo(e,t).reverse()}function ut(e,t,s){let n;if(typeof t=="string")try{n=oo(t)}catch(a){throw new Error(e+" must be hex string or Uint8Array, cause: "+a)}else if(jn(t))n=Uint8Array.from(t);else throw new Error(e+" must be hex string or Uint8Array");const r=n.length;if(typeof s=="number"&&r!==s)throw new Error(e+" of length "+s+" expected, got "+r);return n}function jd(e,t){if(e.length!==t.length)return!1;let s=0;for(let n=0;n<e.length;n++)s|=e[n]^t[n];return s===0}function Si(e){return Uint8Array.from(e)}const na=e=>typeof e=="bigint"&&Da<=e;function Wd(e,t,s){return na(e)&&na(t)&&na(s)&&t<=e&&e<s}function br(e,t,s,n){if(!Wd(t,s,n))throw new Error("expected valid "+e+": "+s+" <= n < "+n+", got "+t)}function Kd(e){let t;for(t=0;e>Da;e>>=fa,t+=1);return t}const Ra=e=>(fa<<BigInt(e))-fa;function Rr(e,t,s={}){if(!e||typeof e!="object")throw new Error("expected valid options object");function n(r,a,i){const o=e[r];if(i&&o===void 0)return;const c=typeof o;if(c!==a||o===null)throw new Error(`param "${r}" is invalid: expected ${a}, got ${c}`)}Object.entries(t).forEach(([r,a])=>n(r,a,!1)),Object.entries(s).forEach(([r,a])=>n(r,a,!0))}const Ii=()=>{throw new Error("not implemented")};function Ei(e){const t=new WeakMap;return(s,...n)=>{const r=t.get(s);if(r!==void 0)return r;const a=e(s,...n);return t.set(s,a),a}}/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const et=BigInt(0),Ye=BigInt(1),bs=BigInt(2),go=BigInt(3),yo=BigInt(4),bo=BigInt(5),Fd=BigInt(7),_o=BigInt(8),Vd=BigInt(9),wo=BigInt(16);function fe(e,t){const s=e%t;return s>=et?s:t+s}function _t(e,t,s){let n=e;for(;t-- >et;)n*=n,n%=s;return n}function Ci(e,t){if(e===et)throw new Error("invert: expected non-zero number");if(t<=et)throw new Error("invert: expected positive modulus, got "+t);let s=fe(e,t),n=t,r=et,a=Ye;for(;s!==et;){const o=n/s,c=n%s,d=r-a*o;n=s,s=c,r=a,a=d}if(n!==Ye)throw new Error("invert: does not exist");return fe(r,t)}function Na(e,t,s){if(!e.eql(e.sqr(t),s))throw new Error("Cannot find square root")}function ko(e,t){const s=(e.ORDER+Ye)/yo,n=e.pow(t,s);return Na(e,n,t),n}function zd(e,t){const s=(e.ORDER-bo)/_o,n=e.mul(t,bs),r=e.pow(n,s),a=e.mul(t,r),i=e.mul(e.mul(a,bs),r),o=e.mul(a,e.sub(i,e.ONE));return Na(e,o,t),o}function Yd(e){const t=an(e),s=xo(e),n=s(t,t.neg(t.ONE)),r=s(t,n),a=s(t,t.neg(n)),i=(e+Fd)/wo;return(o,c)=>{let d=o.pow(c,i),l=o.mul(d,n);const h=o.mul(d,r),u=o.mul(d,a),f=o.eql(o.sqr(l),c),m=o.eql(o.sqr(h),c);d=o.cmov(d,l,f),l=o.cmov(u,h,m);const w=o.eql(o.sqr(l),c),x=o.cmov(d,l,w);return Na(o,x,c),x}}function xo(e){if(e<go)throw new Error("sqrt is not defined for small field");let t=e-Ye,s=0;for(;t%bs===et;)t/=bs,s++;let n=bs;const r=an(e);for(;Ai(r,n)===1;)if(n++>1e3)throw new Error("Cannot find square root: probably non-prime P");if(s===1)return ko;let a=r.pow(n,t);const i=(t+Ye)/bs;return function(c,d){if(c.is0(d))return d;if(Ai(c,d)!==1)throw new Error("Cannot find square root");let l=s,h=c.mul(c.ONE,a),u=c.pow(d,t),f=c.pow(d,i);for(;!c.eql(u,c.ONE);){if(c.is0(u))return c.ZERO;let m=1,w=c.sqr(u);for(;!c.eql(w,c.ONE);)if(m++,w=c.sqr(w),m===l)throw new Error("Cannot find square root");const x=Ye<<BigInt(l-m-1),_=c.pow(h,x);l=m,h=c.sqr(_),u=c.mul(u,h),f=c.mul(f,_)}return f}}function Jd(e){return e%yo===go?ko:e%_o===bo?zd:e%wo===Vd?Yd(e):xo(e)}const ns=(e,t)=>(fe(e,t)&Ye)===Ye,Xd=["create","isValid","is0","neg","inv","sqrt","sqr","eql","add","sub","mul","pow","div","addN","subN","mulN","sqrN"];function Zd(e){const t={ORDER:"bigint",MASK:"bigint",BYTES:"number",BITS:"number"},s=Xd.reduce((n,r)=>(n[r]="function",n),t);return Rr(e,s),e}function Qd(e,t,s){if(s<et)throw new Error("invalid exponent, negatives unsupported");if(s===et)return e.ONE;if(s===Ye)return t;let n=e.ONE,r=t;for(;s>et;)s&Ye&&(n=e.mul(n,r)),r=e.sqr(r),s>>=Ye;return n}function So(e,t,s=!1){const n=new Array(t.length).fill(s?e.ZERO:void 0),r=t.reduce((i,o,c)=>e.is0(o)?i:(n[c]=i,e.mul(i,o)),e.ONE),a=e.inv(r);return t.reduceRight((i,o,c)=>e.is0(o)?i:(n[c]=e.mul(i,n[c]),e.mul(i,o)),a),n}function Ai(e,t){const s=(e.ORDER-Ye)/bs,n=e.pow(t,s),r=e.eql(n,e.ONE),a=e.eql(n,e.ZERO),i=e.eql(n,e.neg(e.ONE));if(!r&&!a&&!i)throw new Error("invalid Legendre symbol result");return r?1:a?0:-1}function el(e,t){t!==void 0&&kd(t);const s=t!==void 0?t:e.toString(2).length,n=Math.ceil(s/8);return{nBitLength:s,nByteLength:n}}function an(e,t,s=!1,n={}){if(e<=et)throw new Error("invalid field: expected ORDER > 0, got "+e);let r,a,i=!1,o;if(typeof t=="object"&&t!=null){if(n.sqrt||s)throw new Error("cannot specify opts in two arguments");const u=t;u.BITS&&(r=u.BITS),u.sqrt&&(a=u.sqrt),typeof u.isLE=="boolean"&&(s=u.isLE),typeof u.modFromBytes=="boolean"&&(i=u.modFromBytes),o=u.allowedLengths}else typeof t=="number"&&(r=t),n.sqrt&&(a=n.sqrt);const{nBitLength:c,nByteLength:d}=el(e,r);if(d>2048)throw new Error("invalid field: expected ORDER of <= 2048 bytes");let l;const h=Object.freeze({ORDER:e,isLE:s,BITS:c,BYTES:d,MASK:Ra(c),ZERO:et,ONE:Ye,allowedLengths:o,create:u=>fe(u,e),isValid:u=>{if(typeof u!="bigint")throw new Error("invalid field element: expected bigint, got "+typeof u);return et<=u&&u<e},is0:u=>u===et,isValidNot0:u=>!h.is0(u)&&h.isValid(u),isOdd:u=>(u&Ye)===Ye,neg:u=>fe(-u,e),eql:(u,f)=>u===f,sqr:u=>fe(u*u,e),add:(u,f)=>fe(u+f,e),sub:(u,f)=>fe(u-f,e),mul:(u,f)=>fe(u*f,e),pow:(u,f)=>Qd(h,u,f),div:(u,f)=>fe(u*Ci(f,e),e),sqrN:u=>u*u,addN:(u,f)=>u+f,subN:(u,f)=>u-f,mulN:(u,f)=>u*f,inv:u=>Ci(u,e),sqrt:a||(u=>(l||(l=Jd(e)),l(h,u))),toBytes:u=>s?mo(u,d):fo(u,d),fromBytes:(u,f=!0)=>{if(o){if(!o.includes(u.length)||u.length>d)throw new Error("Field.fromBytes: expected "+o+" bytes, got "+u.length);const w=new Uint8Array(d);w.set(u,s?0:w.length-u.length),u=w}if(u.length!==d)throw new Error("Field.fromBytes: expected "+d+" bytes, got "+u.length);let m=s?ps(u):Gd(u);if(i&&(m=fe(m,e)),!f&&!h.isValid(m))throw new Error("invalid field element: outside of range 0..ORDER");return m},invertBatch:u=>So(h,u),cmov:(u,f,m)=>m?f:u});return Object.freeze(h)}/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const _r=BigInt(0),ga=BigInt(1);function $i(e,t){const s=t.negate();return e?s:t}function ur(e,t){const s=So(e.Fp,t.map(n=>n.Z));return t.map((n,r)=>e.fromAffine(n.toAffine(s[r])))}function Io(e,t){if(!Number.isSafeInteger(e)||e<=0||e>t)throw new Error("invalid window size, expected [1.."+t+"], got W="+e)}function ra(e,t){Io(e,t);const s=Math.ceil(t/e)+1,n=2**(e-1),r=2**e,a=Ra(e),i=BigInt(e);return{windows:s,windowSize:n,mask:a,maxNumber:r,shiftBy:i}}function Ti(e,t,s){const{windowSize:n,mask:r,maxNumber:a,shiftBy:i}=s;let o=Number(e&r),c=e>>i;o>n&&(o-=a,c+=ga);const d=t*n,l=d+Math.abs(o)-1,h=o===0,u=o<0,f=t%2!==0;return{nextN:c,offset:l,isZero:h,isNeg:u,isNegF:f,offsetF:d}}function tl(e,t){if(!Array.isArray(e))throw new Error("array expected");e.forEach((s,n)=>{if(!(s instanceof t))throw new Error("invalid point at index "+n)})}function sl(e,t){if(!Array.isArray(e))throw new Error("array of scalars expected");e.forEach((s,n)=>{if(!t.isValid(s))throw new Error("invalid scalar at index "+n)})}const aa=new WeakMap,Eo=new WeakMap;function ia(e){return Eo.get(e)||1}function Li(e){if(e!==_r)throw new Error("invalid wNAF")}class nl{constructor(t,s){this.BASE=t.BASE,this.ZERO=t.ZERO,this.Fn=t.Fn,this.bits=s}_unsafeLadder(t,s,n=this.ZERO){let r=t;for(;s>_r;)s&ga&&(n=n.add(r)),r=r.double(),s>>=ga;return n}precomputeWindow(t,s){const{windows:n,windowSize:r}=ra(s,this.bits),a=[];let i=t,o=i;for(let c=0;c<n;c++){o=i,a.push(o);for(let d=1;d<r;d++)o=o.add(i),a.push(o);i=o.double()}return a}wNAF(t,s,n){if(!this.Fn.isValid(n))throw new Error("invalid scalar");let r=this.ZERO,a=this.BASE;const i=ra(t,this.bits);for(let o=0;o<i.windows;o++){const{nextN:c,offset:d,isZero:l,isNeg:h,isNegF:u,offsetF:f}=Ti(n,o,i);n=c,l?a=a.add($i(u,s[f])):r=r.add($i(h,s[d]))}return Li(n),{p:r,f:a}}wNAFUnsafe(t,s,n,r=this.ZERO){const a=ra(t,this.bits);for(let i=0;i<a.windows&&n!==_r;i++){const{nextN:o,offset:c,isZero:d,isNeg:l}=Ti(n,i,a);if(n=o,!d){const h=s[c];r=r.add(l?h.negate():h)}}return Li(n),r}getPrecomputes(t,s,n){let r=aa.get(s);return r||(r=this.precomputeWindow(s,t),t!==1&&(typeof n=="function"&&(r=n(r)),aa.set(s,r))),r}cached(t,s,n){const r=ia(t);return this.wNAF(r,this.getPrecomputes(r,t,n),s)}unsafe(t,s,n,r){const a=ia(t);return a===1?this._unsafeLadder(t,s,r):this.wNAFUnsafe(a,this.getPrecomputes(a,t,n),s,r)}createCache(t,s){Io(s,this.bits),Eo.set(t,s),aa.delete(t)}hasCache(t){return ia(t)!==1}}function Co(e,t,s,n){tl(s,e),sl(n,t);const r=s.length,a=n.length;if(r!==a)throw new Error("arrays of points and scalars must have equal length");const i=e.ZERO,o=Kd(BigInt(r));let c=1;o>12?c=o-3:o>4?c=o-2:o>0&&(c=2);const d=Ra(c),l=new Array(Number(d)+1).fill(i),h=Math.floor((t.BITS-1)/c)*c;let u=i;for(let f=h;f>=0;f-=c){l.fill(i);for(let w=0;w<a;w++){const x=n[w],_=Number(x>>BigInt(f)&d);l[_]=l[_].add(s[w])}let m=i;for(let w=l.length-1,x=i;w>0;w--)x=x.add(l[w]),m=m.add(x);if(u=u.add(m),f!==0)for(let w=0;w<c;w++)u=u.double()}return u}function Pi(e,t,s){if(t){if(t.ORDER!==e)throw new Error("Field.ORDER must match order: Fp == p, Fn == n");return Zd(t),t}else return an(e,{isLE:s})}function rl(e,t,s={},n){if(n===void 0&&(n=e==="edwards"),!t||typeof t!="object")throw new Error(`expected valid ${e} CURVE object`);for(const c of["p","n","h"]){const d=t[c];if(!(typeof d=="bigint"&&d>_r))throw new Error(`CURVE.${c} must be positive bigint`)}const r=Pi(t.p,s.Fp,n),a=Pi(t.n,s.Fn,n),o=["Gx","Gy","a","d"];for(const c of o)if(!r.isValid(t[c]))throw new Error(`CURVE.${c} must be valid field element of CURVE.Fp`);return t=Object.freeze(Object.assign({},t)),{CURVE:t,Fp:r,Fn:a}}/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const ts=BigInt(0),Ie=BigInt(1),oa=BigInt(2),al=BigInt(8);function il(e,t,s,n){const r=e.sqr(s),a=e.sqr(n),i=e.add(e.mul(t.a,r),a),o=e.add(e.ONE,e.mul(t.d,e.mul(r,a)));return e.eql(i,o)}function ol(e,t={}){const s=rl("edwards",e,t,t.FpFnLE),{Fp:n,Fn:r}=s;let a=s.CURVE;const{h:i}=a;Rr(t,{},{uvRatio:"function"});const o=oa<<BigInt(r.BYTES*8)-Ie,c=x=>n.create(x),d=t.uvRatio||((x,_)=>{try{return{isValid:!0,value:n.sqrt(n.div(x,_))}}catch{return{isValid:!1,value:ts}}});if(!il(n,a,a.Gx,a.Gy))throw new Error("bad curve params: generator point");function l(x,_,y=!1){const k=y?Ie:ts;return br("coordinate "+x,_,k,o),_}function h(x){if(!(x instanceof m))throw new Error("ExtendedPoint expected")}const u=Ei((x,_)=>{const{X:y,Y:k,Z:I}=x,L=x.is0();_==null&&(_=L?al:n.inv(I));const B=c(y*_),$=c(k*_),U=n.mul(I,_);if(L)return{x:ts,y:Ie};if(U!==Ie)throw new Error("invZ was invalid");return{x:B,y:$}}),f=Ei(x=>{const{a:_,d:y}=a;if(x.is0())throw new Error("bad point: ZERO");const{X:k,Y:I,Z:L,T:B}=x,$=c(k*k),U=c(I*I),A=c(L*L),E=c(A*A),G=c($*_),N=c(A*c(G+U)),M=c(E+c(y*c($*U)));if(N!==M)throw new Error("bad point: equation left != right (1)");const O=c(k*I),Z=c(L*B);if(O!==Z)throw new Error("bad point: equation left != right (2)");return!0});class m{constructor(_,y,k,I){this.X=l("x",_),this.Y=l("y",y),this.Z=l("z",k,!0),this.T=l("t",I),Object.freeze(this)}static CURVE(){return a}static fromAffine(_){if(_ instanceof m)throw new Error("extended point not allowed");const{x:y,y:k}=_||{};return l("x",y),l("y",k),new m(y,k,Ie,c(y*k))}static fromBytes(_,y=!1){const k=n.BYTES,{a:I,d:L}=a;_=Si(fr(_,k,"point")),ma(y,"zip215");const B=Si(_),$=_[k-1];B[k-1]=$&-129;const U=ps(B),A=y?o:n.ORDER;br("point.y",U,ts,A);const E=c(U*U),G=c(E-Ie),N=c(L*E-I);let{isValid:M,value:O}=d(G,N);if(!M)throw new Error("bad point: invalid y coordinate");const Z=(O&Ie)===Ie,se=($&128)!==0;if(!y&&O===ts&&se)throw new Error("bad point: x=0 and x_0=1");return se!==Z&&(O=c(-O)),m.fromAffine({x:O,y:U})}static fromHex(_,y=!1){return m.fromBytes(ut("point",_),y)}get x(){return this.toAffine().x}get y(){return this.toAffine().y}precompute(_=8,y=!0){return w.createCache(this,_),y||this.multiply(oa),this}assertValidity(){f(this)}equals(_){h(_);const{X:y,Y:k,Z:I}=this,{X:L,Y:B,Z:$}=_,U=c(y*$),A=c(L*I),E=c(k*$),G=c(B*I);return U===A&&E===G}is0(){return this.equals(m.ZERO)}negate(){return new m(c(-this.X),this.Y,this.Z,c(-this.T))}double(){const{a:_}=a,{X:y,Y:k,Z:I}=this,L=c(y*y),B=c(k*k),$=c(oa*c(I*I)),U=c(_*L),A=y+k,E=c(c(A*A)-L-B),G=U+B,N=G-$,M=U-B,O=c(E*N),Z=c(G*M),se=c(E*M),de=c(N*G);return new m(O,Z,de,se)}add(_){h(_);const{a:y,d:k}=a,{X:I,Y:L,Z:B,T:$}=this,{X:U,Y:A,Z:E,T:G}=_,N=c(I*U),M=c(L*A),O=c($*k*G),Z=c(B*E),se=c((I+L)*(U+A)-N-M),de=Z-O,ie=Z+O,ae=c(M-y*N),Ce=c(se*de),he=c(ie*ae),le=c(se*ae),Me=c(de*ie);return new m(Ce,he,Me,le)}subtract(_){return this.add(_.negate())}multiply(_){if(!r.isValidNot0(_))throw new Error("invalid scalar: expected 1 <= sc < curve.n");const{p:y,f:k}=w.cached(this,_,I=>ur(m,I));return ur(m,[y,k])[0]}multiplyUnsafe(_,y=m.ZERO){if(!r.isValid(_))throw new Error("invalid scalar: expected 0 <= sc < curve.n");return _===ts?m.ZERO:this.is0()||_===Ie?this:w.unsafe(this,_,k=>ur(m,k),y)}isSmallOrder(){return this.multiplyUnsafe(i).is0()}isTorsionFree(){return w.unsafe(this,a.n).is0()}toAffine(_){return u(this,_)}clearCofactor(){return i===Ie?this:this.multiplyUnsafe(i)}toBytes(){const{x:_,y}=this.toAffine(),k=n.toBytes(y);return k[k.length-1]|=_&Ie?128:0,k}toHex(){return qr(this.toBytes())}toString(){return`<Point ${this.is0()?"ZERO":this.toHex()}>`}get ex(){return this.X}get ey(){return this.Y}get ez(){return this.Z}get et(){return this.T}static normalizeZ(_){return ur(m,_)}static msm(_,y){return Co(m,r,_,y)}_setWindowSize(_){this.precompute(_)}toRawBytes(){return this.toBytes()}}m.BASE=new m(a.Gx,a.Gy,Ie,c(a.Gx*a.Gy)),m.ZERO=new m(ts,Ie,Ie,ts),m.Fp=n,m.Fn=r;const w=new nl(m,r.BITS);return m.BASE.precompute(8),m}class cl{constructor(t){this.ep=t}static fromBytes(t){Ii()}static fromHex(t){Ii()}get x(){return this.toAffine().x}get y(){return this.toAffine().y}clearCofactor(){return this}assertValidity(){this.ep.assertValidity()}toAffine(t){return this.ep.toAffine(t)}toHex(){return qr(this.toBytes())}toString(){return this.toHex()}isTorsionFree(){return!0}isSmallOrder(){return!1}add(t){return this.assertSame(t),this.init(this.ep.add(t.ep))}subtract(t){return this.assertSame(t),this.init(this.ep.subtract(t.ep))}multiply(t){return this.init(this.ep.multiply(t))}multiplyUnsafe(t){return this.init(this.ep.multiplyUnsafe(t))}double(){return this.init(this.ep.double())}negate(){return this.init(this.ep.negate())}precompute(t,s){return this.init(this.ep.precompute(t,s))}toRawBytes(){return this.toBytes()}}function dl(e,t,s={}){if(typeof t!="function")throw new Error('"hash" function param is required');Rr(s,{},{adjustScalarBytes:"function",randomBytes:"function",domain:"function",prehash:"function",mapToCurve:"function"});const{prehash:n}=s,{BASE:r,Fp:a,Fn:i}=e,o=s.randomBytes||uo,c=s.adjustScalarBytes||(A=>A),d=s.domain||((A,E,G)=>{if(ma(G,"phflag"),E.length||G)throw new Error("Contexts/pre-hash are not supported");return A});function l(A){return i.create(ps(A))}function h(A){const E=k.secretKey;A=ut("private key",A,E);const G=ut("hashed private key",t(A),2*E),N=c(G.slice(0,E)),M=G.slice(E,2*E),O=l(N);return{head:N,prefix:M,scalar:O}}function u(A){const{head:E,prefix:G,scalar:N}=h(A),M=r.multiply(N),O=M.toBytes();return{head:E,prefix:G,scalar:N,point:M,pointBytes:O}}function f(A){return u(A).pointBytes}function m(A=Uint8Array.of(),...E){const G=ss(...E);return l(t(d(G,ut("context",A),!!n)))}function w(A,E,G={}){A=ut("message",A),n&&(A=n(A));const{prefix:N,scalar:M,pointBytes:O}=u(E),Z=m(G.context,N,A),se=r.multiply(Z).toBytes(),de=m(G.context,se,O,A),ie=i.create(Z+de*M);if(!i.isValid(ie))throw new Error("sign failed: invalid s");const ae=ss(se,i.toBytes(ie));return fr(ae,k.signature,"result")}const x={zip215:!0};function _(A,E,G,N=x){const{context:M,zip215:O}=N,Z=k.signature;A=ut("signature",A,Z),E=ut("message",E),G=ut("publicKey",G,k.publicKey),O!==void 0&&ma(O,"zip215"),n&&(E=n(E));const se=Z/2,de=A.subarray(0,se),ie=ps(A.subarray(se,Z));let ae,Ce,he;try{ae=e.fromBytes(G,O),Ce=e.fromBytes(de,O),he=r.multiplyUnsafe(ie)}catch{return!1}if(!O&&ae.isSmallOrder())return!1;const le=m(M,Ce.toBytes(),ae.toBytes(),E);return Ce.add(ae.multiplyUnsafe(le)).subtract(he).clearCofactor().is0()}const y=a.BYTES,k={secretKey:y,publicKey:y,signature:2*y,seed:y};function I(A=o(k.seed)){return fr(A,k.seed,"seed")}function L(A){const E=U.randomSecretKey(A);return{secretKey:E,publicKey:f(E)}}function B(A){return jn(A)&&A.length===i.BYTES}function $(A,E){try{return!!e.fromBytes(A,E)}catch{return!1}}const U={getExtendedPublicKey:u,randomSecretKey:I,isValidSecretKey:B,isValidPublicKey:$,toMontgomery(A){const{y:E}=e.fromBytes(A),G=k.publicKey,N=G===32;if(!N&&G!==57)throw new Error("only defined for 25519 and 448");const M=N?a.div(Ie+E,Ie-E):a.div(E-Ie,E+Ie);return a.toBytes(M)},toMontgomerySecret(A){const E=k.secretKey;fr(A,E);const G=t(A.subarray(0,E));return c(G).subarray(0,E)},randomPrivateKey:I,precompute(A=8,E=e.BASE){return E.precompute(A,!1)}};return Object.freeze({keygen:L,getPublicKey:f,sign:w,verify:_,utils:U,Point:e,lengths:k})}function ll(e){const t={a:e.a,d:e.d,p:e.Fp.ORDER,n:e.n,h:e.h,Gx:e.Gx,Gy:e.Gy},s=e.Fp,n=an(t.n,e.nBitLength,!0),r={Fp:s,Fn:n,uvRatio:e.uvRatio},a={randomBytes:e.randomBytes,adjustScalarBytes:e.adjustScalarBytes,domain:e.domain,prehash:e.prehash,mapToCurve:e.mapToCurve};return{CURVE:t,curveOpts:r,hash:e.hash,eddsaOpts:a}}function ul(e,t){const s=t.Point;return Object.assign({},t,{ExtendedPoint:s,CURVE:e,nBitLength:s.Fn.BITS,nByteLength:s.Fn.BYTES})}function pl(e){const{CURVE:t,curveOpts:s,hash:n,eddsaOpts:r}=ll(e),a=ol(t,s),i=dl(a,n,r);return ul(e,i)}function Rs(e,t){if(ya(e),ya(t),e<0||e>=1<<8*t)throw new Error("invalid I2OSP input: "+e);const s=Array.from({length:t}).fill(0);for(let n=t-1;n>=0;n--)s[n]=e&255,e>>>=8;return new Uint8Array(s)}function hl(e,t){const s=new Uint8Array(e.length);for(let n=0;n<e.length;n++)s[n]=e[n]^t[n];return s}function ya(e){if(!Number.isSafeInteger(e))throw new Error("number expected")}function vl(e){if(!jn(e)&&typeof e!="string")throw new Error("DST must be Uint8Array or string");return typeof e=="string"?Dr(e):e}function Mi(e,t,s,n){Bt(e),ya(s),t=vl(t),t.length>255&&(t=n(ss(Dr("H2C-OVERSIZE-DST-"),t)));const{outputLen:r,blockLen:a}=n,i=Math.ceil(s/r);if(i>255)throw new Error("expand_message_xmd: invalid lenInBytes");const o=ss(t,Rs(t.length,1)),c=Rs(0,a),d=Rs(s,2),l=new Array(i),h=n(ss(c,e,d,Rs(0,1),o));l[0]=n(ss(h,Rs(1,1),o));for(let f=1;f<=i;f++){const m=[hl(h,l[f-1]),Rs(f+1,1),o];l[f]=n(ss(...m))}return ss(...l).slice(0,s)}const fl=Dr("HashToScalar-");/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const vn=BigInt(0),Ns=BigInt(1),pr=BigInt(2);function ml(e){return Rr(e,{adjustScalarBytes:"function",powPminus2:"function"}),Object.freeze({...e})}function gl(e){const t=ml(e),{P:s,type:n,adjustScalarBytes:r,powPminus2:a,randomBytes:i}=t,o=n==="x25519";if(!o&&n!=="x448")throw new Error("invalid type");const c=i||uo,d=o?255:448,l=o?32:56,h=BigInt(o?9:5),u=BigInt(o?121665:39081),f=o?pr**BigInt(254):pr**BigInt(447),m=o?BigInt(8)*pr**BigInt(251)-Ns:BigInt(4)*pr**BigInt(445)-Ns,w=f+m+Ns,x=M=>fe(M,s),_=y(h);function y(M){return mo(x(M),l)}function k(M){const O=ut("u coordinate",M,l);return o&&(O[31]&=127),x(ps(O))}function I(M){return ps(r(ut("scalar",M,l)))}function L(M,O){const Z=U(k(O),I(M));if(Z===vn)throw new Error("invalid private or public key received");return y(Z)}function B(M){return L(M,_)}function $(M,O,Z){const se=x(M*(O-Z));return O=x(O-se),Z=x(Z+se),{x_2:O,x_3:Z}}function U(M,O){br("u",M,vn,s),br("scalar",O,f,w);const Z=O,se=M;let de=Ns,ie=vn,ae=M,Ce=Ns,he=vn;for(let Me=BigInt(d-1);Me>=vn;Me--){const st=Z>>Me&Ns;he^=st,{x_2:de,x_3:ae}=$(he,de,ae),{x_2:ie,x_3:Ce}=$(he,ie,Ce),he=st;const je=de+ie,Ae=x(je*je),be=de-ie,Ut=x(be*be),We=Ae-Ut,nt=ae+Ce,Se=ae-Ce,Ze=x(Se*je),rt=x(nt*be),Vt=Ze+rt,Ps=Ze-rt;ae=x(Vt*Vt),Ce=x(se*x(Ps*Ps)),de=x(Ae*Ut),ie=x(We*(Ae+x(u*We)))}({x_2:de,x_3:ae}=$(he,de,ae)),{x_2:ie,x_3:Ce}=$(he,ie,Ce);const le=a(ie);return x(de*le)}const A={secretKey:l,publicKey:l,seed:l},E=(M=c(l))=>(Bt(M,A.seed),M);function G(M){const O=E(M);return{secretKey:O,publicKey:B(O)}}return{keygen:G,getSharedSecret:(M,O)=>L(M,O),getPublicKey:M=>B(M),scalarMult:L,scalarMultBase:B,utils:{randomSecretKey:E,randomPrivateKey:E},GuBytes:_.slice(),lengths:A}}/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */const yl=BigInt(0),Gt=BigInt(1),Bi=BigInt(2),bl=BigInt(3),_l=BigInt(5),wl=BigInt(8),zs=BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed"),Wn={p:zs,n:BigInt("0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed"),h:wl,a:BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffec"),d:BigInt("0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3"),Gx:BigInt("0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a"),Gy:BigInt("0x6666666666666666666666666666666666666666666666666666666666666658")};function Ao(e){const t=BigInt(10),s=BigInt(20),n=BigInt(40),r=BigInt(80),a=zs,o=e*e%a*e%a,c=_t(o,Bi,a)*o%a,d=_t(c,Gt,a)*e%a,l=_t(d,_l,a)*d%a,h=_t(l,t,a)*l%a,u=_t(h,s,a)*h%a,f=_t(u,n,a)*u%a,m=_t(f,r,a)*f%a,w=_t(m,r,a)*f%a,x=_t(w,t,a)*l%a;return{pow_p_5_8:_t(x,Bi,a)*e%a,b2:o}}function $o(e){return e[0]&=248,e[31]&=127,e[31]|=64,e}const ba=BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");function Ha(e,t){const s=zs,n=fe(t*t*t,s),r=fe(n*n*t,s),a=Ao(e*r).pow_p_5_8;let i=fe(e*n*a,s);const o=fe(t*i*i,s),c=i,d=fe(i*ba,s),l=o===e,h=o===fe(-e,s),u=o===fe(-e*ba,s);return l&&(i=c),(h||u)&&(i=d),ns(i,s)&&(i=fe(-i,s)),{isValid:l||h,value:i}}const Ht=an(Wn.p,{isLE:!0}),To=an(Wn.n,{isLE:!0}),kl={...Wn,Fp:Ht,hash:yr,adjustScalarBytes:$o,uvRatio:Ha},ke=pl(kl),rs=(()=>{const e=Ht.ORDER;return gl({P:e,type:"x25519",powPminus2:t=>{const{pow_p_5_8:s,b2:n}=Ao(t);return fe(_t(s,bl,e)*n,e)},adjustScalarBytes:$o})})(),_a=ba,xl=BigInt("25063068953384623474111414158702152701244531502492656460079210482610430750235"),Sl=BigInt("54469307008909316920995813868745141605393597292927456921205312896311721017578"),Il=BigInt("1159843021668779879193775521855586647937357759715417654439879720876111806838"),El=BigInt("40440834346308536858101042469323190826248399146238708352240133220865137265952"),Ui=e=>Ha(Gt,e),Cl=BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"),wa=e=>ke.Point.Fp.create(ps(e)&Cl);function qi(e){const{d:t}=Wn,s=zs,n=_=>Ht.create(_),r=n(_a*e*e),a=n((r+Gt)*Il);let i=BigInt(-1);const o=n((i-t*r)*n(r+t));let{isValid:c,value:d}=Ha(a,o),l=n(d*e);ns(l,s)||(l=n(-l)),c||(d=l),c||(i=r);const h=n(i*(r-Gt)*El-o),u=d*d,f=n((d+d)*o),m=n(h*xl),w=n(Gt-u),x=n(Gt+u);return new ke.Point(n(f*x),n(w*m),n(m*x),n(f*w))}function Lo(e){Bt(e,64);const t=wa(e.subarray(0,32)),s=qi(t),n=wa(e.subarray(32,64)),r=qi(n);return new Re(s.add(r))}class Re extends cl{constructor(t){super(t)}static fromAffine(t){return new Re(ke.Point.fromAffine(t))}assertSame(t){if(!(t instanceof Re))throw new Error("RistrettoPoint expected")}init(t){return new Re(t)}static hashToCurve(t){return Lo(ut("ristrettoHash",t,64))}static fromBytes(t){Bt(t,32);const{a:s,d:n}=Wn,r=zs,a=I=>Ht.create(I),i=wa(t);if(!jd(Ht.toBytes(i),t)||ns(i,r))throw new Error("invalid ristretto255 encoding 1");const o=a(i*i),c=a(Gt+s*o),d=a(Gt-s*o),l=a(c*c),h=a(d*d),u=a(s*n*l-h),{isValid:f,value:m}=Ui(a(u*h)),w=a(m*d),x=a(m*w*u);let _=a((i+i)*w);ns(_,r)&&(_=a(-_));const y=a(c*x),k=a(_*y);if(!f||ns(k,r)||y===yl)throw new Error("invalid ristretto255 encoding 2");return new Re(new ke.Point(_,y,Gt,k))}static fromHex(t){return Re.fromBytes(ut("ristrettoHex",t,32))}static msm(t,s){return Co(Re,ke.Point.Fn,t,s)}toBytes(){let{X:t,Y:s,Z:n,T:r}=this.ep;const a=zs,i=x=>Ht.create(x),o=i(i(n+s)*i(n-s)),c=i(t*s),d=i(c*c),{value:l}=Ui(i(o*d)),h=i(l*o),u=i(l*c),f=i(h*u*r);let m;if(ns(r*f,a)){let x=i(s*_a),_=i(t*_a);t=x,s=_,m=i(h*Sl)}else m=u;ns(t*f,a)&&(s=i(-s));let w=i((n-s)*m);return ns(w,a)&&(w=i(-w)),Ht.toBytes(w)}equals(t){this.assertSame(t);const{X:s,Y:n}=this.ep,{X:r,Y:a}=t.ep,i=d=>Ht.create(d),o=i(s*a)===i(n*r),c=i(n*a)===i(s*r);return o||c}is0(){return this.equals(Re.ZERO)}}Re.BASE=new Re(ke.Point.BASE);Re.ZERO=new Re(ke.Point.ZERO);Re.Fp=Ht;Re.Fn=To;const Fe={Point:Re},Al={hashToCurve(e,t){const s=(t==null?void 0:t.DST)||"ristretto255_XMD:SHA-512_R255MAP_RO_",n=Mi(e,s,64,yr);return Lo(n)},hashToScalar(e,t={DST:fl}){const s=Mi(e,t.DST,64,yr);return To.create(ps(s))}},$l=yr;function C(e){let t="";for(const s of e)t+=String.fromCharCode(s);return btoa(t)}function W(e){const t=atob(e),s=new Uint8Array(t.length);for(let n=0;n<t.length;n+=1)s[n]=t.charCodeAt(n);return s}function q(e){return new TextEncoder().encode(e)}function Tl(e){return new TextDecoder().decode(e)}function Le(e){let t="";for(const s of e)t+=s.toString(16).padStart(2,"0");return t}function Kt(e){const t=e.reduce((r,a)=>r+a.length,0),s=new Uint8Array(t);let n=0;for(const r of e)s.set(r,n),n+=r.length;return s}function Q(e){const t=new Uint8Array(e);return crypto.getRandomValues(t),t}function z(e){return e|32768}function Oa(e){const t=[];for(const s of e){if(s.value.length>65535)throw new Error("tlv value too large");const n=new Uint8Array(4);n[0]=s.ty>>8&255,n[1]=s.ty&255,n[2]=s.value.length>>8&255,n[3]=s.value.length&255,t.push(n,s.value)}return Kt(t)}function Ga(e){const t=BigInt(e),s=new Uint8Array(8);for(let n=0;n<8;n+=1){const r=BigInt((7-n)*8);s[n]=Number(t>>r&0xffn)}return s}function Ll(e){return new Uint8Array([e>>8&255,e&255])}let V=null,Di=!1;function vt(e){if(typeof e!="string")throw new Error("Unexpected WASM JSON payload");return JSON.parse(e)}async function Pl(){if(V)return!0;if(Di)return!1;Di=!0;try{const t=await import("../pkg/pqmsg_core");return await t.default(),V=t,!0}catch{return!1}}function Nr(){return V!==null&&typeof V.wasm_initiate_session_and_encrypt=="function"&&typeof V.wasm_encrypt_with_session=="function"&&typeof V.wasm_decrypt_message=="function"}function Ml(e,t,s,n,r,a){if(!V||typeof V.wasm_compute_safety_number!="function")throw new Error("WASM PQ runtime is required to compute safety numbers");return V.wasm_compute_safety_number(e,t,s,n,r,a)}function Ri(e,t,s){if(!V||typeof V.wasm_verify_transparency_proof!="function")throw new Error("WASM PQ runtime is required to verify transparency proofs");return V.wasm_verify_transparency_proof(e,t,s??null)}function Po(){return V!==null&&typeof V.wasm_kem_keypair=="function"}function wr(){if(!V)throw new Error("WASM not initialized");if(typeof V.wasm_kem_keypair!="function")throw new Error("KEM not available - WASM built without post-quantum support");return V.wasm_kem_keypair()}function Mo(){return V!==null&&typeof V.wasm_ml_dsa_keypair=="function"}function Bl(){if(!V)throw new Error("WASM not initialized");if(typeof V.wasm_ml_dsa_keypair!="function")throw new Error("ML-DSA not available - WASM built without post-quantum support");return V.wasm_ml_dsa_keypair()}function kr(e,t){if(!V)throw new Error("WASM not initialized");if(typeof V.wasm_ml_dsa_sign!="function")throw new Error("ML-DSA not available - WASM built without post-quantum support");return V.wasm_ml_dsa_sign(e,t)}function Ul(e,t,s,n,r){if(!Nr())throw new Error("WASM PQ session messaging is not available");return V.wasm_initiate_session_and_encrypt(e,t,s,n,r)}function ql(e,t,s,n){if(!Nr())throw new Error("WASM PQ session messaging is not available");return V.wasm_encrypt_with_session(e,t,s,n)}function Dl(e,t,s,n,r){if(!Nr())throw new Error("WASM PQ session messaging is not available");return V.wasm_decrypt_message(e,t,s,n,r??void 0)}function Rl(e,t,s,n,r){if(!V||typeof V.wasm_seal_message_with_sender_cert!="function")throw new Error("WASM certified sealed sender transport is not available");return V.wasm_seal_message_with_sender_cert(e,t,s,n,r)}function Nl(e,t,s,n){if(!V||typeof V.wasm_open_sealed_message_with_sender_cert!="function")throw new Error("WASM certified sealed sender transport is not available");return V.wasm_open_sealed_message_with_sender_cert(e,t??null,s,n)}function tt(){return V!==null&&typeof V.wasm_private_group_create_state=="function"&&typeof V.wasm_private_group_describe_member_credential=="function"}function Hl(e,t,s,n){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_create_state(e,JSON.stringify(t),JSON.stringify(s),BigInt(n)))}function Ol(e){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_encrypt_snapshot(JSON.stringify(e)))}function Ni(e,t){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_export_join_package_for_member(JSON.stringify(e),t))}function Gl(e){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_restore_join_package(JSON.stringify(e)))}function kt(e){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_describe_member_credential(JSON.stringify(e)))}function jl(e,t){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_prepare_bootstrap_material(JSON.stringify(e),t))}function Bo(e){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_encrypt_join_package_for_share_link(JSON.stringify(e)))}function Wl(e,t){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_open_share_link_invite(JSON.stringify(e),t))}function Kl(e,t,s,n){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_prepare_add_member_transition(JSON.stringify(e),t,s,BigInt(n)))}function Fl(e,t,s){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_prepare_remove_member_transition(JSON.stringify(e),t,BigInt(s)))}function Vl(e,t,s,n,r,a){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_encrypt_message(JSON.stringify(e),t,s,n,r,BigInt(a)))}function zl(e,t,s,n){if(!tt())throw new Error("WASM private group bindings are not available");return vt(V.wasm_private_group_open_message(JSON.stringify(e),JSON.stringify(t),s,n))}const Yl=z(12801),Jl=z(12802),Xl=z(12803),Zl=z(12804),Ql=z(12805),me=z(12806),eu=z(12807),tu=z(12809),su=z(12810),nu=z(12818),Uo=z(12819),qo=z(12825),ru=z(12826),au=z(12827),iu=z(12828),ou=z(12838),cu=z(12839),du=z(12840),lu=z(12845),uu=z(12846),pu=z(12841),hu=z(12842),vu=z(12843),fu=z(12820),mu=z(12834),gu=z(12835),yu=z(12836),bu=z(12837),_u=z(12816),wu=z(12817),ku=z(12811),xu=z(12812),Su=z(12813),Iu=z(12814),Eu=z(12815),Cu=z(12848),Au=z(12849),$u=z(12850),Tu=z(12851),Lu=z(513),Pu=z(514),Mu=z(515),Bu=z(12545),Uu=z(12546),qu=z(12547),Du=z(12548),Ru=z(12549),Nu=z(12550),Hu=z(12551),Ou=2e5,Gu=0,ju=1;function Do(e,t,s,n){if(n<1||n>64)throw new Error("one-time prekey count must be in 1..64");if(!Po()||!Mo())throw new Error("Web post-quantum runtime unavailable in this build.");const r=rs.utils.randomPrivateKey(),a=rs.getPublicKey(r),i=ke.utils.randomPrivateKey(),o=ke.getPublicKey(i),c=Bl(),d=rs.utils.randomPrivateKey(),l=rs.getPublicKey(d),h=wr(),u=[],f=[],m=[],w=[];for(let x=0;x<n;x+=1){const _=rs.utils.randomPrivateKey(),y=rs.getPublicKey(_);u.push(C(y)),f.push(C(_));const k=wr();m.push(C(k.public_key)),w.push(C(k.secret_key))}return{userId:e,deviceId:t,suite:s,identityX25519Pub:C(a),identityX25519Secret:C(r),identitySigPub:C(o),identitySigSecret:C(i),identityPqSigPub:C(c.public_key),identityPqSigSecret:C(c.secret_key),signedPrekeyX25519Pub:C(l),signedPrekeyX25519Secret:C(d),pqSignedPrekeyPubMlkem768:C(h.public_key),pqSignedPrekeySecretMlkem768:C(h.secret_key),oneTimePrekeysX25519:u,oneTimePrekeysX25519Secret:f,oneTimePrekeysMlkem768:m,oneTimePrekeysMlkem768Secret:w}}function Ro(e){const t=W(e.signedPrekeyX25519Pub),s=W(e.pqSignedPrekeyPubMlkem768),n=W(e.identitySigSecret),r=W(e.identityPqSigSecret),a=Oi(1,q("SPK"),t),i=Oi(1,q("PQSPK"),s),o=ke.sign(a,n),c=ke.sign(i,n),d=kr(r,a),l=kr(r,i);return{signed_prekey_x25519_pub:e.signedPrekeyX25519Pub,sig_over_spk:C(o),pq_signed_prekey_pub_mlkem768:e.pqSignedPrekeyPubMlkem768,sig_over_pqspk:C(c),pq_sig_over_spk:C(d),pq_sig_over_pqspk:C(l),one_time_prekeys_x25519:e.oneTimePrekeysX25519,one_time_prekeys_mlkem768:e.oneTimePrekeysMlkem768}}function No(e,t){const s=te(),n=C(Q(16)),r=ne("prekeys",e.userId,e.deviceId,s,n);return r.push({ty:tu,value:ce(q(t.signed_prekey_x25519_pub))}),r.push({ty:su,value:ce(q(t.pq_signed_prekey_pub_mlkem768))}),re(e,s,n,r)}function Wu(e){const t=te(),s=C(Q(16)),n=ne("devices-list",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function Ku(e,t){const s=te(),n=C(Q(16)),r=ne("devices-link",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:nu,value:q(t)}),re(e,s,n,r)}function Fu(e,t){const s=te(),n=C(Q(16)),r=ne("devices-revoke",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:Uo,value:q(t)}),re(e,s,n,r)}function Vu(e){const t=te(),s=C(Q(16)),n=ne("devices-retire",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),n.push({ty:Uo,value:q(e.deviceId)}),re(e,t,s,n)}function ja(e,t){const s=te(),n=C(Q(16)),r=ne("profile-get",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(t)}),re(e,s,n,r)}function Wa(e,t,s,n,r,a){const i=te(),o=C(Q(16)),c=ne("profile-upsert",e.userId,e.deviceId,i,o);return c.push({ty:me,value:q(e.userId)}),c.push({ty:ou,value:ce(q(t))}),c.push({ty:lu,value:ce(q(s.trim().replace(/^@/,"").toLowerCase()))}),c.push({ty:uu,value:new Uint8Array([n?1:0])}),c.push({ty:cu,value:ce(q(a))}),c.push({ty:du,value:ce(q(r))}),re(e,i,o,c)}function zu(e){const t=te(),s=C(Q(16)),n=ne("presence-get",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function Yu(e,t){const s=te(),n=C(Q(16)),r=ne("presence-update",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:pu,value:q(t)}),re(e,s,n,r)}function Ju(e){const t=te(),s=C(Q(16)),n=ne("typing-get",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function Xu(e,t,s){const n=te(),r=C(Q(16)),a=ne("typing-update",e.userId,e.deviceId,n,r);return a.push({ty:hu,value:q(t)}),a.push({ty:vu,value:new Uint8Array([s?1:0])}),re(e,n,r,a)}function Zu(e,t,s){const n=`receipt:${e.userId}:${e.deviceId}:${t}:${s}`,r=te(),a=C(Q(16)),i=W(e.identitySigSecret),o=ke.sign(q(n),i);return{"x-pqmsg-auth-user":e.userId,"x-pqmsg-auth-device":e.deviceId,"x-pqmsg-auth-timestamp":String(r),"x-pqmsg-auth-nonce":a,"x-pqmsg-auth-signature":C(o)}}function Qu(e,t){const s=`get-receipts:${e.userId}:${e.deviceId}:${t}`,n=te(),r=C(Q(16)),a=W(e.identitySigSecret),i=ke.sign(q(s),a);return{"x-pqmsg-auth-user":e.userId,"x-pqmsg-auth-device":e.deviceId,"x-pqmsg-auth-timestamp":String(n),"x-pqmsg-auth-nonce":r,"x-pqmsg-auth-signature":C(i)}}function ep(e){const t=te(),s=C(Q(16)),n=ne("contacts-list",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function tp(e){const t=te(),s=C(Q(16)),n=ne("contact-invite-create",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function Hr(e,t,s,n,r){const a=te(),i=C(Q(16)),o=ne("contacts-upsert",e.userId,e.deviceId,a,i);return o.push({ty:me,value:q(e.userId)}),o.push({ty:qo,value:q(t)}),o.push({ty:ru,value:ce(q(s))}),o.push({ty:au,value:new Uint8Array([n?1:0])}),r&&o.push({ty:iu,value:q(r)}),re(e,a,i,o)}function sp(e,t){const s=te(),n=C(Q(16)),r=ne("contacts-remove",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:qo,value:q(t)}),re(e,s,n,r)}function np(e,t){const s=te(),n=C(Q(16)),r=ne("groups-list",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(t)}),re(e,s,n,r)}function rp(e,t,s,n){const r=te(),a=C(Q(16)),i=ne("files-upload",e.userId,e.deviceId,r,a);return i.push({ty:gu,value:q(t)}),i.push({ty:yu,value:ce(W(n))}),i.push({ty:bu,value:ce(q(s))}),re(e,r,a,i)}function Ho(e,t){const s=te(),n=C(Q(16)),r=ne("files-download",e.userId,e.deviceId,s,n);return r.push({ty:mu,value:q(t)}),re(e,s,n,r)}function ap(e,t,s){const n=te(),r=C(Q(16)),a=ne("inbox-delete",e.userId,e.deviceId,n,r);a.push({ty:me,value:q(e.userId)});const i=[...new Set(t)].sort((c,d)=>c-d),o=Kt(i.map(c=>Ga(c)));return a.push({ty:fu,value:ce(o)}),re(e,n,r,a)}function ip(e){const t=te(),s=C(Q(16)),n=ne("prekeys-status",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function op(e,t,s,n){const r=te(),a=C(Q(16)),i=ne("rotate-init",e.userId,e.deviceId,r,a);return i.push({ty:ku,value:ce(q(t))}),i.push({ty:xu,value:ce(q(s))}),i.push({ty:Cu,value:ce(q(n))}),re(e,r,a,i)}function cp(e,t,s,n,r,a){const i=te(),o=C(Q(16)),c=ne("rotate-confirm",e.userId,e.deviceId,i,o);return c.push({ty:Su,value:q(t)}),c.push({ty:Iu,value:ce(q(s))}),c.push({ty:Eu,value:ce(q(n))}),c.push({ty:Au,value:ce(q(r))}),c.push({ty:$u,value:ce(q(a))}),re(e,i,o,c)}function dp(e,t,s,n){if(!Mo())throw new Error("Web post-quantum runtime unavailable in this build.");if(e.userId!==t.userId)throw new Error("rotation requires current and new keys for the same user");const r=W(n),a=Lp(e.userId,s,r,W(t.identityX25519Pub),W(t.identitySigPub),W(t.identityPqSigPub),t.deviceId);return{challenge_id:s,sig_by_current_identity:C(ke.sign(a,W(e.identitySigSecret))),sig_by_new_identity:C(ke.sign(a,W(t.identitySigSecret))),pq_sig_by_current_identity:C(kr(W(e.identityPqSigSecret),a)),pq_sig_by_new_identity:C(kr(W(t.identityPqSigSecret),a))}}function lp(e){const t=te(),s=C(Q(16)),n=ne("identity-log",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function Oo(e,t){const s=te(),n=C(Q(16)),r=ne("sealed-inbox",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:eu,value:Ga(t)}),re(e,s,n,r)}function ka(e){const t=te(),s=C(Q(16)),n=ne("sender-certificate",e.userId,e.deviceId,t,s);return n.push({ty:me,value:q(e.userId)}),re(e,t,s,n)}function up(e,t){const s=te(),n=C(Q(16)),r=ne("contact-discovery-ticket",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:Tu,value:q(t)}),re(e,s,n,r)}function pp(e,t){const s=te(),n=C(Q(16)),r=ne("push-token",e.userId,e.deviceId,s,n);return r.push({ty:me,value:q(e.userId)}),r.push({ty:_u,value:q(e.deviceId)}),r.push({ty:wu,value:ce(q(t))}),re(e,s,n,r)}async function Go(e,t){const s=q(JSON.stringify(e)),n=Q(16),r=Q(12),a=await zo(t,n),i=q("pqmsg-web-fallback-sealed-state-v1"),o=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:r.buffer,additionalData:i.buffer},a,s.buffer)),c={salt_b64:C(n),iv_b64:C(r),ct_b64:C(o)};return JSON.stringify(c)}async function jo(e,t){const s=JSON.parse(e),n=W(s.salt_b64),r=W(s.iv_b64),a=W(s.ct_b64),i=await zo(t,n),o=q("pqmsg-web-fallback-sealed-state-v1");let c;try{c=new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv:r.buffer,additionalData:o.buffer},i,a.buffer))}catch{throw new Error("Wrong passphrase — decryption failed. Please try again.")}return JSON.parse(Tl(c))}async function Wo(){return Pl()}function xr(){return Nr()}function hp(e,t=Math.max(e.oneTimePrekeysX25519.length,16)){if(!Po())throw new Error("Web post-quantum runtime unavailable in this build.");if(t<1||t>64)throw new Error("one-time prekey count must be in 1..64");const s=[],n=[],r=[],a=[];for(let o=0;o<t;o+=1){const c=rs.utils.randomPrivateKey(),d=rs.getPublicKey(c),l=wr();s.push(C(d)),n.push(C(c)),r.push(C(l.public_key)),a.push(C(l.secret_key))}const i=wr();return{...e,pqSignedPrekeyPubMlkem768:C(i.public_key),pqSignedPrekeySecretMlkem768:C(i.secret_key),oneTimePrekeysX25519:s,oneTimePrekeysX25519Secret:n,oneTimePrekeysMlkem768:r,oneTimePrekeysMlkem768Secret:a}}function vp(e,t,s){const n=Ul(e,e.userId,t.user_id,t,s);return{messageBytesBase64:n.message_bytes_base64,sessionJson:n.session_json,usedHandshake:n.used_handshake}}function fp(e,t,s,n){const r=ql(e,t,s,n);return{messageBytesBase64:r.message_bytes_base64,sessionJson:r.session_json,usedHandshake:r.used_handshake}}function mp(e,t,s,n){const r=Dl(e,e.userId,t,s,n);return{plaintextUtf8:r.plaintext_utf8,plaintextBase64:r.plaintext_base64,sessionJson:r.session_json,usedHandshake:r.used_handshake,updatedKeys:r.updated_keys}}function Hi(e,t,s,n,r){return Rl(e,t,s,n,r)}function gp(e,t,s,n){const r=Nl(e,t,s,n);return{senderUserId:r.sender_user_id,senderDeviceId:r.sender_device_id,payloadMessageBytesBase64:r.payload_message_bytes_base64}}function Ko(e,t,s,n){return Ml(e.userId,e.identityX25519Pub,e.identityPqSigPub,t,s,n)}function yp(e){if(!Number.isSafeInteger(e)||e<0||e>4294967295)throw new Error("Transparency field length overflow");return new Uint8Array([e>>>24&255,e>>>16&255,e>>>8&255,e&255])}function Sr(e){if(!Number.isSafeInteger(e)||e<0)throw new Error("Transparency integer overflow");let t=BigInt(e);const s=new Uint8Array(8);for(let n=7;n>=0;n-=1)s[n]=Number(t&0xffn),t>>=8n;return s}function cs(e,t,s){const n=W(t);if(n.length!==s)throw new Error(`${e} must be ${s} bytes`);return n}function ca(e,t){e.push(yp(t.length)),e.push(t)}function bp(e){const t=cs("transparency.leaf.identity_x25519_pub",e.identity_x25519_pub,32),s=W(e.identity_sig_pub),n=[new Uint8Array([Gu])];return ca(n,q(e.user_id)),n.push(Sr(e.version)),n.push(t),ca(n,s),e.identity_pq_sig_pub?(n.push(new Uint8Array([1])),ca(n,W(e.identity_pq_sig_pub))):n.push(new Uint8Array([0])),n.push(Sr(e.timestamp)),ce(Kt(n))}function wn(e,t){return ce(Kt([new Uint8Array([ju]),e,t]))}function xa(e,t){const s=cs("transparency.signed_tree_head.root_hash",e.root_hash,32),n=W(e.signature),r=cs("transparency.server_pub_key",t,32),a=Kt([Sr(e.epoch),Sr(e.tree_size),s]);if(!ke.verify(n,a,r))throw new Error("Transparency signed tree head signature verification failed")}function _p(e,t){xa(e.signed_tree_head,t);let s=bp(e.leaf);for(const r of e.inclusion_proof.path){const a=cs("transparency.inclusion_proof.path.hash",r.hash,32);s=r.is_left?wn(a,s):wn(s,a)}const n=cs("transparency.signed_tree_head.root_hash",e.signed_tree_head.root_hash,32);if(Le(s)!==Le(n))throw new Error("Transparency inclusion proof is invalid")}function wp(e,t,s,n){if(e===0||e>t||n.length===0)throw new Error("Transparency consistency proof parameters are invalid");if(e===t)throw new Error("Transparency consistency proof parameters are invalid");let r=e-1,a=t-1;for(;(r&1)===1;)r>>=1,a>>=1;let i=0,o,c;for((e&e-1)===0?(o=s,c=s):(o=n[0],c=n[0],i=1);i<n.length;){const d=n[i];if(i+=1,a===0)throw new Error("Transparency consistency proof parameters are invalid");if((r&1)===1||r===a)for(o=wn(d,o),c=wn(d,c);r!==0&&(r&1)===0;)r>>=1,a>>=1;else c=wn(c,d);r>>=1,a>>=1}if(a!==0)throw new Error("Transparency consistency proof parameters are invalid");return{oldRoot:o,newRoot:c}}function kp(e,t,s){if(xa(s,t),xa(e.signed_tree_head,t),e.signed_tree_head.epoch<s.epoch)throw new Error("Transparency epoch regressed");if(e.signed_tree_head.tree_size<s.tree_size)throw new Error("Transparency tree shrank");const n=e.consistency_proof;if(!n)return!1;if(n.old_size!==s.tree_size||n.new_size!==e.signed_tree_head.tree_size)throw new Error("Transparency consistency proof size mismatch");const r=cs("transparency.previous_sth.root_hash",s.root_hash,32),a=cs("transparency.signed_tree_head.root_hash",e.signed_tree_head.root_hash,32);if(s.tree_size===e.signed_tree_head.tree_size){if(Le(r)!==Le(a))throw new Error("Transparency root hash mismatch");return!0}const i=n.proof_hashes.map(d=>cs("transparency.consistency_proof.hash",d,32)),{oldRoot:o,newRoot:c}=wp(s.tree_size,e.signed_tree_head.tree_size,r,i);if(Le(o)!==Le(r))throw new Error("Transparency old root mismatch");if(Le(c)!==Le(a))throw new Error("Transparency new root mismatch");return!0}function xp(e){const t=e instanceof Error?e.message:String(e??"");return t.includes("WASM PQ runtime is required to verify transparency proofs")||t.includes("wasm_verify_transparency_proof")||t.includes("verifyTransparencyProof is not a function")}function Sp(e,t,s){const n=JSON.parse(e);return _p(n,t),{verified:!0,consistencyVerified:s?kp(n,t,JSON.parse(s)):!1,leafUserId:n.leaf.user_id,leafVersion:n.leaf.version,treeSize:n.signed_tree_head.tree_size,epoch:n.signed_tree_head.epoch}}function Fo(e,t,s){if(typeof Ri=="function")try{const n=Ri(e,t,s??null);return{verified:n.verified,consistencyVerified:n.consistency_verified,leafUserId:n.leaf_user_id,leafVersion:n.leaf_version,treeSize:n.tree_size,epoch:n.epoch}}catch(n){if(!xp(n))throw n}return Sp(e,t,s)}function Ip(e,t,s,n=null,r=null,a=null,i=null){if(e.ticket_issuer_ed25519_pub!==t)throw new Error("Contact discovery manifest ticket issuer mismatch");if(e.manifest_issuer_ed25519_pub!==s)throw new Error("Contact discovery manifest issuer mismatch");const o=Date.parse(e.signed_at),c=Date.parse(e.expires_at);if(!Number.isFinite(o)||!Number.isFinite(c)||c<=o)throw new Error("Contact discovery manifest timing is invalid");if(c<=Date.now())throw new Error("Contact discovery manifest expired");if((n??"").trim()&&e.attestation_verifier!==n)throw new Error("Contact discovery manifest attestation verifier mismatch");if((r??"").trim()&&e.enclave_measurement_hex!==r)throw new Error("Contact discovery manifest enclave measurement mismatch");if(a&&!Vo(e.attestation_pcrs_sha384,a))throw new Error("Contact discovery manifest attestation PCR set mismatch");if((i??"").trim()&&e.attestation_document_sha256!==i)throw new Error("Contact discovery manifest attestation document hash mismatch");if(e.attestation_mode!=="attested_enclave_v1"||!e.attestation_verifier||!e.enclave_measurement_hex||!e.attestation_document_format||!e.attestation_document_sha256||!e.attestation_challenge_mode)throw new Error("Contact discovery manifest attestation contract is incomplete");const d=q(JSON.stringify({service:e.service,protocol_version:e.protocol_version,attestation_mode:e.attestation_mode,attestation_verifier:e.attestation_verifier??null,enclave_measurement_hex:e.enclave_measurement_hex??null,attestation_pcrs_sha384:Un(e.attestation_pcrs_sha384),attestation_document_format:e.attestation_document_format??null,attestation_document_sha256:e.attestation_document_sha256??null,attestation_challenge_mode:e.attestation_challenge_mode??null,ticket_format:e.ticket_format,ticket_issuer_ed25519_pub:e.ticket_issuer_ed25519_pub,ticket_max_ttl_seconds:e.ticket_max_ttl_seconds,lookup_protocol:e.lookup_protocol,privacy_mode:e.privacy_mode,directory_backend:e.directory_backend,host_enclave_protocol_version:e.host_enclave_protocol_version,host_release_id:e.host_release_id,enclave_release_id:e.enclave_release_id,match_result_format:e.match_result_format,oprf_suite:e.oprf_suite,evaluation_proof_mode:e.evaluation_proof_mode,oprf_public_key_ristretto255:e.oprf_public_key_ristretto255,signed_at:e.signed_at,expires_at:e.expires_at})),l=W(e.manifest_signature_ed25519),h=W(s);if(!ke.verify(l,d,h))throw new Error("Contact discovery manifest signature verification failed")}function Sa(e){return Le(ce(q(JSON.stringify({service:e.service,protocol_version:e.protocol_version,attestation_mode:e.attestation_mode,attestation_verifier:e.attestation_verifier??null,enclave_measurement_hex:e.enclave_measurement_hex??null,attestation_pcrs_sha384:Un(e.attestation_pcrs_sha384),attestation_document_format:e.attestation_document_format??null,attestation_document_sha256:e.attestation_document_sha256??null,attestation_challenge_mode:e.attestation_challenge_mode??null,ticket_format:e.ticket_format,ticket_issuer_ed25519_pub:e.ticket_issuer_ed25519_pub,ticket_max_ttl_seconds:e.ticket_max_ttl_seconds,lookup_protocol:e.lookup_protocol,privacy_mode:e.privacy_mode,directory_backend:e.directory_backend,host_enclave_protocol_version:e.host_enclave_protocol_version,host_release_id:e.host_release_id,enclave_release_id:e.enclave_release_id,match_result_format:e.match_result_format,oprf_suite:e.oprf_suite,evaluation_proof_mode:e.evaluation_proof_mode,oprf_public_key_ristretto255:e.oprf_public_key_ristretto255}))))}function Ep(e,t,s,n,r,a,i,o,c,d,l,h,u){if(e.challenge_nonce_base64!==i)throw new Error("Contact discovery attestation challenge nonce mismatch");const f=q(JSON.stringify({attestation_mode:e.attestation_mode,attestation_verifier:e.attestation_verifier,enclave_measurement_hex:e.enclave_measurement_hex,attested_pcrs_sha384:Un(e.attested_pcrs_sha384),directory_backend:e.directory_backend,host_enclave_protocol_version:e.host_enclave_protocol_version,host_release_id:e.host_release_id,enclave_release_id:e.enclave_release_id,manifest_contract_sha256:e.manifest_contract_sha256,attested_oprf_public_key_ristretto255:e.attested_oprf_public_key_ristretto255,document_format:e.document_format,document_base64:e.document_base64,document_sha256:e.document_sha256,published_at:e.published_at,challenge_nonce_base64:e.challenge_nonce_base64})),m=W(e.attestation_signature_ed25519),w=W(a);if(!ke.verify(m,f,w))throw new Error("Contact discovery attestation signature verification failed");if(e.attestation_mode!==t)throw new Error("Contact discovery attestation mode mismatch");if(e.attestation_verifier!==s)throw new Error("Contact discovery attestation verifier mismatch");if(e.enclave_measurement_hex!==n)throw new Error("Contact discovery attestation measurement mismatch");if(r&&!Vo(e.attested_pcrs_sha384,r))throw new Error("Contact discovery attestation PCR set mismatch");if(e.host_release_id!==c)throw new Error("Contact discovery attestation host release mismatch");if(e.manifest_contract_sha256!==o)throw new Error("Contact discovery attestation manifest contract mismatch");if(e.enclave_release_id!==d)throw new Error("Contact discovery attestation enclave release mismatch");if(e.attested_oprf_public_key_ristretto255!==l)throw new Error("Contact discovery attestation OPRF public key mismatch");if(e.directory_backend!=="attested_enclave_directory_v1")throw new Error("Unsupported contact discovery backend");if(e.host_enclave_protocol_version!==1)throw new Error("Unsupported contact discovery host/enclave protocol version");if(e.document_format!=="opaque_b64_v1")throw new Error("Unsupported contact discovery attestation document format");if(e.document_sha256!==h)throw new Error("Contact discovery attestation document hash mismatch");const x=W(e.document_base64);if(Le(ce(x))!==h.toLowerCase())throw new Error("Contact discovery attestation document integrity check failed");if(!Number.isFinite(u)||u<=0)throw new Error("Contact discovery attestation max age is invalid");const y=Date.parse(e.published_at);if(!Number.isFinite(y))throw new Error("Contact discovery attestation published_at is invalid");const k=Date.now();if(y>k+300*1e3)throw new Error("Contact discovery attestation published_at is in the future");if(k-y>u*1e3)throw new Error("Contact discovery attestation document is stale")}function Cp(){return C(Q(16))}function Un(e){if(!e)return null;const t=Object.entries(e).sort(([s],[n])=>s.localeCompare(n));return t.length?Object.fromEntries(t):null}function Vo(e,t){return JSON.stringify(Un(e))===JSON.stringify(Un(t))}function Ap(e,t,s,n,r){return Ia(ce(Kt([q("pqmsg-discovery-dleq-proof-v1"),Fe.Point.BASE.toBytes(),e.toBytes(),t.toBytes(),s.toBytes(),n.toBytes(),r.toBytes()])))}function Ia(e){let t=0n;for(let s=e.length-1;s>=0;s-=1)t=(t<<8n)+BigInt(e[s]);return Fe.Point.Fn.create(t)}function $p(e){const t=e.trim().toLowerCase();if(t.length!==64||!/^[0-9a-f]+$/.test(t))throw new Error("Discovery values must be 64-character SHA-256 hex strings");const s=new Uint8Array(32);for(let n=0;n<t.length;n+=2)s[n/2]=Number.parseInt(t.slice(n,n+2),16);return s}function Tp(e){const t=$l(Kt([q("pqmsg-discovery-handle-v1"),$p(e)]));return Fe.Point.hashToCurve(t)}function da(e){const t=[],s=[];for(const n of e){const r=Tp(n),a=Al.hashToScalar(Q(32),{DST:"pqmsg-discovery-blind-scalar-v1"}),i=r.multiply(a);t.push(C(i.toBytes())),s.push(C(Fe.Point.Fn.toBytes(a)))}return{blindedElementsBase64:t,blindingScalarsBase64:s}}function la(e,t){if(e.length!==t.length)throw new Error("Discovery evaluation result count mismatch");return t.map((s,n)=>{const r=Fe.Point.fromBytes(W(s)),a=Fe.Point.Fn.fromBytes(W(e[n])),i=r.multiply(Fe.Point.Fn.inv(a));return Le(ce(Kt([q("pqmsg-discovery-finalize-v1"),i.toBytes()])))})}function ua(e,t,s){if(t.evaluation_proof_mode!=="dleq_per_element_v1")throw new Error("Unsupported contact discovery evaluation proof mode");if(e.length!==t.evaluated_elements_base64.length||e.length!==t.dleq_proofs.length)throw new Error("Contact discovery evaluation proof count mismatch");const n=Fe.Point.fromBytes(W(s));for(let r=0;r<e.length;r+=1){const a=Fe.Point.fromBytes(W(e[r])),i=Fe.Point.fromBytes(W(t.evaluated_elements_base64[r])),o=t.dleq_proofs[r],c=Ia(W(o.challenge_scalar_base64)),d=Ia(W(o.response_scalar_base64)),l=Fe.Point.fromBytes(W(o.commitment_base_base64)),h=Fe.Point.fromBytes(W(o.commitment_blinded_base64)),u=Ap(n,a,i,l,h);if(C(Fe.Point.Fn.toBytes(c))!==C(Fe.Point.Fn.toBytes(u)))throw new Error("Contact discovery DLEQ challenge mismatch");const f=Fe.Point.BASE.multiply(d),m=l.add(n.multiply(c)),w=a.multiply(d),x=h.add(i.multiply(c));if(C(f.toBytes())!==C(m.toBytes()))throw new Error("Contact discovery DLEQ base equation failed");if(C(w.toBytes())!==C(x.toBytes()))throw new Error("Contact discovery DLEQ blinded equation failed")}}function Cs(e,t){const s=t?Kt([W(e),W(t)]):W(e);return Le(ce(s))}function Oi(e,t,s){return Oa([{ty:Lu,value:Ll(e)},{ty:Pu,value:t},{ty:Mu,value:s}])}function ne(e,t,s,n,r){return[{ty:Yl,value:q(e)},{ty:Jl,value:q(t)},{ty:Xl,value:q(s)},{ty:Zl,value:Ga(n)},{ty:Ql,value:q(r)}]}function Lp(e,t,s,n,r,a,i){return Oa([{ty:Bu,value:q(e)},{ty:Uu,value:q(t)},{ty:qu,value:s},{ty:Du,value:n},{ty:Ru,value:r},{ty:Hu,value:a},{ty:Nu,value:q(i)}])}function re(e,t,s,n){const r=Oa(n),a=W(e.identitySigSecret),i=ke.sign(r,a);return{"x-pqmsg-auth-user":e.userId,"x-pqmsg-auth-device":e.deviceId,"x-pqmsg-auth-timestamp":String(t),"x-pqmsg-auth-nonce":s,"x-pqmsg-auth-signature":C(i)}}async function zo(e,t){if(!e.trim())throw new Error("passphrase is empty");const s=await crypto.subtle.importKey("raw",q(e).buffer,"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t.buffer,iterations:Ou,hash:"SHA-256"},s,{name:"AES-GCM",length:256},!1,["encrypt","decrypt"])}function te(){return Math.floor(Date.now()/1e3)}const Pp=new Set(["localhost","127.0.0.1","::1","[::1]"]);function Or(e){return Pp.has(e.trim().toLowerCase())}function Yo(e){return e.protocol==="https:"||Or(e.hostname)}function Mp(e){return Yo(e.pageUrl)?e.hasSecureContext?e.hasIndexedDb?e.hasCryptoSubtle?e.hasWebAssembly?e.hasTextEncoding?!Or(e.pageUrl.hostname)&&!e.hasCrossOriginIsolation?"Secure web messaging requires cross-origin isolation (COOP/COEP) on the hosted web origin.":null:"Secure web messaging requires TextEncoder/TextDecoder support.":"Secure web messaging requires WebAssembly support.":"Secure web messaging requires SubtleCrypto support.":"Secure web messaging requires IndexedDB for encrypted local storage.":"Secure web messaging requires a secure browser context.":"Secure web messaging requires HTTPS or localhost during development."}function Jo(){var e;return Mp({pageUrl:window.location,hasSecureContext:window.isSecureContext===!0,hasCrossOriginIsolation:window.crossOriginIsolated===!0,hasIndexedDb:typeof window.indexedDB<"u"&&window.indexedDB!==null,hasCryptoSubtle:typeof window.crypto<"u"&&!!((e=window.crypto)!=null&&e.subtle),hasWebAssembly:typeof WebAssembly<"u",hasTextEncoding:typeof TextEncoder<"u"&&typeof TextDecoder<"u"})}function pt(e){const t=e.trim();if(!t)throw new Error("Server URL is empty.");let s;try{s=new URL(t)}catch{throw new Error("Server URL must be a valid absolute URL.")}if(s.username||s.password)throw new Error("Server URL must not include embedded credentials.");if(s.protocol==="https:"||s.protocol==="http:"&&Or(s.hostname))return s;throw new Error("Secure web messaging requires an HTTPS server URL or loopback HTTP during development.")}class gs extends Error{constructor(s,n){const r=Bp(n);super(r?`HTTP ${s}: ${r}`:`HTTP ${s}`);bt(this,"status");bt(this,"detail");this.name="PqmsgApiError",this.status=s,this.detail=r}}class j{constructor(t){bt(this,"baseUrl");const s=t.trim().replace(/\/+$/,"");if(!s)throw new Error("server URL is empty");pt(s),this.baseUrl=s}async pingRoot(){await this.request("GET","/",void 0,{})}async getCapabilities(){return this.request("GET","/v1/capabilities",void 0,{})}async getTransparencyProof(t,s){const n=s&&s>0?`?previous_tree_size=${encodeURIComponent(String(s))}`:"";return this.request("GET",`/v1/transparency/users/${encodeURIComponent(t)}/proof${n}`,void 0,{})}async registerUser(t){return this.request("POST","/v1/users/register",t,{})}async resetDevUserIdentity(t){await this.request("POST",`/v1/dev/users/${encodeURIComponent(t)}/reset`,void 0,{})}async publishPrekeys(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/prekeys`,s,n)}async getBundle(t){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/bundle`,void 0,{})}async relay(t,s,n){return this.request("POST",`/v1/relay/${encodeURIComponent(t)}`,s,n)}async inbox(t,s,n){return this.request("GET",`/v1/inbox/${encodeURIComponent(t)}?since=${encodeURIComponent(String(s))}`,void 0,n)}async listDevices(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/devices`,void 0,s)}async linkDevice(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/devices/link`,{new_device_id:s},n)}async revokeDevice(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/devices/${encodeURIComponent(s)}/revoke`,void 0,n)}async retireCurrentDevice(t,s){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/devices/current/retire`,void 0,s)}async getProfile(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/profile`,void 0,s)}async upsertProfile(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/profile`,s,n)}async resolveUsername(t){const s=t.trim().replace(/^@/,"");return this.request("GET",`/v1/usernames/${encodeURIComponent(s)}`,void 0,{})}async getUsernameBundle(t){const s=t.trim().replace(/^@/,"");return this.request("GET",`/v1/usernames/${encodeURIComponent(s)}/bundle`,void 0,{})}async getPresence(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/presence`,void 0,s)}async updatePresence(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/presence`,s,n)}async getTyping(t,s){return this.request("GET",`/v1/typing/${encodeURIComponent(t)}`,void 0,s)}async updateTyping(t,s,n){await this.request("POST",`/v1/typing/${encodeURIComponent(t)}`,s,n)}async sendReceipt(t,s,n){await this.request("POST",`/v1/users/${encodeURIComponent(t)}/receipts`,s,n)}async getReceipts(t,s,n){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/receipts/poll?since_id=${encodeURIComponent(String(s))}`,void 0,n)}async createInboxWsTicket(t,s,n){return this.request("POST",`/v1/ws/inbox/${encodeURIComponent(t)}/ticket?since=${encodeURIComponent(String(s))}`,void 0,n)}async createSealedInboxWsTicket(t,s,n){return this.request("POST",`/v1/ws/sealed-inbox/${encodeURIComponent(t)}/ticket?since=${encodeURIComponent(String(s))}`,void 0,n)}async listContacts(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/contacts`,void 0,s)}async upsertContact(t,s,n){await this.request("POST",`/v1/users/${encodeURIComponent(t)}/contacts`,s,n)}async removeContact(t,s,n){await this.request("POST",`/v1/users/${encodeURIComponent(t)}/contacts/remove`,s,n)}async createContactInvite(t,s){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/contact-invites`,void 0,s)}async resolveContactInvite(t){return this.request("GET",`/v1/contact-invites/${encodeURIComponent(t)}`,void 0,{})}async getContactInviteBundle(t){return this.request("GET",`/v1/contact-invites/${encodeURIComponent(t)}/bundle`,void 0,{})}async publishPrivateGroupState(t){return this.request("POST","/v1/private-groups/state/publish",t,{})}async fetchPrivateGroupState(t){return this.request("POST","/v1/private-groups/state/fetch",t,{})}async createPrivateGroupInvite(t){return this.request("POST","/v1/private-groups/invites",t,{})}async resolvePrivateGroupInvite(t){return this.request("GET",`/v1/private-groups/invites/${encodeURIComponent(t)}`,void 0,{})}async consumePrivateGroupInvite(t){return this.request("POST",`/v1/private-groups/invites/${encodeURIComponent(t)}`,void 0,{})}async publishPrivateGroupMessage(t){return this.request("POST","/v1/private-groups/messages/publish",t,{})}async fetchPrivateGroupMessages(t){return this.request("POST","/v1/private-groups/messages/fetch",t,{})}async createGroup(t,s){return this.request("POST","/v1/groups",t,s)}async listUserGroups(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/groups`,void 0,s)}async listGroupMembers(t,s){return this.request("GET",`/v1/groups/${encodeURIComponent(t)}/members`,void 0,s)}async addGroupMember(t,s,n){return this.request("POST",`/v1/groups/${encodeURIComponent(t)}/members/add`,s,n)}async removeGroupMember(t,s,n){return this.request("POST",`/v1/groups/${encodeURIComponent(t)}/members/remove`,s,n)}async relayGroupMessage(t,s,n){return this.request("POST",`/v1/groups/${encodeURIComponent(t)}/relay`,s,n)}async uploadFile(t,s){return this.request("POST","/v1/files/upload",t,s)}async downloadFile(t,s){return this.request("GET",`/v1/files/${encodeURIComponent(t)}`,void 0,s)}async deleteInboxMessages(t,s,n){return this.request("POST",`/v1/inbox/${encodeURIComponent(t)}/delete`,s,n)}async getPrekeysStatus(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/prekeys/status`,void 0,s)}async rotateInit(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/rotate/init`,s,n)}async rotateConfirm(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/rotate/confirm`,s,n)}async getIdentityLog(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/identity-log`,void 0,s)}async sealedRelay(t,s){return this.request("POST",`/v1/sealed-relay/${encodeURIComponent(t)}`,s,{})}async sealedInbox(t,s,n){return this.request("GET",`/v1/sealed-inbox/${encodeURIComponent(t)}?since=${encodeURIComponent(String(s))}`,void 0,n)}async getSenderCertificate(t,s){return this.request("GET",`/v1/users/${encodeURIComponent(t)}/sender-certificate`,void 0,s)}async anonBundle(t){return this.request("GET",`/v1/anon/users/${encodeURIComponent(t)}/bundle`,void 0,{})}async relayEphemeral(t,s,n){return this.request("POST",`/v1/ephemeral-relay/${encodeURIComponent(t)}`,s,n)}async uploadDiscoveryHandles(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/discovery/handles`,s,n)}async discoveryMatch(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/discovery/match`,s,n)}async issueContactDiscoveryTicket(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/contact-discovery/ticket`,n,s)}async getContactDiscoveryManifest(t){const n=`${pt(t).origin}`,r=await fetch(`${n}/v1/manifest`,{method:"GET",headers:{Accept:"application/json"}});if(!r.ok)throw new gs(r.status,await r.text());return r.json()}async getContactDiscoveryAttestation(t,s){const r=`${pt(t).origin}`,a=new URL(`${r}/v1/attestation`);a.searchParams.set("nonce_b64",s);const i=await fetch(a.toString(),{method:"GET",headers:{Accept:"application/json"}});if(!i.ok)throw new gs(i.status,await i.text());return i.json()}async evaluateDiscoveryElementsAtService(t,s){const r=`${pt(t).origin}`,a=await fetch(`${r}/v1/discovery/evaluate`,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify(s)});if(!a.ok)throw new gs(a.status,await a.text());return a.json()}async uploadDiscoveryHandlesToService(t,s){const r=`${pt(t).origin}`,a=await fetch(`${r}/v1/discovery/handles`,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify(s)});if(!a.ok)throw new gs(a.status,await a.text());return a.json()}async matchDiscoveryHashesAtService(t,s){const r=`${pt(t).origin}`,a=await fetch(`${r}/v1/discovery/match`,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify(s)});if(!a.ok)throw new gs(a.status,await a.text());return a.json()}async registerPushToken(t,s,n){return this.request("POST",`/v1/users/${encodeURIComponent(t)}/push-token`,s,n)}async callOffer(t,s,n){return this.request("POST",`/v1/calls/${encodeURIComponent(t)}/offer`,s,n)}async callAnswer(t,s,n){return this.request("POST",`/v1/calls/${encodeURIComponent(t)}/answer`,s,n)}async callIceCandidate(t,s,n){return this.request("POST",`/v1/calls/${encodeURIComponent(t)}/ice`,s,n)}async callHangup(t,s,n){return this.request("POST",`/v1/calls/${encodeURIComponent(t)}/hangup`,s,n)}async pollCallSignals(t,s,n){return this.request("GET",`/v1/calls/${encodeURIComponent(t)}/signals?since=${encodeURIComponent(String(s))}`,void 0,n)}async getHealth(){return this.request("GET","/health",void 0,{})}async getMetrics(){const t=`${this.baseUrl}/metrics`,s=await fetch(t);if(!s.ok)throw new gs(s.status,await s.text());return s.text()}async request(t,s,n,r){const a=`${this.baseUrl}${s}`,i=new Headers(r);i.set("accept","application/json"),n!==void 0&&i.set("content-type","application/json");const o=await fetch(a,{method:t,headers:i,body:n===void 0?void 0:JSON.stringify(n)});if(!o.ok)throw new gs(o.status,await o.text());if(o.status!==204)return await o.json()}}function Bp(e){return e.replace(/<[^>]*>/g," ").replace(/[\u0000-\u001f\u007f]+/g," ").replace(/\s+/g," ").trim().slice(0,280)}const Up="pqmsg-web",qp=6,ye="messages",hs="outbox",$t="sessions",vs="metadata",Tt="keys";function Dp(e){var i,o,c;const t=new Set,s=e.text.trim();s&&t.add(s);const n=((i=e.fileName)==null?void 0:i.trim())||"",r=((o=e.mimeType)==null?void 0:o.trim())||"",a=((c=e.attachmentNoteText)==null?void 0:c.trim())||"";return n&&t.add(n),r&&(t.add(r),r.startsWith("image/")&&t.add("photo"),r.startsWith("video/")&&t.add("video"),r.startsWith("audio/")&&t.add("audio"),r==="application/pdf"&&t.add("pdf"),!r.startsWith("image/")&&!r.startsWith("video/")&&!r.startsWith("audio/")&&r!=="application/pdf"&&t.add("document")),a&&t.add(a),Array.from(t).join(`
`)}let hr=null;function pe(){return hr?Promise.resolve(hr):new Promise((e,t)=>{const s=indexedDB.open(Up,qp);s.onupgradeneeded=n=>{const r=s.result;if(!r.objectStoreNames.contains(ye)){const a=r.createObjectStore(ye,{keyPath:"id"});a.createIndex("by_conversation","conversationId",{unique:!1}),a.createIndex("by_timestamp",["conversationId","timestamp"],{unique:!1})}r.objectStoreNames.contains(hs)||r.createObjectStore(hs,{keyPath:"id"}),r.objectStoreNames.contains($t)||r.createObjectStore($t,{keyPath:"id"}).createIndex("by_user","userId",{unique:!1}),r.objectStoreNames.contains(vs)||r.createObjectStore(vs,{keyPath:"id"}),r.objectStoreNames.contains(Tt)||r.createObjectStore(Tt,{keyPath:"id"})},s.onsuccess=()=>{hr=s.result,e(hr)},s.onerror=()=>t(s.error)})}async function Ys(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction(ye,"readwrite");r.objectStore(ye).put(e),r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function kn(e,t,s){const n=await pe();return new Promise((r,a)=>{const i=n.transaction(ye,"readwrite"),o=i.objectStore(ye),c=o.get(e);c.onsuccess=()=>{const d=c.result;d&&(d.status=t,o.put(d))},i.oncomplete=()=>r(),i.onerror=()=>a(i.error)})}async function ze(e){const t=await pe();return new Promise((s,n)=>{const i=t.transaction(ye,"readonly").objectStore(ye).index("by_conversation").getAll(e);i.onsuccess=()=>{const o=i.result.sort((c,d)=>c.timestamp-d.timestamp);s(o)},i.onerror=()=>n(i.error)})}async function Xo(e){if(e.length===0)return;const t=await pe();return new Promise((s,n)=>{const r=t.transaction(ye,"readwrite"),a=r.objectStore(ye);for(const i of e)a.delete(i);r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function Rp(){const e=await pe();return new Promise((t,s)=>{const n=e.transaction(ye,"readwrite");n.objectStore(ye).clear(),n.oncomplete=()=>t(),n.onerror=()=>s(n.error)})}async function Np(e){const t=await pe(),s=e.toLowerCase();return new Promise((n,r)=>{const a=t.transaction(ye,"readonly"),i=a.objectStore(ye),o=[],c=i.openCursor();c.onsuccess=()=>{const d=c.result;if(d){const l=d.value;Dp(l).toLowerCase().includes(s)&&o.push(l),d.continue()}},a.oncomplete=()=>{o.sort((d,l)=>l.timestamp-d.timestamp),n(o)},a.onerror=()=>r(a.error)})}async function Gi(e){const t=await pe();return new Promise((s,n)=>{const a=t.transaction(hs,"readonly").objectStore(hs).getAll();a.onsuccess=()=>{const i=a.result;s(e?i.filter(o=>o.userId===e):i)},a.onerror=()=>n(a.error)})}async function pa(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction(hs,"readwrite");r.objectStore(hs).delete(e),r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function Hp(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction(hs,"readwrite"),a=r.objectStore(hs);if(!e)a.clear();else{const i=a.openCursor();i.onsuccess=()=>{const o=i.result;o&&(o.value.userId===e&&o.delete(),o.continue())},i.onerror=()=>n(i.error)}r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function Op(e,t,s){const n=await pe(),r={id:`${e}:${t}`,userId:e,peerId:t,sealedSession:s,updatedAt:Date.now()};return new Promise((a,i)=>{const o=n.transaction($t,"readwrite");o.objectStore($t).put(r),o.oncomplete=()=>a(),o.onerror=()=>i(o.error)})}async function Gp(e,t){const s=await pe();return new Promise((n,r)=>{const i=s.transaction($t,"readonly").objectStore($t).get(`${e}:${t}`);i.onsuccess=()=>{const o=i.result;n((o==null?void 0:o.sealedSession)??null)},i.onerror=()=>r(i.error)})}async function jp(e,t){const s=await pe();return new Promise((n,r)=>{const a=s.transaction($t,"readwrite");a.objectStore($t).delete(`${e}:${t}`),a.oncomplete=()=>n(),a.onerror=()=>r(a.error)})}async function Wp(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction($t,"readwrite"),a=r.objectStore($t);if(!e)a.clear();else{const o=a.index("by_user").openCursor(e);o.onsuccess=()=>{const c=o.result;c&&(c.delete(),c.continue())},o.onerror=()=>n(o.error)}r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function Kp(e,t){const s=await pe(),n={id:e,rawJson:t,updatedAt:Date.now()};return new Promise((r,a)=>{const i=s.transaction(vs,"readwrite");i.objectStore(vs).put(n),i.oncomplete=()=>r(),i.onerror=()=>a(i.error)})}async function Fp(e){const t=await pe();return new Promise((s,n)=>{const a=t.transaction(vs,"readonly").objectStore(vs).get(e);a.onsuccess=()=>{const i=a.result;s((i==null?void 0:i.rawJson)??null)},a.onerror=()=>n(a.error)})}async function Vp(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction(vs,"readwrite");r.objectStore(vs).delete(e),r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function zp(e,t){const s=await pe(),n={id:e,sealedKeys:t,updatedAt:Date.now()};return new Promise((r,a)=>{const i=s.transaction(Tt,"readwrite");i.objectStore(Tt).put(n),i.oncomplete=()=>r(),i.onerror=()=>a(i.error)})}async function Yp(e){const t=await pe();return new Promise((s,n)=>{const a=t.transaction(Tt,"readonly").objectStore(Tt).get(e);a.onsuccess=()=>{const i=a.result;s((i==null?void 0:i.sealedKeys)??null)},a.onerror=()=>n(a.error)})}async function Jp(){const e=await pe();return new Promise((t,s)=>{const r=e.transaction(Tt,"readonly").objectStore(Tt).getAllKeys();r.onsuccess=()=>{t(r.result.map(a=>String(a)))},r.onerror=()=>s(r.error)})}async function Xp(e){const t=await pe();return new Promise((s,n)=>{const r=t.transaction(Tt,"readwrite");r.objectStore(Tt).delete(e),r.oncomplete=()=>s(),r.onerror=()=>n(r.error)})}async function ji(e,t,s){const n=await pe();return new Promise((r,a)=>{const i=n.transaction(ye,"readwrite"),o=i.objectStore(ye),c=o.get(e);c.onsuccess=()=>{const d=c.result;if(!d){r(null);return}const l=d.reactions??[],h=l.findIndex(u=>u.emoji===t&&u.sender===s);h>=0?l.splice(h,1):l.push({emoji:t,sender:s}),d.reactions=l,o.put(d),i.oncomplete=()=>r(d)},i.onerror=()=>a(i.error)})}async function Zp(e,t){const s=await pe();return new Promise((n,r)=>{const a=s.transaction(ye,"readwrite"),i=a.objectStore(ye),o=i.get(e);o.onsuccess=()=>{const c=o.result;if(!c){n(null);return}c.text=t,(c.fileId||c.attachmentDataBase64)&&(c.attachmentNoteText=t),c.editedAt=Date.now(),i.put(c),a.oncomplete=()=>n(c)},a.onerror=()=>r(a.error)})}async function ys(e){const t=await pe();return new Promise((s,n)=>{const a=t.transaction(ye,"readonly").objectStore(ye).get(e);a.onsuccess=()=>s(a.result??null),a.onerror=()=>n(a.error)})}const Ka="pqmsg.web.setup.v1",Lt="pqmsg.web.conversations.v1",Pt="pqmsg.web.groupconvos.v1",Js="pqmsg.web.privategroups.v1",_s="pqmsg.web.conversationmeta.v1",ds="pqmsg.web.profilecache.v1",Xs="pqmsg.web.pins.v1",Zs="pqmsg.web.cursors.v1",Qs="pqmsg.web.privategroupcursors.v1",en="pqmsg.web.transparency.v1",tn="pqmsg.web.contactdiscovery.v1",Fa="pqmsg.web.threadtips.v1",js="pqmsg.web.threaddrafts.v1",Qp=[Ka,Lt,Pt,Js,_s,ds,Xs,Zs,Qs,en,tn,Fa,js],Ir=new Map,sn=new Set,Ke={serverUrl:"http://127.0.0.1:3000",userId:"",deviceId:"",suiteLabel:"ml-kem-768",peerUserId:"bob",displayName:"",username:"",usernameLookupEnabled:!1};async function eh(){for(const e of Qp)Ir.set(e,await Fp(e));sn.clear();for(const e of await Jp()){const t=e.trim();t&&sn.add(t)}}function th(){const e=lc(Ka);if(!e)return Ke;try{const t=JSON.parse(e);return{serverUrl:typeof t.serverUrl=="string"?t.serverUrl:Ke.serverUrl,userId:typeof t.userId=="string"?t.userId:Ke.userId,deviceId:typeof t.deviceId=="string"?t.deviceId:Ke.deviceId,suiteLabel:t.suiteLabel==="kyber768"||t.suiteLabel==="ml-kem-768"?t.suiteLabel:Ke.suiteLabel,peerUserId:typeof t.peerUserId=="string"?t.peerUserId:Ke.peerUserId,displayName:typeof t.displayName=="string"?t.displayName:Ke.displayName,username:typeof t.username=="string"?t.username:Ke.username,usernameLookupEnabled:typeof t.usernameLookupEnabled=="boolean"?t.usernameLookupEnabled:Ke.usernameLookupEnabled}}catch{return Ke}}function Mt(e){ee(Ka,e)}function Zo(){return Y(Fa,!1)}function Qo(){ee(Fa,!0)}function Er(e,t,s){var r;return((r=Y(js,[]).find(a=>a.userId===e&&a.kind===t&&a.threadId===s))==null?void 0:r.text)??""}function Wi(e,t,s){var r;return((r=Y(js,[]).find(a=>a.userId===e&&a.kind===t&&a.threadId===s))==null?void 0:r.updatedAt)??0}function ec(e,t,s,n){const r=Y(js,[]),a=r.findIndex(c=>c.userId===e&&c.kind===t&&c.threadId===s),i=n.trimEnd();if(!i){a>=0&&(r.splice(a,1),ee(js,r));return}const o={userId:e,kind:t,threadId:s,text:i,updatedAt:Date.now()};a>=0?r[a]=o:r.push(o),ee(js,r)}async function Gr(e,t,s){const n=await Go(s,t);await zp(e,n),sn.add(e.trim())}async function tc(e,t){const s=await Yp(e);if(!s)throw new Error(`missing keys for user '${e}'`);return jo(s,t)}function Kn(e){const t=e.trim();return t?sn.has(t):!1}function sc(){return[...sn].sort((e,t)=>e.localeCompare(t))}async function sh(e,t,s,n){const r=await Go(n,s);await Op(e,t,r)}async function nh(e,t,s){const n=await Gp(e,t);return n?jo(n,s):null}async function rh(e,t){await jp(e,t)}async function nc(e){const t=e.trim();t&&await Wp(t)}function Va(e){return Y(Lt,[]).filter(n=>n.peerUserId&&n.userId===e).map(n=>({peerUserId:n.peerUserId,lastPreview:n.lastPreview,unreadCount:n.unreadCount,updatedAt:n.updatedAt})).sort((n,r)=>r.updatedAt-n.updatedAt)}function as(e,t,s,n,r=Date.now()){const a=Y(Lt,[]),i=r,o=s.trim().slice(0,160)||"No content",c=a.findIndex(d=>d.userId===e&&d.peerUserId===t);if(c>=0){const d=a[c];d.lastPreview=o,d.updatedAt=i,n&&(d.unreadCount+=1)}else a.push({userId:e,peerUserId:t,lastPreview:o,unreadCount:n?1:0,updatedAt:i});ee(Lt,a)}function jt(e,t){const s=Y(Lt,[]),n=s.findIndex(r=>r.userId===e&&r.peerUserId===t);n>=0&&(s[n].unreadCount=0,ee(Lt,s))}function ah(e,t,s){const n=Y(Lt,[]),r=n.findIndex(a=>a.userId===e&&a.peerUserId===t);r>=0&&(n[r].unreadCount=Math.max(0,s),ee(Lt,n))}function Fn(e,t,s){const r=Y(_s,[]).find(a=>a.userId===e&&a.kind===t&&a.threadId===s);return r?{kind:r.kind,threadId:r.threadId,requestState:r.requestState,pinnedAt:r.pinnedAt,archivedAt:r.archivedAt,sealedSenderDefault:r.sealedSenderDefault,ephemeralTtlDefault:r.ephemeralTtlDefault}:uc(t,s)}function ih(e){return Y(_s,[]).filter(t=>t.userId===e).map(t=>({kind:t.kind,threadId:t.threadId,requestState:t.requestState,pinnedAt:t.pinnedAt,archivedAt:t.archivedAt,sealedSenderDefault:t.sealedSenderDefault,ephemeralTtlDefault:t.ephemeralTtlDefault})).sort((t,s)=>{const n=t.pinnedAt??0,r=s.pinnedAt??0;return n!==r?r-n:t.threadId.localeCompare(s.threadId)})}function Vn(e,t,s,n){const r=Y(_s,[]),a=r.findIndex(c=>c.userId===e&&c.kind===t&&c.threadId===s),o={...a>=0?r[a]:{userId:e,...uc(t,s)},...n,userId:e,kind:t,threadId:s};return a>=0?r[a]=o:r.push(o),ee(_s,r),{kind:o.kind,threadId:o.threadId,requestState:o.requestState,pinnedAt:o.pinnedAt,archivedAt:o.archivedAt,sealedSenderDefault:o.sealedSenderDefault,ephemeralTtlDefault:o.ephemeralTtlDefault}}function rc(e,t){const n=Y(ds,[]).find(r=>r.userId===e&&r.targetUserId===t);return(n==null?void 0:n.displayName)??null}function on(e,t,s){const n=Y(ds,[]),r=n.findIndex(o=>o.userId===e&&o.targetUserId===t),a=s.trim();if(!a){r>=0&&(n.splice(r,1),ee(ds,n));return}const i={userId:e,targetUserId:t,displayName:a,updatedAt:Date.now()};r>=0?n[r]=i:n.push(i),ee(ds,n)}function ac(e){return Y(ds,[]).filter(t=>t.userId===e).map(t=>({targetUserId:t.targetUserId,displayName:t.displayName,updatedAt:t.updatedAt})).sort((t,s)=>t.targetUserId.localeCompare(s.targetUserId))}function oh(e,t){const s=Y(Zs,{}),n=t?`${e}:${t}`:e;return Number(s[n]??0)}function ic(e,t,s){const n=Y(Zs,{}),r=s?`${e}:${s}`:e;n[r]=t,ee(Zs,n)}function xn(e,t){const s=t?`sealed:${t}`:"sealed";return oh(e,s)}function Sn(e,t,s){const n=s?`sealed:${s}`:"sealed";ic(e,t,n)}function jr(e,t){return Y(en,{})[`${e.trim()}::${t.trim()}`]??null}function oc(e,t,s){const n=Y(en,{});n[`${e.trim()}::${t.trim()}`]=s,ee(en,n)}function ch(e,t){return Y(tn,{})[`${e.trim()}::${t.trim()}`]??null}function dh(e,t,s){const n=Y(tn,{});n[`${e.trim()}::${t.trim()}`]=s,ee(tn,n)}function xt(e,t){const n=Y(Xs,[]).find(r=>r.userId===e&&r.peerUserId===t);return n?{fingerprintSha256:n.fingerprintSha256,identityKeyVersion:n.identityKeyVersion,identityX25519Pub:n.identityX25519Pub,identitySigPub:n.identitySigPub,identityPqSigPub:typeof n.identityPqSigPub=="string"?n.identityPqSigPub:"",observedAt:n.observedAt}:null}function Ki(e,t,s){const n=Y(Xs,[]),r=n.findIndex(i=>i.userId===e&&i.peerUserId===t),a={userId:e,peerUserId:t,...s};r>=0?n[r]=a:n.push(a),ee(Xs,n)}function As(e){return Y(Pt,[]).filter(s=>s.userId===e).map(s=>({groupId:s.groupId,ownerUserId:s.ownerUserId,lastPreview:s.lastPreview,unreadCount:s.unreadCount,updatedAt:s.updatedAt})).sort((s,n)=>n.updatedAt-s.updatedAt)}function zn(e,t,s,n,r,a=Date.now()){const i=Y(Pt,[]),o=a,c=n.trim().slice(0,160)||"No content",d=i.findIndex(l=>l.userId===e&&l.groupId===t);d>=0?(i[d].lastPreview=c,i[d].updatedAt=o,r&&(i[d].unreadCount+=1)):i.push({userId:e,groupId:t,ownerUserId:s,lastPreview:c,unreadCount:r?1:0,updatedAt:o}),ee(Pt,i)}function Yn(e,t){const s=Y(Pt,[]),n=s.findIndex(r=>r.userId===e&&r.groupId===t);n>=0&&(s[n].unreadCount=0,ee(Pt,s))}function lh(e,t,s){const n=Y(Pt,[]),r=n.findIndex(a=>a.userId===e&&a.groupId===t);r>=0&&(n[r].unreadCount=Math.max(0,s),ee(Pt,n))}function cc(e){return Y(Js,[]).filter(s=>s.userId===e).map(s=>({groupId:s.groupId,stateJson:s.stateJson,memberCredentialJson:s.memberCredentialJson,stateCommitmentSha256:s.stateCommitmentSha256??null,updatedAt:s.updatedAt})).sort((s,n)=>n.updatedAt-s.updatedAt)}function uh(e,t){return!e.trim()||!t.trim()?null:cc(e).find(s=>s.groupId===t)??null}function ph(e,t,s,n,r){if(!e.trim()||!t.trim())return;const a=Y(Js,[]),i=a.findIndex(c=>c.userId===e&&c.groupId===t),o={userId:e,groupId:t,stateJson:s,memberCredentialJson:n,stateCommitmentSha256:(r==null?void 0:r.trim())||null,updatedAt:Date.now()};i>=0?a[i]=o:a.push(o),ee(Js,a)}function hh(e,t){var s;return!e.trim()||!t.trim()?0:((s=Y(Qs,[]).find(n=>n.userId===e&&n.groupId===t))==null?void 0:s.lastMessageId)??0}function dc(e,t,s){if(!e.trim()||!t.trim())return;const n=Y(Qs,[]),r=n.findIndex(i=>i.userId===e&&i.groupId===t),a={userId:e,groupId:t,lastMessageId:s};r>=0?n[r]=a:n.push(a),ee(Qs,n)}async function za(e){const t=e.trim();if(!t)return;await Xp(t),sn.delete(t);const s=Y(Lt,[]).filter(u=>u.userId!==t);ee(Lt,s);const n=Y(Pt,[]).filter(u=>u.userId!==t);ee(Pt,n);const r=Y(Js,[]).filter(u=>u.userId!==t);ee(Js,r);const a=Y(Qs,[]).filter(u=>u.userId!==t);ee(Qs,a);const i=Y(_s,[]).filter(u=>u.userId!==t);ee(_s,i);const o=Y(ds,[]).filter(u=>u.userId!==t);ee(ds,o);const c=Y(Xs,[]).filter(u=>u.userId!==t);ee(Xs,c);const d=Y(Zs,{});for(const u of Object.keys(d))(u===t||u.startsWith(`${t}:`))&&delete d[u];ee(Zs,d);const l=Y(en,{});for(const u of Object.keys(l))u.endsWith(`::${t}`)&&delete l[u];ee(en,l);const h=Y(tn,{});for(const u of Object.keys(h))u.endsWith(`::${t}`)&&delete h[u];ee(tn,h),await nc(t)}function Y(e,t){const s=lc(e);if(!s)return t;try{return JSON.parse(s)}catch{return t}}function ee(e,t){if(Array.isArray(t)&&t.length===0){ha(e,null);return}if(typeof t=="object"&&t!==null&&!Array.isArray(t)&&Object.keys(t).length===0){ha(e,null);return}ha(e,JSON.stringify(t))}function lc(e){return Ir.has(e)?Ir.get(e)??null:null}function ha(e,t){if(Ir.set(e,t),t===null){Vp(e).catch(()=>{});return}Kp(e,t).catch(()=>{})}function uc(e,t){return{kind:e,threadId:t,requestState:"accepted",pinnedAt:null,archivedAt:null,sealedSenderDefault:!1,ephemeralTtlDefault:0}}class vh{constructor(t,s){bt(this,"ws",null);bt(this,"listeners",[]);bt(this,"reconnectListeners",[]);bt(this,"reconnectTimer",null);bt(this,"intentionallyClosed",!1);bt(this,"serverUrl");bt(this,"keys");this.serverUrl=t,this.keys=s}onMessage(t){this.listeners.push(t)}onReconnect(t){this.reconnectListeners.push(t)}connect(){this.intentionallyClosed=!1,this.doConnect()}disconnect(){this.intentionallyClosed=!0,this.reconnectTimer&&(clearTimeout(this.reconnectTimer),this.reconnectTimer=null),this.ws&&(this.ws.close(),this.ws=null)}async doConnect(){if(this.intentionallyClosed)return;this.ws&&(this.ws.close(),this.ws=null);const t=xn(this.keys.userId,this.keys.deviceId),s=Oo(this.keys,t),n=new j(this.serverUrl);let r;try{r=(await n.createSealedInboxWsTicket(this.keys.userId,t,s)).ticket}catch(c){console.warn("[ws] failed to create inbox ticket",c),this.scheduleReconnect();return}const i=`${this.serverUrl.replace(/^http/,"ws")}/v1/ws/sealed-inbox/${encodeURIComponent(this.keys.userId)}?ticket=${encodeURIComponent(r)}`,o=new WebSocket(i);o.onopen=()=>{console.log("[ws] connected");for(const c of this.reconnectListeners)c()},o.onmessage=c=>{try{const d=JSON.parse(String(c.data));for(const l of d.messages??[])for(const h of this.listeners)h(l)}catch(d){console.warn("[ws] failed to parse message",d)}},o.onclose=()=>{console.log("[ws] disconnected"),this.ws=null,this.intentionallyClosed||this.scheduleReconnect()},o.onerror=()=>{},this.ws=o}scheduleReconnect(){this.reconnectTimer||(this.reconnectTimer=setTimeout(()=>{this.reconnectTimer=null,this.doConnect()},3e3))}}let pc={screen:"onboarding"},hc=[],vc=[],fh=1;function Jn(){return pc}function R(e){pc=e;for(const t of hc)t(e)}function mh(e){hc.push(e)}function D(e,t="info",s){const n={id:fh++,text:e,type:t,...s};for(const r of vc)r(n)}function gh(e){vc.push(e)}const yh="Web remains a demo surface until the server promotes the hardened web policy. direct messages require the hardened web policy, private groups require their own capability, and calling stays unavailable on web.";function $s(e){const t=e?`Server policy is ${e.web_client_policy}.`:"Server capabilities could not be verified.";return e?e.web_client_policy==="demo_only"?{directMessagingAllowed:!1,groupMessagingAllowed:!1,title:"Web messaging unavailable",detail:`${t} Direct web messaging and private groups stay disabled while the server remains in demo-only web mode. Calling stays out of scope for the supported web beta.`,tone:"warning"}:e.private_group_messaging_supported?{directMessagingAllowed:!0,groupMessagingAllowed:!0,title:"Hardened web messaging enabled",detail:`${t} Direct web messaging and private groups are enabled on the hardened web path when the local PQ runtime is available. Calling stays out of scope for the supported web beta.`,tone:"info"}:{directMessagingAllowed:!0,groupMessagingAllowed:!1,title:"Web private groups unavailable",detail:`${t} Direct web messaging can use the hardened PQ path, but private groups stay unavailable until the server advertises the private-group messaging capability. Calling stays out of scope for the supported web beta.`,tone:"warning"}:{directMessagingAllowed:!1,groupMessagingAllowed:!1,title:"Web messaging unavailable",detail:`${t} Direct web messaging still requires the local PQ runtime. Private groups and calling are not part of the supported web beta until the server advertises the hardened web policy.`,tone:"warning"}}function fc(e){return e.trim().replace(/^@/,"").toLowerCase()}function mc(e){var s;const t=e.trim();if(!t)return"";try{const r=(s=new URL(t).searchParams.get("invite"))==null?void 0:s.trim();if(r)return r}catch{}return t}function qn(e){var s,n;const t=e.trim();if(!t)return"";try{const r=new URL(t);return((s=r.searchParams.get("invite_token"))==null?void 0:s.trim())||((n=r.searchParams.get("token"))==null?void 0:n.trim())||""}catch{return""}}async function bh(e,t){const s=qn(e.rawTarget),n=s?(await t.resolveInviteToken(s)).replace(/^@/,""):(await t.resolvePeerTarget(e.rawTarget)).replace(/^@/,"");if(!n)throw new Error("User ID is required");if(n===e.currentUserId)throw new Error("You can't chat with yourself");return await t.ensureDirectChatPeerExists(n),await t.addContactSilent(n),t.markConversationAccepted(n),t.setConversationArchived("dm",n,!1),t.upsertConversation(e.currentUserId,n,"New conversation",!1),t.markConversationRead(e.currentUserId,n),n}const Ge=document.getElementById("app");let p=Ke,He=null,Ct=null,cn=null,Hs=null,vr=null,is=null,os=null,Gs=null,Cr=null,In=null,Fi=!1;const gc="pqmsg-media-v1";let En=null,Ws=null,mr=null,Cn=null,bn=0,ue=[],Je={},Dn={},Rn={},Xn={},At="all",ws=null,An=null,Et=0,$n=null,Ee=null,Tn=null;const Ea="pqmsg-private-group-message-v1:",yc="group_secret";function bc(e){try{return JSON.parse(e)}catch{return null}}function _h(e){try{return JSON.parse(e)}catch{return null}}function _c(e){return uh(p.userId,e)}function Wr(e){const t=_c(e);return t?bc(t.stateJson):null}function wh(){return{title:"This group is not ready on this device.",body:"Open this group from an invite link or from a device that already has the latest group state.",statusLine:"This device needs the latest group state to open this conversation."}}function Zn(e){const t=wh(),s=_c(e);if(!s)return{available:!1,...t};const n=bc(s.stateJson),r=_h(s.memberCredentialJson);return!n||!r?{available:!1,...t}:n.group_id!==e||r.group_id!==e?{available:!1,...t}:r.member_user_id!==p.userId||r.epoch!==n.epoch?{available:!1,...t}:kc(n,p.userId)?{available:!0,local:s,state:n,credential:r}:{available:!1,...t}}function Vi(e,t){const s=e.find(n=>n.member_user_id===t);if(!s)throw new Error(`Private-group credential for @${t} is missing from the current epoch.`);return s}function Qn(e){var t;return((t=e.members.find(s=>s.role==="Owner"))==null?void 0:t.user_id)||p.userId}function wc(e){var t,s;return((s=(t=Wr(e))==null?void 0:t.attributes.title)==null?void 0:s.trim())||e}function kc(e,t){return e.members.some(s=>s.user_id===t)}function xc(e,t,s){const n=new URL(location.origin+"/");return n.searchParams.set("group_invite_token",t),n.searchParams.set("server",e),n.hash=`${yc}=${encodeURIComponent(s)}`,n.toString()}function kh(e,t=location.hash){var r;const s=t.startsWith("#")?t.slice(1):t;return((r=new URLSearchParams(s).get(e))==null?void 0:r.trim())||""}function xh(e){const t=e.trim().toLowerCase();if(!t||t.length%2!==0)throw new Error("Invalid hex value.");const s=[];for(let n=0;n<t.length;n+=2)s.push(Number.parseInt(t.slice(n,n+2),16));return s}function zi(e){const s=(e||"").trim()||location.href;let n;try{n=new URL(s,location.origin)}catch{return null}const r=(n.searchParams.get("group_invite_token")||n.searchParams.get("group_token")||n.searchParams.get("pg_invite_token")||"").trim(),a=(kh(yc,n.hash)||n.searchParams.get("group_secret")||"").trim();return!r||!a?null:{serverUrl:(n.searchParams.get("server")||p.serverUrl||location.origin).trim(),inviteToken:r,inviteSecretBase64:a}}function Sh(e,t){if(!e.startsWith(Ea))return null;try{const s=JSON.parse(e.slice(Ea.length));if(s.kind!=="pqmsg-private-group-message-v1"||!s.group_id.trim()||!s.body.trim())return null;const n=Wr(s.group_id);return!n||!kc(n,t)?null:{groupId:s.group_id,body:s.body}}catch{return null}}function Sc(e){return{membership_handle_sha256:e.membership_handle_sha256,member_commitment_sha256:e.member_commitment_sha256,fetch_key_sha256:e.fetch_key_sha256,publish_key_sha256:e.publish_key_sha256}}async function Ih(e,t){const s=kt(t.authorizing_member_credential);if(!s.publish_key_base64)throw new Error("Current private group credential cannot publish state");const n=Le(Uint8Array.from(t.snapshot.state_commitment_sha256));return await e.publishPrivateGroupState({group_id:t.snapshot.group_id,epoch:t.snapshot.epoch,state_commitment_sha256:n,ciphertext_nonce_base64:C(Uint8Array.from(t.snapshot.ciphertext.nonce)),ciphertext_base64:C(Uint8Array.from(t.snapshot.ciphertext.ciphertext)),ciphertext_aad_base64:C(Uint8Array.from(t.snapshot.ciphertext.aad)),authorizing_membership_handle_sha256:s.membership_handle_sha256,authorizing_publish_key_base64:s.publish_key_base64,members:t.member_credentials.map(r=>Sc(kt(r)))}),n}async function Yi(e,t,s,n){const r=kt(s);if(!r.publish_key_base64)throw new Error("Current private group credential cannot publish state");const a=Ol(t),i=Le(Uint8Array.from(a.state_commitment_sha256));return await e.publishPrivateGroupState({group_id:a.group_id,epoch:a.epoch,state_commitment_sha256:i,ciphertext_nonce_base64:C(Uint8Array.from(a.ciphertext.nonce)),ciphertext_base64:C(Uint8Array.from(a.ciphertext.ciphertext)),ciphertext_aad_base64:C(Uint8Array.from(a.ciphertext.aad)),authorizing_membership_handle_sha256:r.membership_handle_sha256,authorizing_publish_key_base64:r.publish_key_base64,members:n.map(o=>Sc(kt(o)))}),i}function Ar(e,t,s,n,r){ph(p.userId,e.group_id,JSON.stringify(e),JSON.stringify(t),s),zn(p.userId,e.group_id,Qn(e),n,r)}async function Ji(e,t,s,n){const r=kt(s);if(!r.publish_key_base64)throw new Error("Current private-group credential cannot issue invites.");const a=Bo(n),i=await e.createPrivateGroupInvite({group_id:t.group_id,epoch:t.epoch,invite_commitment_sha256:Le(Uint8Array.from(a.envelope.invite_commitment_sha256)),invite_ciphertext_nonce_base64:C(Uint8Array.from(a.envelope.ciphertext.nonce)),invite_ciphertext_base64:C(Uint8Array.from(a.envelope.ciphertext.ciphertext)),invite_ciphertext_aad_base64:C(Uint8Array.from(a.envelope.ciphertext.aad)),authorizing_membership_handle_sha256:r.membership_handle_sha256,authorizing_publish_key_base64:r.publish_key_base64});return xc(p.serverUrl,i.invite_token,C(Uint8Array.from(a.invite_secret)))}function Eh(e,t,s,n){const r=new TextEncoder,a=C(r.encode(e)),i=C(r.encode(t)),o=C(r.encode(s));return[gc,a,i,o,n].join("|")}function Ch(e){const t=e.split("|",5);if(t.length!==5||t[0]!==gc)return null;const s=new TextDecoder;try{const n=s.decode(W(t[1])),r=s.decode(W(t[2])),a=s.decode(W(t[3])),i=W(t[4]);return{fileName:n,mimeType:r,noteText:a,dataBase64:t[4],byteLength:i.byteLength}}catch{return null}}function Ya(e,t){const s=e.trim(),n=fs(t).toLowerCase();return s?`Sent ${n}: ${s}`:`Sent ${n}`}function Ah(e){if(!at(e))return"";const t=fs(Ls(e)),s=er(e),n=e.attachmentByteLength?` (${ui(e.attachmentByteLength)})`:"";return`${t}: ${s}${n}`}function ht(e){var a;const t=new Set,s=e.text.trim();s&&t.add(s);const n=Ah(e);n&&t.add(n);const r=((a=e.attachmentNoteText)==null?void 0:a.trim())||"";return r&&!s.toLowerCase().includes(r.toLowerCase())&&t.add(r),Array.from(t).join(`
`).trim()}function $h(e){var o,c,d;const t=new Set,s=ht(e);s&&t.add(s);const n=((o=e.replyPreview)==null?void 0:o.trim())||"";n&&t.add(n);const r=((c=e.fileName)==null?void 0:c.trim())||"";r&&t.add(r);const a=((d=e.mimeType)==null?void 0:d.trim())||"";a&&t.add(a);const i=at(e)?fs(Ls(e)):"";return i&&t.add(i),Array.from(t).join(`
`)}function Ic(e,t=80){return ht(e).replace(/\s+/g," ").trim().slice(0,t)}function Xi(e){const t=Ic(e)||"No messages yet";return e.sender===p.userId?`You: ${t}`:t}function Th(e){return Ic(e)||"No messages yet"}async function Lh(e,t){const s=e.trim();if(!t)return{plaintext:s,previewText:`You: ${s}`,storedText:`You: ${s}`};const n=t.type||"application/octet-stream",r=dd(await t.arrayBuffer()),a={fileName:t.name,mimeType:n,noteText:s,dataBase64:r,byteLength:t.size},i=Ya(s,n);return{plaintext:Eh(a.fileName,a.mimeType,a.noteText,a.dataBase64),previewText:`You: ${i}`,storedText:`You: ${i}`,attachment:a}}function Ph(e,t){return`${e}: ${Ya(t.noteText,t.mimeType)}`}async function Mh(e,t){var h,u,f,m,w;const s=Zn(e);if(!s.available)throw new Error(s.statusLine);const{state:n,credential:r}=s,a=await J();await Ft();const i=new j(p.serverUrl),o=kt(r),c=Vl(n,p.userId,a.identitySigSecret,a.identityPqSigSecret,t.plaintext,Date.now()),d=await i.publishPrivateGroupMessage({group_id:c.group_id,epoch:c.epoch,sent_at_unix_ms:c.sent_at_unix_ms,ciphertext_nonce_base64:C(Uint8Array.from(c.ciphertext.nonce)),ciphertext_base64:C(Uint8Array.from(c.ciphertext.ciphertext)),ciphertext_aad_base64:C(Uint8Array.from(c.ciphertext.aad)),sender_hybrid_signature_base64:C(Uint8Array.from(c.sender_hybrid_signature)),authorizing_membership_handle_sha256:o.membership_handle_sha256,authorizing_fetch_key_base64:o.fetch_key_base64});dc(p.userId,e,d.message_id);const l=Qn(n);zn(p.userId,e,l,t.previewText,!1),await Ys({id:`srv-group-${d.message_id}`,conversationId:`group:${e}`,sender:p.userId,recipient:e,text:t.storedText,timestamp:c.sent_at_unix_ms,status:"sent",serverMessageId:d.message_id,mimeType:(h=t.attachment)==null?void 0:h.mimeType,fileName:(u=t.attachment)==null?void 0:u.fileName,attachmentDataBase64:(f=t.attachment)==null?void 0:f.dataBase64,attachmentByteLength:(m=t.attachment)==null?void 0:m.byteLength,attachmentNoteText:(w=t.attachment)==null?void 0:w.noteText})}async function Bh(e,t,s){if(e===p.userId){const r=s??await J();return{fingerprintSha256:Cs(r.identityX25519Pub,r.identityPqSigPub),identityKeyVersion:1,identityX25519Pub:r.identityX25519Pub,identitySigPub:r.identitySigPub,identityPqSigPub:r.identityPqSigPub,observedAt:new Date().toISOString()}}const n=await li(e,t);return await Hn(e,t,n),n}function Uh(e,t){return{group_id:e.group_id,epoch:e.epoch,sender_user_id:t,sent_at_unix_ms:e.sent_at_unix_ms,ciphertext:{nonce:Array.from(W(e.ciphertext_nonce_base64)),ciphertext:Array.from(W(e.ciphertext_base64)),aad:Array.from(W(e.ciphertext_aad_base64))},sender_hybrid_signature:Array.from(W(e.sender_hybrid_signature_base64))}}async function qh(e,t,s,n){const r=[...new Set(e.members.map(i=>i.user_id))].sort((i,o)=>{const c=i===p.userId||xt(p.userId,i)?0:1,d=o===p.userId||xt(p.userId,o)?0:1;return c!==d?c-d:i.localeCompare(o)});let a=null;for(const i of r)try{const o=await Bh(i,s,n);return{opened:zl(e,Uh(t,i),o.identitySigPub,o.identityPqSigPub),senderPin:o}}catch(o){a=o}throw a instanceof Error?a:new Error("Private-group sender could not be identified from the current group state.")}async function Ec(e){const t=Zn(e);if(!t.available)return!1;const{state:s,credential:n}=t,r=new j(p.serverUrl),a=kt(n);let i=hh(p.userId,e);const o=await r.fetchPrivateGroupMessages({membership_handle_sha256:a.membership_handle_sha256,fetch_key_base64:a.fetch_key_base64,since_message_id:i||void 0});if(!o.messages.length)return!1;const c=await J();let d=!1;for(const l of o.messages){if(l.message_id<=i)continue;const{opened:h}=await qh(s,l,r,c),u=Pe(h.sender_user_id).primaryLabel,f=Ch(h.body),m=h.sender_user_id===p.userId?"You":u,w=f?Ph(m,f):`${m}: ${h.body}`,x=f?Ya(f.noteText,f.mimeType):h.body;await Ys({id:`srv-group-${l.message_id}`,conversationId:`group:${e}`,sender:h.sender_user_id,recipient:e,text:w,timestamp:l.sent_at_unix_ms,status:"delivered",serverMessageId:l.message_id,mimeType:f==null?void 0:f.mimeType,fileName:f==null?void 0:f.fileName,attachmentDataBase64:f==null?void 0:f.dataBase64,attachmentByteLength:f==null?void 0:f.byteLength,attachmentNoteText:f==null?void 0:f.noteText}),ti(e,h.sender_user_id,x,ws!==e&&h.sender_user_id!==p.userId),Ts(h.sender_user_id),i=Math.max(i,l.message_id),d=!0}return i>0&&dc(p.userId,e,i),ws===e&&Yn(p.userId,e),d}async function Cc(){if(!p.userId)return;const e=await Xe();if(!(e!=null&&e.private_group_messaging_supported))return;let t=!1;for(const s of cc(p.userId))try{await Ec(s.groupId)&&(t=!0)}catch{}t&&Oe()}async function Dh(){try{await eh(),p=th(),Nh(),await Ft()}catch(e){Ge.innerHTML=`
      <div class="empty-state">
        <h2>Secure web messaging unavailable</h2>
        <p>${v(X(e))}</p>
      </div>
    `;return}if(p.userId&&Kn(p.userId)){const e=new URLSearchParams(location.search),t=e.get("invite"),s=e.get("invite_token")||e.get("token");e.get("group_invite_token")||e.get("group_token")||e.get("pg_invite_token")?R({screen:"create-group"}):t&&t!==p.userId||s?R({screen:"new-chat"}):R({screen:"conversations"})}else R({screen:"onboarding"});mh(Qi),gh(qv),Rh(),Qi(Jn())}function $r(){os==null||os.remove(),os=null}function nn(){var t;if(os)return;const e=document.createElement("div");e.className="shortcut-sheet",e.setAttribute("role","dialog"),e.setAttribute("aria-modal","true"),e.setAttribute("aria-labelledby","shortcut-sheet-title"),e.innerHTML=`
    <div class="shortcut-card">
      <div class="shortcut-head">
        <div>
          <h2 id="shortcut-sheet-title">Keyboard shortcuts</h2>
          <p>Signal Desktop exposes shortcuts with <span class="mono">Ctrl /</span> or <span class="mono">Cmd /</span>. This web build now does the same for the shortcuts it currently supports.</p>
        </div>
        <button id="shortcut-sheet-close" class="icon-btn" aria-label="Close keyboard shortcuts">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
      <div class="shortcut-grid">
        <section class="shortcut-section">
          <h3>General</h3>
          <div class="shortcut-row">
            <span>Show keyboard shortcuts</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>/</kbd> <span class="shortcut-sep">or</span> <kbd>Cmd</kbd><kbd>/</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Focus composer</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>T</kbd> <span class="shortcut-sep">or</span> <kbd>Cmd</kbd><kbd>Shift</kbd><kbd>T</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Insert a new line while composing</span>
            <span class="shortcut-keys"><kbd>Shift</kbd><kbd>Enter</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Expand composer</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>X</kbd> <span class="shortcut-sep">or</span> <kbd>Cmd</kbd><kbd>Shift</kbd><kbd>X</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Send from expanded composer</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Enter</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Attach file in direct chat</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>U</kbd> <span class="shortcut-sep">or</span> <kbd>Cmd</kbd><kbd>U</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Search in conversation</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>F</kbd> <span class="shortcut-sep">or</span> <kbd>Cmd</kbd><kbd>Shift</kbd><kbd>F</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Close shortcut sheet or selection mode</span>
            <span class="shortcut-keys"><kbd>Esc</kbd></span>
          </div>
        </section>
        <section class="shortcut-section">
          <h3>Selected messages</h3>
          <div class="shortcut-row">
            <span>Share selected messages</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>S</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Delete selected messages from this device</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>D</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Reply to a single selected message</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>R</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>React to a single selected message</span>
            <span class="shortcut-keys"><kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>E</kbd></span>
          </div>
          <div class="shortcut-row">
            <span>Open selected message menu</span>
            <span class="shortcut-keys"><kbd>Shift</kbd><kbd>F10</kbd></span>
          </div>
        </section>
        <section class="shortcut-section">
          <h3>Thread navigation</h3>
          <div class="shortcut-row">
            <span>Reply to a message</span>
            <span class="shortcut-keys">Swipe right on Android <span class="shortcut-sep">or</span> right-click a bubble on web</span>
          </div>
          <div class="shortcut-row">
            <span>Jump through a reply thread</span>
            <span class="shortcut-keys">Click a quoted reply or reply count chip</span>
          </div>
        </section>
      </div>
      <p class="shortcut-footnote">To enter selection mode, right-click a message bubble and choose <strong>Select messages</strong>, then click additional bubbles.</p>
    </div>
  `,document.body.appendChild(e),os=e,(t=e.querySelector("#shortcut-sheet-close"))==null||t.addEventListener("click",$r),e.addEventListener("click",s=>{s.target===e&&$r()})}function Rh(){Fi||(Fi=!0,window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&e.code==="Slash"){e.preventDefault(),os?$r():nn();return}e.key==="Escape"&&os&&(e.preventDefault(),$r())}))}async function Xe(){if(Ee&&Tn===p.serverUrl)return Ee;try{const e=await new j(p.serverUrl).getCapabilities();return Ee=e,Tn=p.serverUrl,e}catch{return Ee=null,Tn=p.serverUrl,null}}function Kr(){return $s(Ee)}function ls(){return(Ee==null?void 0:Ee.presence_supported)??!1}function Nn(){return(Ee==null?void 0:Ee.typing_indicators_supported)??!1}function Ja(){return(Ee==null?void 0:Ee.read_receipts_supported)??!1}function Nh(){const e=Jo();if(e)throw new Error(e)}async function Ft(){if(xr())return;if(!await Wo()||!xr())throw new Error("Web post-quantum runtime unavailable in this build.")}async function Xa(){const e=await Xe();if(!e)throw new Error("Server capabilities could not be verified.");if(e.pq_ratchet_interval!==1)throw new Error("Server is not advertising per-message PQ ratchet support.");if(!e.sealed_sender_required)throw new Error("Server is not advertising sealed-sender-only direct messaging.");if(!e.sender_certificate_supported)throw new Error("Server is not advertising sender certificate support.");if(!e.key_transparency_supported)throw new Error("Server is not advertising key transparency support.");if(!e.sealed_delivery_tokens_supported)throw new Error("Server is not advertising sealed delivery token support.");if(!e.sender_certificate_issuer_ed25519_pub)throw new Error("Server is not advertising the sender certificate issuer key.");if(!e.transparency_log_issuer_ed25519_pub)throw new Error("Server is not advertising the transparency log issuer key.");if(e.contact_discovery_mode==="private_service"&&(!e.contact_discovery_supported||!e.contact_discovery_ticket_supported||!e.contact_discovery_service_origin||!e.contact_discovery_ticket_issuer_ed25519_pub||!e.contact_discovery_manifest_issuer_ed25519_pub))throw new Error("Server is advertising private contact discovery without a complete service contract.");return e}async function Ca(e,t){await sh(p.userId,e,dn(),t)}async function Hh(e){return nh(p.userId,e,dn())}function Oh(e,t){var s,n;try{const a=(n=(s=JSON.parse(e).snapshot)==null?void 0:s.pq_ratchet)==null?void 0:n.interval;return typeof a!="number"||a!==t}catch{return!0}}async function Ac(e,t){const s=await Hh(e);return s?Oh(s,t)?(await rh(p.userId,e),{sessionJson:null,clearedLegacy:!0}):{sessionJson:s,clearedLegacy:!1}:{sessionJson:null,clearedLegacy:!1}}async function Gh(e){const t=dn();He=e,await Gr(e.userId,t,e)}async function $c(e,t,s){await Ft();const n=await Xa(),{sessionJson:r}=await Ac(t,n.pq_ratchet_interval),a=new j(p.serverUrl);if(r){const l=fp(r,e.userId,t,s);await Ca(t,l.sessionJson);const h=await jh(t,a),u=await Zi(e,a);return Hi(e,t,h,l.messageBytesBase64,u)}const i=Rn[t]??await a.getBundle(t);delete Rn[t];const o=i.identity_fingerprint_sha256||Cs(i.identity_x25519_pub,i.identity_pq_sig_pub);zr(t,i.identity_x25519_pub,i.identity_sig_pub,i.identity_pq_sig_pub,o,i.identity_key_version,i.bundle_generated_at),await Hn(t,a,xt(p.userId,t));const c=vp(e,i,s);await Ca(t,c.sessionJson);const d=await Zi(e,a);return Hi(e,t,i.identity_x25519_pub,c.messageBytesBase64,d)}async function Tc(e,t,s,n){const r=He??e;await Ft();const a=await Xa();let i=t,o=s??"";if(a.sealed_sender_required){const h=gp(r,n,t,a.sender_certificate_issuer_ed25519_pub);o=h.senderUserId,i=h.payloadMessageBytesBase64}if(!o)throw new Error("Missing sender identity for incoming message");await Hn(o,new j(p.serverUrl));const{sessionJson:c,clearedLegacy:d}=await Ac(o,a.pq_ratchet_interval);let l;try{l=mp(r,o,i,c)}catch(h){throw d?new Error("Stored session was reset for mandatory PQ ratchet rollout; peer must start a fresh session."):h}if(await Gh(l.updatedKeys),await Ca(o,l.sessionJson),l.plaintextUtf8.startsWith(Ea)){if(a.private_group_messaging_supported)return{kind:"ignored",senderUserId:o,recipient:r.userId,plaintext:""};const h=Sh(l.plaintextUtf8,o);if(!h)throw new Error("Private-group message could not be matched to local opaque state.");return{kind:"group",senderUserId:o,recipient:h.groupId,plaintext:h.body}}return{kind:"dm",senderUserId:o,recipient:r.userId,plaintext:l.plaintextUtf8}}async function jh(e,t){const s=xt(p.userId,e);if(s!=null&&s.identityX25519Pub)return await Hn(e,t,s),s.identityX25519Pub;const n=await t.getBundle(e),r=n.identity_fingerprint_sha256||Cs(n.identity_x25519_pub,n.identity_pq_sig_pub);return zr(e,n.identity_x25519_pub,n.identity_sig_pub,n.identity_pq_sig_pub,r,n.identity_key_version,n.bundle_generated_at),await Hn(e,t,xt(p.userId,e)),n.identity_x25519_pub}async function Zi(e,t){const s=ka(e);return(await t.getSenderCertificate(e.userId,s)).certificate_base64}function Wh(e,t,s){return t.user_id!==e||t.leaf.user_id!==e?!1:t.leaf.version===s.identityKeyVersion&&t.leaf.identity_x25519_pub===s.identityX25519Pub&&t.leaf.identity_sig_pub===s.identitySigPub&&(t.leaf.identity_pq_sig_pub??"")===s.identityPqSigPub}function Kh(e){return e.includes("previous_tree_size must be in 1..=current tree size")}async function Lc(e,t,s){try{return await e.getTransparencyProof(t,s==null?void 0:s.tree_size)}catch(n){if(!s||!Kh(X(n)))throw n;return await e.getTransparencyProof(t)}}async function Hn(e,t,s){var c;const n=await Xa(),r=(c=s==null?void 0:s.identityPqSigPub)!=null&&c.trim()?s:await li(e,t),a=jr(p.serverUrl,e),i=await Lc(t,e,a),o=Fo(JSON.stringify(i),n.transparency_log_issuer_ed25519_pub,a?JSON.stringify(a):null);if(!Wh(e,i,r))throw new Error(`Peer transparency proof does not match the pinned hybrid identity for ${e}.`);if(o.leafUserId!==e||o.leafVersion!==i.leaf.version)throw new Error(`Peer transparency proof returned an unexpected leaf for ${e}.`);return oc(p.serverUrl,e,i.signed_tree_head),{leafVersion:o.leafVersion,treeSize:o.treeSize,consistencyVerified:o.consistencyVerified}}async function Pc(e,t,s){var c,d,l,h;const n=(c=Dn[t])==null?void 0:c.trim();if(n)return n;const r=ja(e,t);let a=await s.getProfile(t,r),i=((d=a.sealed_delivery_token)==null?void 0:d.trim())||"";if(!i){const u=Hr(e,t,"",!1,"");await s.upsertContact(e.userId,{contact_user_id:t},u),Wt(t),Es(),a=await s.getProfile(t,r),i=((l=a.sealed_delivery_token)==null?void 0:l.trim())||""}if(!i)throw new Error("Direct messaging requires adding this user as a contact first.");Dn[t]=i;const o=((h=a.display_name)==null?void 0:h.trim())||"";return o&&(Je[t]=o,on(e.userId,t,o)),i}async function us(e){const t=$s(await Xe());if(e==="direct"){try{await Ft()}catch(n){return D(X(n),"error"),!1}if(t.directMessagingAllowed)return!0}else if(t.groupMessagingAllowed)return!0;return D(`Web ${e==="group"?"group messaging":"messaging"} is disabled. ${t.detail}`,"error"),!1}const Za=`
  <div class="onboarding-icon">
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="16" fill="#1a8cff"/>
      <path d="M20 22h24v20H20z" fill="#fff" opacity="0.9"/>
      <circle cx="28" cy="32" r="4" fill="#1a8cff"/>
      <rect x="36" y="28" width="14" height="3" rx="1.5" fill="#1a8cff"/>
      <rect x="36" y="34" width="10" height="3" rx="1.5" fill="#1a8cff" opacity="0.6"/>
    </svg>
  </div>
  <h1>PQMsg</h1>
  <p class="onboarding-sub">Post-quantum encrypted messaging</p>
`;Dh();window.addEventListener("offline",()=>rd(!0));window.addEventListener("online",()=>{rd(!1),Uv()});function Qi(e){switch(is==null||is(),is=null,e.screen){case"onboarding":sv();break;case"create-account":Gc();break;case"sign-in":jc();break;case"conversations":ni();break;case"chat":cn=e.peerId,On(e.peerId);break;case"new-chat":yv();break;case"settings":gr();break;case"group-chat":ws=e.groupId,ed(e.groupId);break;case"group-info":La(e.groupId);break;case"create-group":_v();break;case"identity-log":Gv();break;case"discovery":jv();break;case"server-info":Wv();break;case"search":Bv();break;case"devices":Pa();break;case"link-device":Sv();break;case"call":Iv(e.peerId,e.callType);break;case"incoming-call":Ev(e.callId,e.peerId,e.callType,e.sdpOfferBase64);break}requestAnimationFrame(()=>{const t=Ge.querySelector("h1, h2, h3, .topbar .chat-header-name, .search-input");t instanceof HTMLElement&&t.focus({preventScroll:!0})})}function Mc(e,t){return`${e}:${t}`}function Fh(){return new Map(ih(p.userId).map(e=>[Mc(e.kind,e.threadId),e]))}function eo(e,t,s){return e.get(Mc(t,s))??Fn(p.userId,t,s)}function Vh(e){var s;const t=((s=e==null?void 0:e.username)==null?void 0:s.trim().replace(/^@+/,""))||"";return t?`@${t}`:(e==null?void 0:e.contact_user_id)||""}function Pe(e){var d,l,h;const t=ue.find(u=>u.contact_user_id===e),s=((d=Je[e])==null?void 0:d.trim())||((l=rc(p.userId,e))==null?void 0:l.trim())||"",n=Vh(t),r=((h=t==null?void 0:t.alias)==null?void 0:h.trim())||s||n||e,a=n||(r===e?"":e),i=a&&r!==a?a:"",o=r.slice(0,2).toUpperCase()||e.slice(0,2).toUpperCase(),c=!!(t!=null&&t.verified_by_qr||xt(p.userId,e));return{primaryLabel:r,secondaryLabel:i,avatarText:o,isVerified:c}}function Qa(e,t){const s=wc(e);return{primaryLabel:s,secondaryLabel:t===p.userId?"You created this group":`Owner @${t}`,avatarText:s.slice(0,2).toUpperCase()||e.slice(0,2).toUpperCase()}}function zh(e){if(e===p.userId)return{summary:"Local member credential",detail:"This device holds the current opaque state for your membership."};const t=ue.find(r=>r.contact_user_id===e),s=xt(p.userId,e),n=jr(p.serverUrl,e);return ei(t,s)?{summary:"Verified via safety number",detail:n?`Transparency auto-verified in tree #${n.tree_size}.`:"This member's current fingerprint matches the saved verification."}:n?{summary:"Transparency auto-verified",detail:`Signed transparency checkpoint saved at tree #${n.tree_size}.`}:s?{summary:"Pinned on this device",detail:"This member's hybrid identity is pinned locally, but not safety-number verified."}:{summary:"No local trust checkpoint",detail:"Open a direct chat and verify this member before trusting membership changes."}}function Bc(e,t,s){return Vn(p.userId,e,t,{requestState:s})}function ks(e,t,s){return Vn(p.userId,e,t,{archivedAt:s?Date.now():null})}function Uc(e,t){const s=Fn(p.userId,e,t);return Vn(p.userId,e,t,{pinnedAt:s.pinnedAt?null:Date.now()})}function qc(e,t,s){D(s?"Chat archived":"Chat restored","success",{actionLabel:"Undo",action:()=>{ks(e,t,!s),Oe()}})}function Yh(e,t){var s,n;return e==="group"?((s=As(p.userId).find(r=>r.groupId===t))==null?void 0:s.unreadCount)??0:((n=Va(p.userId).find(r=>r.peerUserId===t))==null?void 0:n.unreadCount)??0}function Jh(e,t,s){if(e==="group"){s?lh(p.userId,t,1):Yn(p.userId,t);return}s?ah(p.userId,t,1):jt(p.userId,t)}function Xh(e){return ue.some(t=>t.contact_user_id===e)?!0:Fn(p.userId,"dm",e).requestState==="accepted"}function Wt(e){Bc("dm",e,"accepted"),ks("dm",e,!1)}function ei(e,t){var n;return!(e!=null&&e.verified_by_qr)||!t?!1:(((n=e.verified_fingerprint_sha256)==null?void 0:n.trim().toLowerCase())||"")===t.fingerprintSha256.trim().toLowerCase()}function Zh(e){const t=ue.findIndex(s=>s.contact_user_id===e.contact_user_id);if(t>=0){ue=[...ue.slice(0,t),e,...ue.slice(t+1)];return}ue=[...ue,e].sort((s,n)=>s.contact_user_id.localeCompare(n.contact_user_id))}function Dc(e){Vn(p.userId,"dm",e,{requestState:"dismissed",archivedAt:Date.now()})}function Rc(e,t,s){Xh(e)?Wt(e):Bc("dm",e,"pending"),as(p.userId,e,t,s)}function Qh(){for(const e of ue)Vn(p.userId,"dm",e.contact_user_id,{requestState:"accepted"})}async function Ts(e){var t,s,n;if(e)try{const r=await J(),a=new j(p.serverUrl),i=ja(r,e),o=await a.getProfile(e,i),c=((t=o.sealed_delivery_token)==null?void 0:t.trim())||"";c&&(Dn[e]=c);const d=((s=o.display_name)==null?void 0:s.trim())||"";if(d&&(Je[e]=d,on(r.userId,e,d)),e===r.userId){let l=!1;d&&p.displayName!==d&&(p.displayName=d,l=!0);const h=((n=o.username)==null?void 0:n.trim())||"";(p.username||"")!==h&&(p.username=h,l=!0);const u=!!(o.username_lookup_enabled&&h);!!p.usernameLookupEnabled!==u&&(p.usernameLookupEnabled=u,l=!0),l&&Mt(p)}}catch{}}async function ev(e){const t=[...new Set(e)].map(n=>n.trim()).filter(n=>n&&!Je[n]);if(t.length===0)return;const s=JSON.stringify(Je);await Promise.allSettled(t.map(n=>Ts(n))),JSON.stringify(Je)!==s&&Oe()}async function Nc(){Je=Object.fromEntries(ac(p.userId).map(e=>[e.targetUserId,e.displayName])),await Promise.allSettled([Es(),Aa(),Cc(),Ts(p.userId)])}function ti(e,t,s,n){const r=As(p.userId).find(o=>o.groupId===e),a=Pe(t).primaryLabel,i=Wr(e);zn(p.userId,e,i?Qn(i):(r==null?void 0:r.ownerUserId)||t,`${a}: ${s}`,n)}async function Aa(){if(!p.userId)return;const e=await Xe();if(e!=null&&e.group_messaging_supported){try{const t=await J(),s=new j(p.serverUrl),n=np(t,t.userId),r=await s.listUserGroups(t.userId,n),a=new Map(As(t.userId).map(o=>[o.groupId,o]));let i=!1;for(const o of r.groups)a.has(o.group_id)||(zn(t.userId,o.group_id,o.owner_user_id,o.owner_user_id===t.userId?"Group created":"You were added to a group",!1),i=!0);i&&Oe()}catch{}await Cc()}}async function si(e){var a,i;const t=await Fr(e);if(!t)throw new Error("User ID is required");if(t===p.userId)throw new Error("You can't chat with yourself");const s=await J(),n=new j(p.serverUrl),r=ja(s,t);try{const o=await n.getProfile(t,r),c=((a=o.sealed_delivery_token)==null?void 0:a.trim())||"";c&&(Dn[t]=c);const d=((i=o.display_name)==null?void 0:i.trim())||"";d&&(Je[t]=d,on(s.userId,t,d));return}catch(o){if(!X(o).includes("HTTP 404"))throw o}await n.getBundle(t)}async function Fr(e,t){const s=qn(e);if(s)return Tr(s,t);const n=mc(e).trim();return n?n.startsWith("@")?tv(n,t):n.replace(/^@/,"").trim():""}function Hc(e,t){const s=X(t);return s.includes("HTTP 404")?e==="private invite"?"Private invite link was not found or has expired":`User @${e} was not found on this server`:s}function Oc(e){const t=e.user_id.trim().replace(/^@/,"");if(!t)throw new Error("Invite bundle did not contain a user ID");Rn[t]=e;const s=e.identity_fingerprint_sha256||Cs(e.identity_x25519_pub,e.identity_pq_sig_pub);return zr(t,e.identity_x25519_pub,e.identity_sig_pub,e.identity_pq_sig_pub,s,e.identity_key_version,e.bundle_generated_at),t}async function Tr(e,t){const n=await(t??new j(p.serverUrl)).getContactInviteBundle(e);return Oc(n)}async function tv(e,t){const n=await(t??new j(p.serverUrl)).getUsernameBundle(e);return Oc(n)}function sv(){Ge.innerHTML=`
    <div class="onboarding">
      <div class="onboarding-card">
        ${Za}
        <div class="onboarding-copy">
          <p class="onboarding-lede">
            Pick a username, protect this browser with a passphrase, and start private messaging without wading through advanced setup first.
          </p>
          <div class="onboarding-points" aria-label="Onboarding overview">
            <div class="onboarding-point">
              <strong>Username first</strong>
              <span>Your account starts from a simple @name instead of a long utility form.</span>
            </div>
            <div class="onboarding-point">
              <strong>Local passphrase</strong>
              <span>Your keys stay on this browser and are unlocked only with the passphrase you choose.</span>
            </div>
            <div class="onboarding-point">
              <strong>Advanced stays hidden</strong>
              <span>Relay and transport details are still available, but they no longer dominate first run.</span>
            </div>
          </div>
        </div>
        <div class="onboarding-actions">
          <button id="onb-create" class="btn-primary">Create Account</button>
          <button id="onb-signin" class="btn-secondary">Unlock This Browser</button>
        </div>
        <details class="onb-advanced">
          <summary>Advanced</summary>
          <label class="field">
            <span>Server URL</span>
            <input id="onb-server" type="text" value="${v(p.serverUrl)}" />
          </label>
          <button id="onb-save-server" class="btn-sm">Save</button>
        </details>
        <div class="beta-banner beta-banner-warning">
          <strong>Web messaging today</strong>
          <p>${v(yh)}</p>
        </div>
        <p class="onboarding-note">Your keys are generated locally and never leave this browser profile.</p>
      </div>
    </div>
  `,g("#onb-create").addEventListener("click",()=>R({screen:"create-account"})),g("#onb-signin").addEventListener("click",()=>R({screen:"sign-in"})),g("#onb-save-server").addEventListener("click",()=>{const e=g("#onb-server").value.trim();if(e)try{const t=pt(e);p.serverUrl=t.toString().replace(/\/+$/,""),Mt(p),Ee=null,Tn=null,D("Server URL saved","success")}catch(t){D(X(t),"error")}})}function Gc(){const e=sc();Ge.innerHTML=`
    <div class="onboarding">
      <div class="onboarding-card">
        ${Za}
        <div class="onboarding-form">
          <div class="onboarding-copy onboarding-copy-tight">
            <h2 class="onboarding-section-title">Create your profile</h2>
            <p class="onboarding-note">Choose a username for this browser. Your display name is optional and can be changed later.</p>
          </div>
          <label class="field">
            <span>Username</span>
            <input id="onb-user" type="text" placeholder="e.g. alice" autocomplete="off" />
            <small class="field-help">This becomes your account ID on this relay.</small>
          </label>
          <label class="field">
            <span>Display Name (optional)</span>
            <input id="onb-name" type="text" placeholder="How people should see you" autocomplete="off" />
          </label>
          <label class="field">
            <span>Passphrase</span>
            <input id="onb-pass" type="password" placeholder="Protects your keys on this browser" />
            <div id="onb-strength" class="password-strength"></div>
          </label>
          <label class="field">
            <span>Confirm Passphrase</span>
            <input id="onb-pass2" type="password" placeholder="Re-enter passphrase" />
          </label>
          <button id="onb-go" class="btn-primary">Create Account</button>
          <button id="onb-back" class="btn-link">&larr; Back</button>
        </div>
        <div id="onb-progress" class="progress-bar hidden"><div class="progress-fill"></div></div>
        ${e.length>0?`
          <div class="contacts-section">
            <h3 class="section-label">Profiles already on this browser</h3>
            <div class="contacts-list">
              ${e.map(d=>`
                <div class="contact-row-item">
                  <div class="contact-row contact-row-static">
                    <div class="avatar avatar-sm">${v(d.slice(0,2).toUpperCase())}</div>
                    <div class="contact-info">
                      <span class="contact-name">${v(d)}</span>
                      <span class="contact-id">Already saved locally in this browser</span>
                    </div>
                  </div>
                  <button type="button" class="btn-secondary contact-row-forget" data-local-account-forget="${v(d)}">Forget profile</button>
                </div>
              `).join("")}
            </div>
          </div>
        `:'<p class="onboarding-note">Profiles created here stay bound to this browser origin unless you export or link another device.</p>'}
        <p id="onb-status" class="onboarding-status"></p>
      </div>
    </div>
  `;const t=g("#onb-user"),s=g("#onb-name"),n=g("#onb-pass"),r=g("#onb-pass2"),a=g("#onb-go"),i=g("#onb-progress"),o=g("#onb-status"),c=g("#onb-strength");n.addEventListener("input",()=>{const d=n.value;let l=0;d.length>=8&&l++,d.length>=12&&l++,/[A-Z]/.test(d)&&/[a-z]/.test(d)&&l++,/\d/.test(d)&&l++,/[^A-Za-z0-9]/.test(d)&&l++;const h=["","Weak","Fair","Good","Strong","Very strong"],u=["","var(--danger)","#f59e0b","#eab308","#4ade80","#22c55e"];d.length===0?c.innerHTML="":c.innerHTML=`<div class="strength-bar"><div class="strength-fill" style="width:${l*20}%;background:${u[l]}"></div></div><span style="color:${u[l]}">${h[l]}</span>`}),g("#onb-back").addEventListener("click",()=>R({screen:"onboarding"}));for(const d of document.querySelectorAll("[data-local-account-forget]"))d.addEventListener("click",async()=>{const l=d.dataset.localAccountForget||"";l&&confirm(`Forget the saved local profile for @${l} on this browser? This removes local keys, sessions, pins, and cached chats from this browser only.`)&&(await za(l),p.userId===l&&(p={...Ke,serverUrl:p.serverUrl,suiteLabel:p.suiteLabel},Mt(p)),D(`Forgot the local profile for @${l} on this browser.`,"info"),Gc())});a.addEventListener("click",async()=>{const d=fc(t.value),l=s.value.trim(),h=n.value,u=r.value;if(!t.value.trim()){o.textContent="Choose a username for this browser profile.",o.classList.add("error-text"),t.focus();return}if(!d){o.textContent="That username cannot be used after normalization. Try letters, numbers, dashes, or underscores.",o.classList.add("error-text"),t.focus();return}if(Kn(d)){o.textContent=`This browser already has a saved local profile for @${d}. Sign in with that profile or forget it first.`,o.classList.add("error-text"),t.focus();return}if(!h){o.textContent="Enter a passphrase to protect your local keys.",o.classList.add("error-text"),n.focus();return}if(h!==u){o.textContent="Passphrases do not match",o.classList.add("error-text"),r.focus();return}if(h.length<6){o.textContent="Passphrase must be at least 6 characters",o.classList.add("error-text"),n.focus();return}const f=d,m=l||f;t.value=f,s.value=l,a.disabled=!0,o.classList.remove("error-text"),i.classList.remove("hidden");try{o.textContent="Loading crypto runtime...",Nt(i,10),await Ft(),o.textContent="Generating keys…",Nt(i,20);const w=`${f}-web-1`,x=Do(f,w,"ml-kem-768",16),_=new j(p.serverUrl);let y=!1;o.textContent="Preparing relay accountâ€¦",Nt(i,50);try{await Ua(_,x,m),y=!0}catch(I){const L=X(I),B=await Xe();if(!Jv(L)||!tr(B))throw I;if(!confirm(`@${f} is already registered on this development relay. Reset the relay record and continue with the saved keys for @${f} in this browser?`))throw new Error(`Registration stopped because @${f} is already registered on this relay.`);o.textContent=`Resetting @${f} on the development relayâ€¦`,Nt(i,65),await _.resetDevUserIdentity(f),o.textContent="Re-publishing this browser's keysâ€¦",Nt(i,80),await Ua(_,x,m),y=!0}o.textContent="Registering…",Nt(i,50);const k=new j(p.serverUrl);if(!y){await k.registerUser({user_id:x.userId,identity_x25519_pub:x.identityX25519Pub,identity_sig_pub:x.identitySigPub,identity_pq_sig_pub:x.identityPqSigPub,device_id:x.deviceId}),o.textContent="Publishing prekeys…",Nt(i,80);const I=Ro(x),L=No(x,I);await k.publishPrekeys(x.userId,I,L);try{const B=Wa(x,m,"",!1,"","");await k.upsertProfile(x.userId,{display_name:m,username_lookup_enabled:!1},B)}catch{D("Account created, but profile name could not be synced yet","info")}}o.textContent="Saving encrypted keysâ€¦",Nt(i,90),await Gr(f,h,x),p={serverUrl:p.serverUrl,userId:f,deviceId:w,suiteLabel:"ml-kem-768",peerUserId:"",displayName:m,username:"",usernameLookupEnabled:!1},Mt(p),sessionStorage.setItem("pqmsg.passphrase",h),He=x,Je[f]=m,on(f,f,m),Nt(i,100),o.textContent="Ready!",D(`Your profile is ready as @${f}.`,"info"),setTimeout(()=>R({screen:"conversations"}),600)}catch(w){o.textContent=`Error: ${X(w)}`,o.classList.add("error-text"),a.disabled=!1,i.classList.add("hidden")}})}function jc(){const e=sc();Ge.innerHTML=`
    <div class="onboarding">
      <div class="onboarding-card">
        ${Za}
        <div class="onboarding-form">
          <div class="onboarding-copy onboarding-copy-tight">
            <h2 class="onboarding-section-title">Unlock this browser</h2>
            <p class="onboarding-note">Use the username and passphrase for a profile that was already created on this browser origin.</p>
          </div>
          ${e.length>0?`
            <div class="contacts-section">
              <h3 class="section-label">Profiles on this browser</h3>
              <div class="contacts-list">
                ${e.map(a=>`
                  <div class="contact-row-item">
                    <button type="button" class="contact-row contact-row-main" data-local-account-fill="${v(a)}">
                      <div class="avatar avatar-sm">${v(a.slice(0,2).toUpperCase())}</div>
                      <div class="contact-info">
                        <span class="contact-name">${v(a)}</span>
                        <span class="contact-id">Tap to fill username</span>
                      </div>
                    </button>
                    <button type="button" class="btn-secondary contact-row-forget" data-local-account-forget="${v(a)}">Forget profile</button>
                  </div>
                `).join("")}
              </div>
            </div>
          `:`<p class="onboarding-note">Only profiles created in this browser origin (${v(location.origin)}) can be unlocked here.</p>`}
          <label class="field">
            <span>Username</span>
            <input id="onb-uid" type="text" placeholder="e.g. alice" autocomplete="off" />
          </label>
          <label class="field">
            <span>Passphrase</span>
            <input id="onb-pass" type="password" placeholder="The passphrase protecting your local keys" />
          </label>
          <button id="onb-go" class="btn-primary">Unlock</button>
          <button id="onb-back" class="btn-link">&larr; Back</button>
        </div>
        <p id="onb-status" class="onboarding-status"></p>
      </div>
    </div>
  `;const t=g("#onb-uid"),s=g("#onb-pass"),n=g("#onb-go"),r=g("#onb-status");g("#onb-back").addEventListener("click",()=>R({screen:"onboarding"}));for(const a of document.querySelectorAll("[data-local-account-fill]"))a.addEventListener("click",()=>{t.value=a.dataset.localAccountFill||"",s.focus(),r.textContent="",r.classList.remove("error-text")});for(const a of document.querySelectorAll("[data-local-account-forget]"))a.addEventListener("click",async()=>{const i=a.dataset.localAccountForget||"";i&&confirm(`Forget the saved local profile for @${i} on this browser? This removes local keys, sessions, pins, and cached chats from this browser only.`)&&(await za(i),p.userId===i&&(p={...Ke,serverUrl:p.serverUrl,suiteLabel:p.suiteLabel},Mt(p)),D(`Forgot the local profile for @${i} on this browser.`,"info"),jc())});n.addEventListener("click",async()=>{var o;const a=fc(t.value),i=s.value;if(!t.value.trim()){r.textContent="Enter the username for a profile saved in this browser.",r.classList.add("error-text"),t.focus();return}if(!s.value){r.textContent="Enter the passphrase used when creating this local profile.",r.classList.add("error-text"),s.focus();return}t.value=a,n.disabled=!0,r.classList.remove("error-text");try{if(r.textContent="Loading crypto runtime...",await Ft(),!Kn(a))throw new Error("No local profile found for that username on this browser");r.textContent="Unlocking keys…";let c=await tc(a,i);const d=((o=rc(a,a))==null?void 0:o.trim())||a,l=new j(p.serverUrl);r.textContent="Verifying account…";try{await l.getSenderCertificate(a,ka(c))}catch(h){const u=X(h);if(Ba(u)){const f=await Xe();if(tr(f)&&confirm(`Saved local keys for @${a} do not match the current server record. Repair the saved keys for @${a} on this development relay by resetting the relay record and re-publishing the keys already saved in this browser?`))r.textContent=`Repairing @${a} on the development relayâ€¦`,c=await cd(c,d,i),r.textContent="Verifying repaired accountâ€¦",await l.getSenderCertificate(a,ka(c));else throw new Error(qa(a))}else throw h}p={serverUrl:p.serverUrl,userId:a,deviceId:c.deviceId,suiteLabel:c.suite,peerUserId:"",displayName:d,username:"",usernameLookupEnabled:!1},Mt(p),sessionStorage.setItem("pqmsg.passphrase",i),He=c,r.textContent="Loading your chats…",await Nc(),r.textContent="Signed in!",setTimeout(()=>R({screen:"conversations"}),400)}catch(c){r.textContent=X(c),r.classList.add("error-text"),n.disabled=!1}})}async function ni(){await Xe();const{rows:e,counts:t,visibleRows:s}=xs(),n=Kr(),r=n.directMessagingAllowed?"Pick up a conversation":"Review saved conversations",a=n.directMessagingAllowed?"Select a chat on the left to keep reading, reply, or jump into details.":"This server keeps web messaging in demo-only mode. You can still review local chats and open settings from here.";Ge.innerHTML=`
    <div class="desktop-shell desktop-home-shell">
      ${Ss(s,t)}
      <section class="workspace-preview-pane">
        <div class="workspace-preview-card">
          <span class="workspace-kicker">Inbox</span>
          <h2>${v(r)}</h2>
          <p class="workspace-preview-copy">${v(a)}</p>
          <p class="workspace-preview-meta">
            <span>${t.unread} unread</span>
            <span>${t.groups} groups</span>
            <span>${t.requests} requests</span>
            <span>${t.archived} archived</span>
          </p>
          <div class="workspace-preview-note" role="status" aria-live="polite">
            <strong>${v(n.title)}</strong>
            <span>${v(n.detail)}</span>
          </div>
        </div>
      </section>
    </div>
  `,Is(),Cv(),ls()&&Dv(),Es(),Aa(),ev(e.filter(i=>i.kind==="dm").map(i=>i.threadId)),$n||(Ma(),$n=setInterval(()=>void Ma(),1e4)),An||(An=setInterval(()=>void Aa(),1e4))}function nv(e,t,s){const n=e.map(a=>{const i=eo(s,"dm",a.peerUserId),o=Pe(a.peerUserId),c=Xn[a.peerUserId],d=Er(p.userId,"dm",a.peerUserId).trim()||null,l=Wi(p.userId,"dm",a.peerUserId);return{kind:"dm",threadId:a.peerUserId,updatedAt:Math.max(a.updatedAt,l),unreadCount:a.unreadCount,lastPreview:a.lastPreview,draftText:d,meta:i,primaryLabel:o.primaryLabel,secondaryLabel:o.secondaryLabel,avatarText:o.avatarText,presenceStatus:ls()?(c==null?void 0:c.status)??null:null,isVerified:o.isVerified}}),r=t.map(a=>{const i=eo(s,"group",a.groupId),o=Qa(a.groupId,a.ownerUserId),c=Er(p.userId,"group",a.groupId).trim()||null,d=Wi(p.userId,"group",a.groupId);return{kind:"group",threadId:a.groupId,updatedAt:Math.max(a.updatedAt,d),unreadCount:a.unreadCount,lastPreview:a.lastPreview,draftText:c,meta:i,primaryLabel:o.primaryLabel,secondaryLabel:o.secondaryLabel,avatarText:o.avatarText,presenceStatus:null,isVerified:!1,ownerUserId:a.ownerUserId}});return[...n,...r].filter(a=>a.kind==="group"||a.meta.requestState!=="dismissed").sort((a,i)=>{const o=a.meta.pinnedAt??0,c=i.meta.pinnedAt??0;return o!==c?c-o:i.updatedAt-a.updatedAt})}function Os(e,t){return e.filter(s=>{const n=!!s.meta.archivedAt,r=s.kind==="dm"&&s.meta.requestState==="pending";switch(t){case"all":return!n&&!r;case"unread":return!n&&!r&&s.unreadCount>0;case"groups":return s.kind==="group"&&!n;case"requests":return s.kind==="dm"&&r;case"archived":return n;default:return!0}})}function rv(e){return{all:Os(e,"all").length,unread:Os(e,"unread").length,groups:Os(e,"groups").length,requests:Os(e,"requests").length,archived:Os(e,"archived").length}}function xs(e=null){Je={...Object.fromEntries(ac(p.userId).map(o=>[o.targetUserId,o.displayName])),...Je};const t=p.userId?Va(p.userId):[],s=p.userId?As(p.userId):[],n=Fh(),r=nv(t,s,n),a=rv(r);let i=Os(r,At);if(e&&!i.some(c=>c.kind===e.kind&&c.threadId===e.threadId)){const c=r.find(d=>d.kind===e.kind&&d.threadId===e.threadId);c&&(i=[c,...i])}return{rows:r,counts:a,visibleRows:i}}function Ss(e,t,s=null){const n=Kr(),r=At==="archived"?'<button id="workspace-archived-toggle" class="summary-link-btn" type="button">Back to inbox</button>':t.archived>0?'<button id="workspace-archived-toggle" class="summary-link-btn" type="button">Archived</button>':"",a=e.length===0?ov(At):e.map(l=>cv(l,s)).join(""),i=p.displayName||p.userId,o=i.slice(0,2).toUpperCase(),c=n.directMessagingAllowed?`
        <div class="workspace-compose-row">
          <button id="workspace-new-chat" class="btn-primary">New chat</button>
          ${n.groupMessagingAllowed?'<button id="workspace-new-group" class="btn-secondary">New group</button>':""}
        </div>
      `:`
        <div class="workspace-compose-row">
          <button id="workspace-open-settings" class="btn-primary">Settings</button>
        </div>
      `,d=n.directMessagingAllowed?n.groupMessagingAllowed?"Open chats and settings without losing your place.":"Direct web messaging is available here. Private groups stay blocked by this server.":"This server keeps web messaging in demo-only mode.";return`
    <aside class="workspace-sidebar">
      <div class="workspace-sidebar-head">
        <div class="workspace-profile-card">
          <div class="avatar workspace-profile-avatar">${v(o)}</div>
          <div class="workspace-profile-copy">
            <span class="workspace-kicker">Messages</span>
            <strong>${v(i)}</strong>
            <span class="mono">@${v(p.userId)}</span>
          </div>
          <span class="inbox-pill workspace-profile-pill">${t.unread>0?`${t.unread} unread`:"Protected"}</span>
        </div>
        <div class="workspace-toolbar">
          <button id="workspace-shortcuts" class="icon-btn" title="Keyboard shortcuts" aria-label="Keyboard shortcuts">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="6" width="18" height="12" rx="2"/>
              <path d="M7 10h.01M10 10h.01M13 10h.01M16 10h.01M7 14h10"/>
            </svg>
          </button>
          <button id="workspace-search" class="icon-btn" title="Search messages" aria-label="Search messages">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
            </svg>
          </button>
          <button id="workspace-settings" class="icon-btn" title="Settings" aria-label="Settings">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
            </svg>
          </button>
        </div>
        ${c}
        <div class="workspace-summary-inline" role="status" aria-live="polite">
          <span class="workspace-summary-copy">${v(d)}</span>
          ${r}
        </div>
        <div class="filter-chip-bar workspace-filter-bar" role="tablist" aria-label="Inbox filters">
          ${fn("all","All",t.all)}
          ${fn("unread","Unread",t.unread)}
          ${fn("groups","Groups",t.groups)}
          ${fn("requests","Requests",t.requests)}
          ${fn("archived","Archived",t.archived)}
        </div>
      </div>
      <div class="conversation-list workspace-conversation-list" id="conv-list" role="list">
        ${a}
      </div>
    </aside>
  `}function Is(){var e,t,s,n,r,a,i;(e=document.querySelector("#workspace-new-chat"))==null||e.addEventListener("click",()=>R({screen:"new-chat"})),(t=document.querySelector("#workspace-new-group"))==null||t.addEventListener("click",()=>R({screen:"create-group"})),(s=document.querySelector("#workspace-open-settings"))==null||s.addEventListener("click",()=>R({screen:"settings"})),(n=document.querySelector("#workspace-search"))==null||n.addEventListener("click",()=>R({screen:"search"})),(r=document.querySelector("#workspace-shortcuts"))==null||r.addEventListener("click",()=>nn()),(a=document.querySelector("#workspace-settings"))==null||a.addEventListener("click",()=>R({screen:"settings"})),(i=document.querySelector("#workspace-archived-toggle"))==null||i.addEventListener("click",()=>{At=At==="archived"?"all":"archived",Ot()});for(const o of document.querySelectorAll("[data-inbox-filter]"))o.addEventListener("click",()=>{const c=o.dataset.inboxFilter||"all";c!==At&&(At=c,Ot())});for(const o of document.querySelectorAll("[data-peer]"))o.addEventListener("click",()=>{const c=o.dataset.peer;jt(p.userId,c),R({screen:"chat",peerId:c})}),o.addEventListener("keydown",c=>{(c.key==="Enter"||c.key===" ")&&(c.preventDefault(),o.click())});for(const o of document.querySelectorAll("[data-group]"))o.addEventListener("click",()=>{const c=o.dataset.group;Yn(p.userId,c),R({screen:"group-chat",groupId:c})}),o.addEventListener("keydown",c=>{(c.key==="Enter"||c.key===" ")&&(c.preventDefault(),o.click())});for(const o of document.querySelectorAll("[data-thread-menu]"))o.addEventListener("click",c=>{c.stopPropagation(),dv(o,o.dataset.threadKind||"dm",o.dataset.threadId||"")})}function it(e,t={}){const{counts:s,visibleRows:n}=xs(t.activeThread??null);Ge.innerHTML=`
    <div class="desktop-shell desktop-page-shell">
      ${Ss(n,s,t.activeThread??null)}
      <section class="workspace-page-pane">
        ${e}
      </section>
    </div>
  `,Is()}function av(e={}){const t=Ge.firstElementChild;if(!(t instanceof HTMLElement))return;if(t.classList.contains("desktop-shell")){Is();return}t.classList.add("workspace-legacy-page-card");const s=e.activeThread??null,{counts:n,visibleRows:r}=xs(s),a=document.createElement("div");a.className="desktop-shell desktop-page-shell",a.innerHTML=`
    ${Ss(r,n,s)}
    <section class="workspace-page-pane"></section>
  `;const i=a.querySelector(".workspace-page-pane");i&&(Ge.innerHTML="",i.appendChild(t),Ge.appendChild(a),Is())}function Wc(){return window.matchMedia("(min-width: 980px)").matches}function iv(){return Wc()?document.querySelector(".desktop-thread-pane")||document.querySelector(".workspace-page-pane"):null}function Ln(e){if(!e)return;const t=!!e.querySelector(".chat-details-sheet:not(.hidden), .shared-media-sheet");e.classList.toggle("has-side-panel",t)}function ot(e,t,s={}){const n=[s.backButtonId&&s.backButtonLabel?`<button id="${v(s.backButtonId)}" class="btn-secondary" type="button">${v(s.backButtonLabel)}</button>`:"",s.actionsHtml??""].filter(Boolean).join("");return`
    <header class="workspace-page-header">
      <div class="workspace-page-copy">
        <span class="workspace-kicker">${v(s.eyebrow??"Messages")}</span>
        <h1 class="workspace-page-title">${v(e)}</h1>
        ${t?`<p class="workspace-page-subtitle">${t}</p>`:""}
      </div>
      ${n?`<div class="workspace-page-actions">${n}</div>`:""}
    </header>
  `}function xe(e,t,s={}){const n=s.iconSvg??`
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v7A2.5 2.5 0 0 1 17.5 17h-6l-3.5 2.5V17h-1.5A2.5 2.5 0 0 1 4 14.5z"/>
        <path d="M8 9h8M8 12.5h5"/>
      </svg>
    `;return`
    <div class="workspace-empty-state${s.compact?" compact":""}">
      <div class="workspace-empty-state-icon" aria-hidden="true">${n}</div>
      <div class="workspace-empty-state-copy">
        <span class="workspace-kicker">${v(s.eyebrow??"Messages")}</span>
        <h2>${v(e)}</h2>
        <p>${v(t)}</p>
      </div>
      ${s.actionsHtml?`<div class="workspace-empty-state-actions">${s.actionsHtml}</div>`:""}
    </div>
  `}function fn(e,t,s){const n=At===e?" active":"",r=s>0?`<span class="filter-chip-count">${s}</span>`:"";return`
    <button type="button" class="filter-chip${n}" data-inbox-filter="${e}" role="tab" aria-selected="${At===e}">
      <span>${t}</span>
      ${r}
    </button>
  `}function ov(e){const t=e==="requests"?{title:"No message requests",body:"New chats from unknown people appear here until you accept them."}:e==="archived"?{title:"Archive is empty",body:"Archived chats stay out of the way until you need them."}:e==="groups"?{title:"No groups yet",body:"Create a group from the new chat button when you are ready."}:{title:"No conversations yet",body:"Start a new chat to begin a secure conversation."};return`
    <div class="empty-state">
      <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
        <rect width="80" height="80" rx="20" fill="#1a2d3d"/>
        <path d="M25 28h30v24H25z" fill="#2a4a5f"/>
        <circle cx="35" cy="40" r="5" fill="#4a9eff"/>
        <rect x="45" y="36" width="16" height="3" rx="1.5" fill="#4a9eff" opacity="0.7"/>
        <rect x="45" y="42" width="12" height="3" rx="1.5" fill="#4a9eff" opacity="0.4"/>
      </svg>
      <h2>${t.title}</h2>
      <p>${t.body}</p>
    </div>
  `}function Kc(e){const t=(e.pills??[]).filter(Boolean).map(s=>`<span class="thread-intro-pill">${v(s)}</span>`).join("");return`
    <section class="thread-intro-card" aria-label="${v(e.title)} overview">
      <div class="thread-intro-avatar${e.group?" avatar-group":""}">${v(e.avatarText)}</div>
      <div class="thread-intro-copy">
        <span class="workspace-kicker">${v(e.eyebrow)}</span>
        <h2>${v(e.title)}</h2>
        ${e.subtitle?`<p class="thread-intro-subtitle">${v(e.subtitle)}</p>`:""}
        <p class="thread-intro-body">${v(e.body)}</p>
      </div>
      ${t?`<div class="thread-intro-pills">${t}</div>`:""}
    </section>
  `}function cv(e,t=null){const s=e.unreadCount>0?`<span class="badge">${e.unreadCount>99?"99+":e.unreadCount}</span>`:"",n=!!(t&&e.kind===t.kind&&e.threadId===t.threadId),r=[e.unreadCount>0?" unread":"",e.meta.pinnedAt?" pinned":"",e.kind==="dm"&&e.meta.requestState==="pending"?" pending-request":"",n?" active":""].join(""),a=Yv(e.updatedAt),i=e.kind==="dm"&&e.presenceStatus&&e.presenceStatus!=="offline"?`<span class="presence-dot presence-${v(e.presenceStatus)}"></span>`:"",o=e.secondaryLabel?`<span class="conv-handle">${v(e.secondaryLabel)}</span>`:"",c=e.draftText?'<span class="conv-preview-prefix">Draft</span>':"",d=e.draftText||e.lastPreview,l=e.isVerified?'<span class="verified-badge" title="Trusted identity">✓</span>':"",h=e.kind==="dm"&&e.meta.requestState==="pending"?'<span class="conv-state-badge">Request</span>':"",u=e.meta.pinnedAt?'<span class="conv-state-badge subtle">Pinned</span>':"",f=e.kind==="group"?'<span class="conv-state-badge subtle">Group</span>':"",m=e.kind==="dm"?`data-peer="${v(e.threadId)}"`:`data-group="${v(e.threadId)}"`;return`
    <div class="conv-row${r}" role="button" tabindex="0" ${m}>
      <div class="avatar-wrap">
        <div class="avatar${e.kind==="group"?" avatar-group":""}">${v(e.avatarText)}</div>
        ${i}
      </div>
      <div class="conv-info">
        <div class="conv-top">
          <div class="conv-heading">
            <span class="conv-name">${v(e.primaryLabel)}</span>
            ${l}
            ${h}
            ${u}
            ${f}
          </div>
          <span class="conv-time">${a}</span>
        </div>
        <div class="conv-bottom">
          ${c}
          <span class="conv-preview${e.draftText?" conv-preview-draft":""}">${v(d)}</span>
          ${o}
        </div>
      </div>
      <div class="conv-row-side">
        ${s}
        <button
          type="button"
          class="icon-btn conv-row-menu"
          data-thread-menu="1"
          data-thread-kind="${e.kind}"
          data-thread-id="${v(e.threadId)}"
          aria-label="Conversation actions"
          title="Conversation actions"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/>
          </svg>
        </button>
      </div>
    </div>
  `}function dv(e,t,s){var c;(c=document.querySelector(".ctx-menu"))==null||c.remove();const n=Fn(p.userId,t,s),r=Yh(t,s),a=[{label:r>0?"Mark read":"Mark unread",action:()=>{const d=r===0;Jh(t,s,d),D(d?"Marked unread":"Marked read","success"),Ot()}},{label:n.pinnedAt?"Unpin":"Pin",action:()=>{Uc(t,s),D(n.pinnedAt?"Chat unpinned":"Chat pinned","success"),Ot()}},{label:n.archivedAt?"Unarchive":"Archive",action:()=>{const d=!n.archivedAt;ks(t,s,d),qc(t,s,d),Ot()}}];t==="dm"&&n.requestState==="pending"&&a.unshift({label:"Accept",action:()=>{Wt(s),Ot()}},{label:"Dismiss",className:"ctx-danger",action:()=>{Dc(s),Ot()}});const i=document.createElement("div");i.className="ctx-menu",i.innerHTML=a.map((d,l)=>`<div class="ctx-item ${d.className??""}" data-conv-action="${l}">${v(d.label)}</div>`).join(""),document.body.appendChild(i);const o=e.getBoundingClientRect();i.style.top=`${Math.min(window.innerHeight-i.offsetHeight-12,o.bottom+4)}px`,i.style.left=`${Math.max(12,o.right-180)}px`;for(const d of i.querySelectorAll("[data-conv-action]"))d.addEventListener("click",()=>{var h;const l=Number(d.dataset.convAction);i.remove(),(h=a[l])==null||h.action()});setTimeout(()=>{document.addEventListener("click",function d(l){l.target.closest(".ctx-menu")||(i.remove(),document.removeEventListener("click",d))})},0)}async function On(e){var fi,mi;const t=ue.find(b=>b.contact_user_id===e),s=Pe(e),n=s.primaryLabel,r=Fn(p.userId,"dm",e),a=xt(p.userId,e),i=jr(p.serverUrl,e);let o=xr();o||(o=await Wo()&&xr());const c=Xn[e],d=((fi=s.secondaryLabel)==null?void 0:fi.trim())||"",l=ls()?(c==null?void 0:c.status)==="online"?"online":(c==null?void 0:c.status)==="away"?"away":"encrypted":"secure chat",h=ls()?(c==null?void 0:c.status)==="online"?"presence-online":(c==null?void 0:c.status)==="away"?"presence-away":"":"",u=(a==null?void 0:a.fingerprintSha256)||"Not pinned yet",f=ei(t,a),m=f?"Verified":a?"Trusted":"Review safety",w=f?"Safety number confirmed on this browser.":a?"Pinned on this browser.":"Open Details to compare safety numbers.",x=i?"Saved on this browser":"Checked on first send",_=[l,d].filter(Boolean).join(" · ");let y="";if((mi=a==null?void 0:a.identityPqSigPub)!=null&&mi.trim()&&o&&Kn(p.userId))try{const b=await J();y=Ko(b,e,a.identityX25519Pub,a.identityPqSigPub)}catch{y=""}const k=a?y||"Unavailable until a fresh hybrid identity bundle is observed.":"Available after the first peer bundle is pinned.",I=f?"View Safety Number":"Verify Safety Number",L=o?"":"Web post-quantum runtime is unavailable in this build, so direct messages cannot be sent yet.",B=Kc({eyebrow:"Direct chat",avatarText:s.avatarText,title:n,subtitle:d||"Secure chat",body:"Start chatting here. Open Details when you need safety, shared media, or archive controls.",pills:[m]}),$=r.requestState==="pending"?`
      <div class="request-banner">
        <div>
          <strong>Message request</strong>
          <p>${v(n)} is not in your trusted chats yet.</p>
        </div>
        <div class="request-banner-actions">
          <button id="request-dismiss" class="btn-secondary">Dismiss</button>
          <button id="request-accept" class="btn-sm">Accept</button>
        </div>
      </div>
    `:"",{counts:U,visibleRows:A}=xs({kind:"dm",threadId:e});Ge.innerHTML=`
    <div class="desktop-shell desktop-thread-shell">
      ${Ss(A,U,{kind:"dm",threadId:e})}
      <div class="desktop-thread-pane">
    <div class="chat-shell">
      <header class="chat-header">
        <button id="chat-back" class="icon-btn" aria-label="Back to conversations">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div class="avatar-wrap">
          <div class="avatar avatar-sm">${s.avatarText}</div>
          ${h?`<span class="presence-dot ${h}"></span>`:""}
        </div>
        <div class="chat-header-info">
          <span class="chat-header-name">${v(n)}</span>
          <span class="chat-header-status ${h}" id="chat-status">${l}${s.secondaryLabel?` · ${v(s.secondaryLabel)}`:""}</span>
        </div>
        <button id="chat-search" class="icon-btn" title="Search in conversation" aria-label="Search in conversation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.5-3.5"></path>
          </svg>
        </button>
        <button id="chat-shortcuts" class="icon-btn" title="Keyboard shortcuts" aria-label="Keyboard shortcuts">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="5" width="18" height="14" rx="2"/>
            <path d="M7 9h.01M10 9h.01M13 9h.01M16 9h.01M8 13h8M7 16h4"/>
          </svg>
        </button>
        <button id="chat-details-toggle" class="icon-btn" title="Chat details" aria-label="Chat details">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>
          </svg>
        </button>
      </header>
      ${$}
      <div class="chat-context-strip" role="status" aria-live="polite">
        <span class="context-pill context-pill-secure">${v(m)}</span>
        <span class="chat-context-copy">${v(w)}</span>
        <button id="chat-open-details-inline" type="button" class="context-pill context-pill-link">Details</button>
      </div>
      <div id="thread-search-bar" class="thread-search-bar hidden" role="search">
        <input id="thread-search-input" type="text" class="thread-search-input" placeholder="Search in conversation" autocomplete="off" aria-label="Search in conversation" />
        <span id="thread-search-count" class="thread-search-count"></span>
        <div class="thread-search-actions">
          <button id="thread-search-prev" class="icon-btn" title="Previous result" aria-label="Previous result">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m15 18-6-6 6-6"/>
            </svg>
          </button>
          <button id="thread-search-next" class="icon-btn" title="Next result" aria-label="Next result">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </button>
          <button id="thread-search-close" class="icon-btn" title="Close search" aria-label="Close search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>
      ${L?`
        <div class="beta-banner beta-banner-warning chat-holdback-banner">
          <strong>Direct messaging unavailable</strong>
          <p>${v(L)}</p>
        </div>
      `:""}
      ${Nn()?`
        <div id="typing-indicator" class="typing-indicator hidden">
          <span class="typing-dots"><span></span><span></span><span></span></span>
          <span class="typing-text">${v(n)} is typing</span>
        </div>
      `:""}
      <div id="message-selection-bar" class="message-selection-bar hidden">
        <span id="message-selection-count" class="message-selection-count">0 selected</span>
        <div class="message-selection-actions">
          <button id="message-selection-copy" class="btn-secondary">Copy</button>
          <button id="message-selection-share" class="btn-secondary">Share</button>
          <button id="message-selection-delete" class="btn-secondary danger-lite">Delete</button>
          <button id="message-selection-close" class="btn-secondary">Close</button>
        </div>
      </div>
      <div id="chat-details-sheet" class="chat-details-sheet hidden">
        <div class="chat-details-card">
          <div class="chat-details-head">
            <div>
              <h3>${v(n)}</h3>
              <p>${s.secondaryLabel?v(s.secondaryLabel):"Direct message"}</p>
            </div>
            <button id="chat-details-close" class="icon-btn" aria-label="Close details">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6 6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <div class="chat-details-row"><span>Trust</span><strong>${v(m)}</strong></div>
          <div class="chat-details-row"><span>Transparency</span><strong>${v(x)}</strong></div>
          <div class="chat-details-row column"><span>Identity fingerprint</span><span class="mono fingerprint">${v(u)}</span></div>
          <div class="chat-details-row column"><span>Safety number</span><span class="mono fingerprint">${v(k)}</span></div>
          <div class="chat-details-row">
            <span>Sealed sender</span>
            <strong>Required</strong>
          </div>
          <div class="chat-details-row">
            <span>Disappearing messages</span>
            <strong>Unavailable</strong>
          </div>
          <div class="chat-details-row">
            <span>Shared media</span>
            <strong id="detail-shared-media-count">0 items</strong>
          </div>
          <div class="chat-details-actions">
            <button id="detail-shared-media" class="btn-secondary">Shared media</button>
            <button id="detail-verify-safety" class="btn-secondary" ${a?"":"disabled"}>${I}</button>
            <button id="detail-pin" class="btn-secondary">${r.pinnedAt?"Unpin Chat":"Pin Chat"}</button>
            <button id="detail-archive" class="btn-secondary">${r.archivedAt?"Unarchive":"Archive"}</button>
          </div>
        </div>
      </div>
      <div class="messages-container" id="messages-container">
        <div class="messages" id="messages-list" role="log" aria-live="polite"></div>
      </div>
      <div id="attachment-preview" class="attachment-preview hidden" aria-live="polite"></div>
      <div id="chat-emoji-tray" class="emoji-tray hidden" aria-label="Quick emoji"></div>
      <div id="chat-input-bar" class="chat-input-bar">
        <button id="chat-emoji" class="icon-btn attach-btn" title="Insert emoji" aria-label="Insert emoji">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="9"/>
            <path d="M8.5 15a5 5 0 0 0 7 0"/>
            <path d="M9 10h.01M15 10h.01"/>
          </svg>
        </button>
        <button id="chat-attach" class="icon-btn attach-btn" title="Attach file" aria-label="Attach file">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/>
          </svg>
        </button>
        <button id="chat-expand-compose" class="icon-btn attach-btn" title="Expand composer" aria-label="Expand composer">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>
          </svg>
        </button>
        <textarea id="chat-input" class="chat-compose-input" rows="1" placeholder="Write a message" aria-label="Message"></textarea>
        <button id="chat-send" class="send-btn" disabled aria-label="Send message">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        </button>
        <input id="file-input" type="file" class="hidden" />
      </div>
      <div id="attachment-sheet" class="attachment-sheet hidden" aria-hidden="true">
        <div class="attachment-sheet-card" role="dialog" aria-modal="true" aria-labelledby="attachment-sheet-title">
          <div class="attachment-sheet-head">
            <div>
              <h3 id="attachment-sheet-title">Share something</h3>
              <p>Choose what to send in this chat.</p>
            </div>
            <button id="attachment-sheet-close" class="icon-btn" aria-label="Close attachment options">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <div class="attachment-sheet-grid">
            <button class="attachment-option" data-attach-kind="camera">
              <span class="attachment-option-icon camera">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M4 7h4l2-2h4l2 2h4a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2z"/>
                  <circle cx="12" cy="13" r="4"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Camera</strong>
                <span>Capture a photo or video</span>
              </span>
            </button>
            <button class="attachment-option" data-attach-kind="media">
              <span class="attachment-option-icon media">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="3" y="4" width="18" height="16" rx="3"/>
                  <circle cx="9" cy="10" r="2"/>
                  <path d="M21 16l-4.5-4.5L7 21"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Photos & Videos</strong>
                <span>Pick from your library</span>
              </span>
            </button>
            <button class="attachment-option" data-attach-kind="audio">
              <span class="attachment-option-icon audio">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 4a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V7a3 3 0 0 1 3-3z"/>
                  <path d="M19 11a7 7 0 0 1-14 0"/>
                  <path d="M12 18v3"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Audio</strong>
                <span>Share a sound file</span>
              </span>
            </button>
            <button class="attachment-option" data-attach-kind="document">
              <span class="attachment-option-icon document">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z"/>
                  <path d="M14 2v5h5"/>
                  <path d="M9 13h6M9 17h6"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Document</strong>
                <span>Browse files and folders</span>
              </span>
            </button>
          </div>
          <div class="attachment-sheet-actions">
            <button id="attachment-sheet-cancel" class="btn-secondary">Cancel</button>
          </div>
        </div>
      </div>
      <div id="chat-expanded-compose" class="expanded-compose-sheet hidden" aria-hidden="true">
        <div class="expanded-compose-card" role="dialog" aria-modal="true" aria-labelledby="chat-expanded-title">
          <div class="expanded-compose-head">
            <div>
              <h3 id="chat-expanded-title">Expanded composer</h3>
              <p>Use Shift+Enter for a new line and Ctrl+Enter to send.</p>
            </div>
            <button id="chat-expanded-close" class="icon-btn" aria-label="Close expanded composer">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <textarea id="chat-expanded-input" class="expanded-compose-input" rows="6" placeholder="Write a message"></textarea>
          <div class="expanded-compose-actions">
            <button id="chat-expanded-send" class="btn-primary">Send</button>
          </div>
        </div>
      </div>
    </div>
      </div>
    </div>
  `,Is();const E=g("#messages-list"),G=g("#messages-container"),N=Mn(p.userId,e);E.dataset.conversationId=N;const M=g("#chat-input"),O=g("#chat-send"),Z=g("#message-selection-bar"),se=g("#message-selection-count"),de=g("#message-selection-copy"),ie=g("#message-selection-share"),ae=g("#message-selection-delete"),Ce=g("#message-selection-close"),he=g("#chat-input-bar"),le=g("#thread-search-bar"),Me=g("#thread-search-input"),st=g("#thread-search-count"),je=g("#thread-search-prev"),Ae=g("#thread-search-next"),be=g("#thread-search-close"),Ut=g("#chat-emoji"),We=g("#chat-attach"),nt=g("#chat-expand-compose"),Se=g("#file-input"),Ze=g("#chat-details-sheet"),rt=document.querySelector(".desktop-thread-pane"),Vt=g("#chat-open-details-inline"),Ps=g("#chat-status"),ln=g("#detail-shared-media"),ms=g("#detail-shared-media-count"),ve=g("#attachment-sheet"),$e=g("#attachment-preview"),ft=g("#chat-emoji-tray"),ct=g("#chat-expanded-compose"),_e=g("#chat-expanded-input"),un=g("#chat-expanded-close"),Ms=g("#chat-expanded-send");rt&&Wc()&&(Ze.classList.add("desktop-side-panel"),rt.appendChild(Ze),Ln(rt));let zt=!1,mt=null,Be=null;const pn=Er(p.userId,"dm",e);Ps.textContent=_,pn&&(M.value=pn,_e.value=pn,wt(M),wt(_e));const Ue=async()=>{await Xc(N,E,Z,se,he,$e)},dt=()=>{const b=zt,T=!!(Qe!=null&&Qe.allowEmptyText);O.disabled=!o||!M.value.trim()&&!mt&&!T||b,We.disabled=b,Ut.disabled=b,nt.disabled=b,Ms.disabled=O.disabled},lt=(b,T=!0)=>{M.value!==b&&(M.value=b),_e.value!==b&&(_e.value=b),wt(M),wt(_e),dt(),T&&ec(p.userId,"dm",e,b)},sr=()=>{O.textContent="",O.innerHTML='<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>'},nr=b=>{const T=b.at(-1),K=Va(p.userId).find(Te=>Te.peerUserId===e);as(p.userId,e,T?Xi(T):"No messages yet",!1,(T==null?void 0:T.timestamp)??(K==null?void 0:K.updatedAt)??Date.now()),Oe()},Bs=async b=>{var K;if(b.length===0)return;await Xo(b),De&&b.includes(De.msgId)&&(De=null,(K=document.querySelector(".reply-compose-bar"))==null||K.remove()),Qe&&b.includes(Qe.msgId)&&(Qe=null,sr(),lt("")),Ve(N);const T=await ze(N);Ks(E,T,B),nr(T),ge(!1),await Ue()},S=()=>{ct.classList.remove("hidden"),ct.setAttribute("aria-hidden","false"),lt(M.value,!1),_e.focus();const b=_e.value.length;_e.setSelectionRange(b,b)},P=(b=!0)=>{lt(_e.value),ct.classList.add("hidden"),ct.setAttribute("aria-hidden","true"),b&&M.focus()};let H=0;const ge=(b=!0)=>{var oe;if(le.classList.contains("hidden")){E.dataset.threadSearchQuery="",E.dataset.threadSearchActiveId="",Ne(E);return}const T=Me.value.trim();if(E.dataset.threadSearchQuery=T,!T){E.dataset.threadSearchActiveId="",Ne(E),st.textContent="Type to search this conversation",je.disabled=!0,Ae.disabled=!0;return}let K=Ne(E);if(K.length===0){H=0,E.dataset.threadSearchActiveId="",Ne(E),st.textContent="No matches",je.disabled=!0,Ae.disabled=!0;return}H>=K.length&&(H=0);const Te=K[H];E.dataset.threadSearchActiveId=Te,K=Ne(E),st.textContent=`${H+1} of ${K.length}`,je.disabled=K.length<2,Ae.disabled=K.length<2,b&&((oe=E.querySelector(`#msg-${CSS.escape(Te)}`))==null||oe.scrollIntoView({behavior:"smooth",block:"center"}))},gt=()=>{we(N)&&(Ve(N),Ue()),le.classList.remove("hidden"),Me.focus(),Me.select(),ge(!1)},hn=(b=!0)=>{H=0,Me.value="",le.classList.add("hidden"),E.dataset.threadSearchQuery="",E.dataset.threadSearchActiveId="",Ne(E),st.textContent="",je.disabled=!0,Ae.disabled=!0,b&&M.focus()},Yr=b=>{if(!Me.value.trim())return;const K=Ne(E);K.length!==0&&(H=(H+b+K.length)%K.length,ge())},rr=()=>{M.placeholder=mt?"Add a caption":"Write a message"},Jr=()=>{Be&&(URL.revokeObjectURL(Be),Be=null),mt=null,$e.classList.add("hidden"),$e.innerHTML="",rr(),dt(),Ue()},ld=()=>{if(!mt){$e.classList.add("hidden"),$e.innerHTML="",rr(),dt(),Ue();return}Be&&(URL.revokeObjectURL(Be),Be=null);const b=mt,T=b.type||"application/octet-stream",K=fs(T);(T.startsWith("image/")||T.startsWith("video/")||T.startsWith("audio/"))&&(Be=URL.createObjectURL(b));const Te=T.startsWith("image/")&&Be?`<img src="${Be}" alt="${v(b.name)}" class="attachment-preview-thumb" />`:T.startsWith("video/")&&Be?`<video class="attachment-preview-thumb" src="${Be}" muted playsinline></video>`:T.startsWith("audio/")&&Be?`<audio class="attachment-preview-audio" controls src="${Be}"></audio>`:`<div class="attachment-preview-icon">${v(K.slice(0,1))}</div>`;$e.classList.remove("hidden"),$e.innerHTML=`
      <div class="attachment-preview-card">
        ${Te}
        <div class="attachment-preview-copy">
          <strong>${v(b.name)}</strong>
          <span>${v(K)} - ${ui(b.size)}</span>
        </div>
        <button id="attachment-preview-clear" class="icon-btn" type="button" aria-label="Remove attachment">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
    `,g("#attachment-preview-clear").addEventListener("click",Jr),rr(),dt(),Ue()},ud=b=>{const T=ct.classList.contains("hidden")?M:_e,K=T.selectionStart??T.value.length,Te=T.selectionEnd??K,oe=`${T.value.slice(0,K)}${b}${T.value.slice(Te)}`;lt(oe);const St=K+b.length;T.focus(),T.setSelectionRange(St,St)};ft.innerHTML=["😀","❤️","👍","🎉","🔥","😮","😭","🙏"].map(b=>`<button type="button" class="emoji-chip" data-emoji="${b}" aria-label="Insert ${b}">${b}</button>`).join(""),g("#chat-back").addEventListener("click",()=>{Ve(N),Jr(),cn=null,di(),R({screen:"conversations"})});const ar=()=>{Ze.classList.add("hidden"),Ln(rt)},pi=()=>{_n(),Ze.classList.remove("hidden"),Ln(rt)},hi=()=>{ar(),ci({title:`${n} shared media`,conversationId:N,emptyMessage:"No shared media in this chat yet."})};g("#chat-details-toggle").addEventListener("click",()=>{pi()}),g("#chat-search").addEventListener("click",()=>{gt()}),g("#chat-shortcuts").addEventListener("click",()=>{nn()}),Vt.addEventListener("click",()=>{pi()}),g("#chat-details-close").addEventListener("click",()=>{ar()}),ln.addEventListener("click",()=>{hi()}),Me.addEventListener("input",()=>{H=0,ge(!1)}),Me.addEventListener("keydown",b=>{if(b.key==="Enter"){b.preventDefault(),Yr(b.shiftKey?-1:1);return}b.key==="Escape"&&(b.preventDefault(),hn(!1))}),je.addEventListener("click",()=>Yr(-1)),Ae.addEventListener("click",()=>Yr(1)),be.addEventListener("click",()=>hn()),Ze.addEventListener("click",b=>{b.target===Ze&&ar()}),g("#detail-pin").addEventListener("click",()=>{const b=Uc("dm",e);D(b.pinnedAt?"Chat pinned":"Chat unpinned","success"),Oe(),On(e)}),g("#detail-verify-safety").addEventListener("click",()=>{(async()=>{try{await zv(e)}catch(b){D(`Safety-number verification failed: ${X(b)}`,"error")}})()}),g("#detail-archive").addEventListener("click",()=>{const b=!r.archivedAt;ks("dm",e,b),qc("dm",e,b),R({screen:"conversations"})});const Xr=document.getElementById("request-accept");Xr==null||Xr.addEventListener("click",()=>{Wt(e),D("Message request accepted","success"),On(e),Oe()});const Zr=document.getElementById("request-dismiss");Zr==null||Zr.addEventListener("click",()=>{Dc(e),D("Message request dismissed","info"),R({screen:"conversations"})}),Ut.addEventListener("click",()=>{ft.classList.toggle("hidden")}),nt.addEventListener("click",()=>{S()}),un.addEventListener("click",()=>P()),Ms.addEventListener("click",()=>{lt(_e.value),O.click()}),ct.addEventListener("click",b=>{b.target===ct&&P()});for(const b of ft.querySelectorAll("[data-emoji]"))b.addEventListener("click",()=>ud(b.dataset.emoji||""));M.addEventListener("input",()=>{lt(M.value),no(e,!0)}),_e.addEventListener("input",()=>{lt(_e.value),no(e,!0)}),M.addEventListener("focus",()=>{ft.classList.add("hidden")}),M.addEventListener("keydown",b=>{b.key==="Enter"&&!b.shiftKey&&!b.repeat&&!O.disabled&&!zt&&(b.preventDefault(),O.click())}),_e.addEventListener("keydown",b=>{if(b.key==="Enter"&&b.ctrlKey&&!Ms.disabled&&!zt){b.preventDefault(),Ms.click();return}b.key==="Escape"&&(b.preventDefault(),P(!1))}),dt(),rr(),wt(M),wt(_e),O.addEventListener("click",async()=>{var Te;const b=M.value.trim(),T=mt,K=!!(Qe!=null&&Qe.allowEmptyText);if(!(!b&&!T&&!K||zt)&&await us("direct")){if(Qe&&T){D("Finish editing before adding media","info");return}zt=!0,dt();try{if(Qe){const{msgId:yt}=Qe;if(Qe=null,sr(),await Zp(yt,b)){const Yt=await ze(N);Ks(E,Yt,B);const Jt=Yt.at(-1);Jt&&(as(p.userId,e,Xi(Jt),!1,Jt.timestamp),Oe())}M.value="",lt("");return}const oe=De?{...De}:null;if(De&&(De=null,(Te=document.querySelector(".reply-compose-bar"))==null||Te.remove()),Wt(e),ks("dm",e,!1),T){try{const yt=await J(),qt=new j(p.serverUrl),Yt=await T.arrayBuffer(),Jt=dd(Yt),or=T.type||"application/octet-stream",gd=rp(yt,e,or,Jt),yd=await qt.uploadFile({recipient_user_id:e,device_id:yt.deviceId,mime_type:or,file_bytes_base64:Jt},gd),yi={id:`local-${Date.now()}-${Math.random().toString(36).slice(2)}`,conversationId:Mn(p.userId,e),sender:p.userId,recipient:e,text:b,timestamp:Date.now(),status:"sent",fileId:yd.file_id,mimeType:or,fileName:T.name,attachmentByteLength:T.size,attachmentNoteText:b,replyToId:oe==null?void 0:oe.msgId,replyPreview:oe==null?void 0:oe.preview,contentType:oe?"reply":"text"};await Ys(yi),rn(E,yi,G);const bd=b?`You: ${b}`:`You: Sent ${fs(or).toLowerCase()}`;as(p.userId,e,bd,!1),jt(p.userId,e),lt(""),Jr(),Ot()}catch(yt){D(`Upload failed: ${X(yt)}`,"error")}return}const St=`local-${Date.now()}-${Math.random().toString(36).slice(2)}`,gi={id:St,conversationId:Mn(p.userId,e),sender:p.userId,recipient:e,text:b,timestamp:Date.now(),status:"sending",replyToId:oe==null?void 0:oe.msgId,replyPreview:oe==null?void 0:oe.preview,contentType:oe?"reply":"text"};lt(""),await Ys(gi),as(p.userId,e,`You: ${b}`,!1),jt(p.userId,e),rn(E,gi,G);try{const yt=await J(),qt=new j(p.serverUrl),Yt=await $c(yt,e,b),Jt=await Pc(yt,e,qt);await qt.sealedRelay(e,{delivery_token:Jt,message_bytes_base64:Yt}),await kn(St,"sent"),as(p.userId,e,`You: ${b}`,!1),jt(p.userId,e),Vs(St,"sent"),Ot()}catch(yt){await kn(St,"failed"),Vs(St,"failed");const qt=X(yt);Ba(qt)&&tr(Ee)?D(`Send failed: ${qa(p.userId)}`,"error",{actionLabel:"Repair saved keys",action:()=>{(async()=>{try{await cd(await J(),p.displayName||p.userId,dn()),await Nc(),D(`Repaired the saved keys for @${p.userId} on this development relay. Send again.`,"success")}catch(Yt){D(`Repair failed: ${X(Yt)}`,"error")}})()}}):D(`Send failed: ${Ba(qt)?qa(p.userId):qt}`,"error")}}finally{zt=!1,dt()}}});const pd=()=>{ve.classList.remove("hidden"),ve.setAttribute("aria-hidden","false"),g("[data-attach-kind='camera']").focus()},Qr=()=>{ve.classList.add("hidden"),ve.setAttribute("aria-hidden","true"),We.focus()},vi={camera:{accept:"image/*,video/*",capture:"environment"},media:{accept:"image/*,video/*"},audio:{accept:"audio/*"},document:{}},hd=b=>{const T=vi[b]??vi.document;T.accept?Se.setAttribute("accept",T.accept):Se.removeAttribute("accept"),T.capture?Se.setAttribute("capture",T.capture):Se.removeAttribute("capture"),ve.classList.add("hidden"),ve.setAttribute("aria-hidden","true"),Se.click()};We.addEventListener("click",()=>{ft.classList.add("hidden"),pd()}),g("#attachment-sheet-close").addEventListener("click",Qr),g("#attachment-sheet-cancel").addEventListener("click",Qr),ve.addEventListener("click",b=>{b.target===ve&&Qr()});for(const b of document.querySelectorAll("[data-attach-kind]"))b.addEventListener("click",()=>hd(b.dataset.attachKind||"document"));Se.addEventListener("change",()=>{var T;const b=(T=Se.files)==null?void 0:T[0];if(b){if(b.size>1e6){D("File too large (max 1 MB)","error"),Se.removeAttribute("accept"),Se.removeAttribute("capture"),Se.value="";return}mt=b,ld(),dt(),Se.removeAttribute("accept"),Se.removeAttribute("capture"),Se.value="",M.focus()}}),E.addEventListener("click",b=>{if(!we(N))return;const T=b.target.closest(".bubble");T&&(b.preventDefault(),Lr(N,T.id.replace("msg-","")),Ue())}),E.addEventListener("contextmenu",b=>{b.preventDefault();const T=b.target.closest(".bubble");if(!T)return;const K=T.id.replace("msg-","");if(we(N)){Lr(N,K),Ue();return}const Te=T.classList.contains("bubble-sent"),oe=T.getAttribute("data-server-mid");Mr(b,K,Te,oe?Number(oe):null,T,M,O,e,()=>{Ue()},{allowEdit:!0,allowServerDelete:!0,onLocalDelete:async St=>{await Bs([St]),D("Message deleted from this device","success")}})}),Ce.addEventListener("click",()=>{Ve(N),Ue()}),de.addEventListener("click",async()=>{if(!we(N))return;const b=(await ze(N)).filter(T=>F==null?void 0:F.selectedIds.has(T.id));await navigator.clipboard.writeText(b.map(T=>ht(T)).join(`

`)),D("Messages copied","success")}),ie.addEventListener("click",async()=>{if(!we(N))return;const T=(await ze(N)).filter(K=>F==null?void 0:F.selectedIds.has(K.id)).map(K=>ht(K)).join(`

`);if(navigator.share)try{await navigator.share({text:T})}catch{await navigator.clipboard.writeText(T)}else await navigator.clipboard.writeText(T);D("Selected messages ready to share","success")}),ae.addEventListener("click",async()=>{if(!we(N))return;const b=Array.from((F==null?void 0:F.selectedIds)??[]);b.length!==0&&(await Bs(b),D("Messages deleted from this device","success"))});const ea=()=>{if(!we(N))return null;const b=Array.from((F==null?void 0:F.selectedIds)??[])[0];return b?E.querySelector(`#msg-${CSS.escape(b)}`):null},vd=()=>{const b=ea();if(!b)return;const T=b.getBoundingClientRect(),K=b.id.replace("msg-","");Mr({clientX:T.right-12,clientY:T.top+Math.min(T.height/2,28)},K,b.classList.contains("bubble-sent"),b.getAttribute("data-server-mid")?Number(b.getAttribute("data-server-mid")):null,b,M,O,e,()=>{Ue()},{allowEdit:!0,allowServerDelete:!0,onLocalDelete:async Te=>{await Bs([Te]),D("Message deleted from this device","success")}})},fd=()=>{const b=ea();if(!b)return;const T=b.id.replace("msg-","");Ve(N),Ue(),(async()=>{var oe;const K=await ys(T),Te=(K?ht(K):((oe=b.querySelector(".bubble-text"))==null?void 0:oe.textContent)||"").replace(/\s+/g," ").trim();De={msgId:T,preview:Te.slice(0,60)},ai(M),M.focus()})()},md=()=>{const b=ea();if(!b)return;const T=b.getBoundingClientRect();ii(T.right-12,T.top+Math.min(T.height/2,28),b.id.replace("msg-",""),b)};Zc(b=>{const T=b.ctrlKey||b.metaKey,K=b.key.toLowerCase();if(T&&b.shiftKey&&K==="f"){b.preventDefault(),gt();return}if(T&&b.shiftKey&&K==="m"){b.preventDefault(),hi();return}if(T&&b.shiftKey&&K==="t"){b.preventDefault(),M.focus();return}if(T&&b.shiftKey&&K==="x"){b.preventDefault(),ct.classList.contains("hidden")?S():P(!1);return}if(T&&!b.shiftKey&&K==="u"){b.preventDefault(),We.click();return}if(b.key==="Escape"&&!le.classList.contains("hidden")){b.preventDefault(),hn(!1);return}if(b.key==="Escape"&&!ct.classList.contains("hidden")){b.preventDefault(),P(!1);return}if(b.key==="Escape"&&!Ze.classList.contains("hidden")){b.preventDefault(),ar();return}if(we(N)){if(b.key==="Escape"){b.preventDefault(),Ve(N),Ue();return}if(T&&b.shiftKey&&K==="s"){b.preventDefault(),ie.click();return}if(T&&b.shiftKey&&K==="d"){b.preventDefault(),ae.click();return}if(T&&b.shiftKey&&K==="r"&&((F==null?void 0:F.selectedIds.size)??0)===1){b.preventDefault(),fd();return}if(T&&b.shiftKey&&K==="e"&&((F==null?void 0:F.selectedIds.size)??0)===1){b.preventDefault(),md();return}!T&&b.shiftKey&&b.key==="F10"&&(b.preventDefault(),vd())}});const ta=await ze(N),ir=ta.filter(b=>at(b)).length;ms.textContent=ir===1?"1 item":`${ir} items`,ln.textContent=ir>0?`Shared media (${ir})`:"Shared media",Ks(E,ta,B),nr(ta),await Ue(),ge(!1),Ur(G),Zo()||(Qo(),nn()),M.focus(),$v(),Nn()&&Nv(e),Ja()&&Hv(),ls()&&Rv(e)}function Ks(e,t,s=""){var a;(a=t[0])!=null&&a.conversationId&&(e.dataset.conversationId=t[0].conversationId);const n=e.closest(".chat-shell");n==null||n.classList.toggle("thread-has-messages",t.length>0),e.innerHTML="",s&&t.length===0&&e.insertAdjacentHTML("beforeend",s);let r="";for(const i of t){const o=new Date(i.timestamp).toLocaleDateString();if(o!==r){r=o;const c=document.createElement("div");c.className="date-sep",c.textContent=od(i.timestamp),e.appendChild(c)}zc(e,i)}Vr(e),Ne(e),Pn(e)}function rn(e,t,s){var i;(i=e.closest(".chat-shell"))==null||i.classList.add("thread-has-messages");const n=e.lastElementChild,r=(n==null?void 0:n.getAttribute("data-date"))||"";if(new Date(t.timestamp).toLocaleDateString()!==r&&!(n!=null&&n.classList.contains("date-sep"))){const o=document.createElement("div");o.className="date-sep",o.textContent=od(t.timestamp),e.appendChild(o)}zc(e,t),Vr(e),Ne(e),Pn(e),id(),Ur(s)}const Fs=new Map;function at(e){return!!(e.fileId||e.attachmentDataBase64)}function er(e){return e.fileName||e.fileId||"attachment"}function Ls(e){return e.mimeType||"application/octet-stream"}function $a(e){return e.attachmentNoteText??e.text}function lv(e){return`inline:${e.id}`}function Fc(e){var s;const t=(s=e.attachmentDataBase64)==null?void 0:s.trim();if(!t)return null;try{const n=Uint8Array.from(atob(t),r=>r.charCodeAt(0));return new Blob([n],{type:Ls(e)})}catch{return null}}function Vc(e){if(e.fileId)return Fs.get(e.fileId)??null;const t=lv(e),s=Fs.get(t);if(s)return s;const n=Fc(e);if(!n)return null;const r=URL.createObjectURL(n);return Fs.set(t,r),r}function uv(e){const t=Fc(e);if(!t){D("Attachment is not available on this device","error");return}const s=URL.createObjectURL(t),n=document.createElement("a");n.href=s,n.download=er(e),n.click(),setTimeout(()=>URL.revokeObjectURL(s),6e4)}async function ri(e){if(e.fileId){await Lv(e.fileId);return}uv(e)}function pv(e){if(!at(e))return`<div class="bubble-text">${v(e.text)}</div>`;const t=Ls(e),s=er(e),n=Vc(e);return t.startsWith("image/")&&n?`<img src="${n}" alt="${v(s)}" class="media-img" loading="lazy" />`:t.startsWith("audio/")&&n?`<audio controls src="${n}" class="media-audio"></audio>`:t.startsWith("video/")&&n?`<video controls src="${n}" class="media-video"></video>`:e.fileId&&(t.startsWith("image/")||t.startsWith("audio/")||t.startsWith("video/"))?`<div class="media-loading" data-file-id="${v(e.fileId)}">Loading media…</div>`:`<button type="button" class="media-file-link">📎 ${v(s)}</button>`}function hv(e){if(!at(e))return`<div class="bubble-text">${v(e.text)}</div>`;const t=$a(e).trim(),s=t?`<div class="bubble-text bubble-media-caption">${v(t)}</div>`:"";return`${pv(e)}${s}`}function vv(e){return!e.replyToId||!e.replyPreview?"":`<button type="button" class="reply-quote" data-target-id="${v(e.replyToId)}">${v(e.replyPreview)}</button>`}function fv(e){return e===1?"1 reply":`${e} replies`}function Ta(e){if(!e.reactions||e.reactions.length===0)return"";const t=new Map;for(const n of e.reactions)t.set(n.emoji,(t.get(n.emoji)??0)+1);return`<div class="reaction-pills">${Array.from(t.entries()).map(([n,r])=>`<span class="reaction-pill" data-emoji="${n}">${n}${r>1?` ${r}`:""}</span>`).join("")}</div>`}function zc(e,t){if(t.contentType==="reaction")return;const s=t.sender===p.userId,n=document.createElement("div");n.className=`bubble ${s?"bubble-sent":"bubble-received"}`,n.id=`msg-${t.id}`,n.setAttribute("role","listitem"),n.setAttribute("data-date",new Date(t.timestamp).toLocaleDateString()),n.dataset.conversationId=t.conversationId,t.replyToId&&(n.dataset.replyToId=t.replyToId),t.serverMessageId&&n.setAttribute("data-server-mid",String(t.serverMessageId)),n.dataset.hasAttachment=at(t)?"1":"",n.dataset.searchText=$h(t).toLowerCase();const r=new Date(t.timestamp).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),a=s?Qc(t.status):"",i=t.editedAt?' <span class="edit-indicator">(edited)</span>':"";n.innerHTML=`
    ${vv(t)}
    ${hv(t)}
    <div class="bubble-meta">
      <span class="bubble-time">${r}${i}</span>
      ${a}
    </div>
    ${Ta(t)}
  `,e.appendChild(n),t.fileId&&!Fs.has(t.fileId)&&nd(t.fileId,n);const o=n.querySelector(".media-img");o&&o.addEventListener("click",()=>oi(o.src));const c=n.querySelector(".media-file-link");c&&c.addEventListener("click",l=>{l.preventDefault(),ri(t)});const d=n.querySelector(".reply-quote[data-target-id]");d&&d.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),gv(e,d.dataset.targetId||"")})}function Vr(e){var a,i;const t=Array.from(e.querySelectorAll(".bubble")),s=e.dataset.conversationId||((a=t[0])==null?void 0:a.dataset.conversationId)||"",n=new Map;for(const o of t){const c=o.dataset.replyToId;c&&n.set(c,(n.get(c)??0)+1)}let r=s?Gn.get(s)??null:null;r&&!t.some(o=>o.id===`msg-${r}`||o.dataset.replyToId===r)&&(r=null,s&&Gn.delete(s));for(const o of t){const c=o.id.replace("msg-",""),d=n.get(c)??0;let l=o.querySelector(".reply-thread-pill");if(d>0){if(!l){l=document.createElement("button"),l.type="button",l.className="reply-thread-pill";const f=o.querySelector(".bubble-meta");f?f.insertAdjacentElement("beforebegin",l):o.appendChild(l)}l.textContent=fv(d),l.dataset.targetId=c,l.onclick=f=>{f.preventDefault(),f.stopPropagation(),mv(e,c)},l.classList.toggle("reply-thread-pill-active",r===c)}else l&&l.remove();const h=r===c,u=!!r&&o.dataset.replyToId===r;o.classList.toggle("bubble-reply-source-active",h),o.classList.toggle("bubble-reply-active",u),(i=o.querySelector(".reply-quote"))==null||i.classList.toggle("reply-quote-active",u)}}function Ne(e){const t=Array.from(e.querySelectorAll(".bubble")),s=(e.dataset.threadSearchQuery||"").trim().toLowerCase(),n=e.dataset.threadSearchActiveId||"",r=[];for(const a of t){const i=a.id.replace("msg-",""),o=a.dataset.searchText||"",c=!!s&&o.includes(s);c&&r.push(i),a.classList.toggle("bubble-search-match",c),a.classList.toggle("bubble-search-active",c&&i===n)}return r}function mv(e,t){const s=e.dataset.conversationId||"";if(!s)return;const r=(Gn.get(s)??null)===t?null:t;if(Yc(e,r),!r)return;const a=Array.from(e.querySelectorAll(".bubble")).find(i=>i.dataset.replyToId===r);a==null||a.scrollIntoView({behavior:"smooth",block:"center"})}function Yc(e,t){const s=e.dataset.conversationId||"";s&&(t==null?Gn.delete(s):Gn.set(s,t),Vr(e))}function gv(e,t){if(!t)return;Yc(e,t);const s=e.querySelector(`#msg-${CSS.escape(t)}`);s==null||s.scrollIntoView({behavior:"smooth",block:"center"})}function we(e){return F?e?F.conversationId===e:!0:!1}function Jc(e,t){F={conversationId:e,selectedIds:new Set([t])}}function Lr(e,t){if(!we(e)){Jc(e,t);return}const s=F.selectedIds;s.has(t)?s.delete(t):s.add(t),s.size===0&&(F=null)}function Ve(e){F&&(e&&F.conversationId!==e||(F=null))}function Pn(e){const t=e.dataset.conversationId||"",s=we(t),n=s?F.selectedIds:null;e.classList.toggle("messages-selection-active",s);for(const r of e.querySelectorAll(".bubble")){const a=r.id.replace("msg-","");r.classList.toggle("bubble-selected",!!(n!=null&&n.has(a)))}}async function Xc(e,t,s,n,r,a){if(!we(e)){s.classList.add("hidden"),r.classList.remove("hidden"),a&&a.innerHTML.trim()&&a.classList.remove("hidden"),Pn(t);return}const i=await ze(e),o=new Set(i.map(c=>c.id));if(F.selectedIds.forEach(c=>{o.has(c)||F.selectedIds.delete(c)}),F.selectedIds.size===0){Ve(e),s.classList.add("hidden"),r.classList.remove("hidden"),Pn(t);return}n.textContent=`${F.selectedIds.size} selected`,s.classList.remove("hidden"),r.classList.add("hidden"),a==null||a.classList.add("hidden"),Pn(t)}function Zc(e){is==null||is();const t=s=>e(s);window.addEventListener("keydown",t),is=()=>{window.removeEventListener("keydown",t)}}function Vs(e,t){const s=document.getElementById(`msg-${e}`);if(!s)return;const n=s.querySelector(".bubble-meta");if(!n)return;const r=n.querySelector(".status-icon");r&&r.remove();const a=document.createElement("span");a.className="status-icon",a.innerHTML=Qc(t),n.appendChild(a)}function Qc(e){switch(e){case"sending":return'<span class="status-icon" title="Sending"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8899aa" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg></span>';case"sent":return'<span class="status-icon" title="Sent"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8899aa" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg></span>';case"delivered":return'<span class="status-icon" title="Delivered"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8899aa" stroke-width="2.5"><path d="M18 6L7 17l-5-5M22 6L11 17"/></svg></span>';case"failed":return'<span class="status-icon error-icon" title="Failed — tap to retry"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff5555" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></span>'}}async function yv(){const e=$s(await Xe());if(!e.directMessagingAllowed){it(`
      <section class="workspace-page-card">
        ${ot("Web messaging unavailable","This server is still holding the web client in demo-only mode.",{eyebrow:"New message",backButtonId:"nc-back",backButtonLabel:"Back to inbox"})}
        ${xe(e.title,e.detail,{eyebrow:"New message",compact:!0,actionsHtml:`
              <button id="nc-open-settings" class="btn-primary" type="button">Open settings</button>
              <button id="nc-back-to-inbox" class="btn-secondary" type="button">Back to inbox</button>
            `})}
      </section>
    `),g("#nc-back").addEventListener("click",()=>R({screen:"conversations"})),g("#nc-open-settings").addEventListener("click",()=>R({screen:"settings"})),g("#nc-back-to-inbox").addEventListener("click",()=>R({screen:"conversations"}));return}const t=ue.map(d=>{const l=Pe(d.contact_user_id),h=d.verified_by_qr?'<span class="verified-badge" title="Verified">✓</span>':"";return`
      <div class="contact-row" data-contact="${v(d.contact_user_id)}">
        <div class="avatar avatar-sm">${v(l.avatarText)}</div>
        <div class="contact-info">
          <span class="contact-name">${v(l.primaryLabel)}${h}</span>
          ${l.secondaryLabel?`<span class="contact-id">${v(l.secondaryLabel)}</span>`:""}
        </div>
      </div>
    `}).join("");it(`
    <section class="workspace-page-card">
      ${ot("Start chat",'Choose a contact or enter a shareable <span class="mono">@username</span> or invite link.',{eyebrow:"New message"})}
      <div class="new-chat-body">
        ${ue.length>0?`
          <div class="contacts-section">
            <h3 class="section-label">Contacts</h3>
            <div class="contacts-list">${t}</div>
          </div>
          <div class="divider-or"><span>or enter a username</span></div>
        `:""}
        <label class="field">
          <span>Username or invite link</span>
          <input id="nc-peer" type="text" placeholder="@username or invite link" autocomplete="off" />
        </label>
        <button id="nc-start" class="btn-primary">Start Chat</button>
        <p id="nc-status" class="onboarding-status"></p>
        <div class="invite-section">
          <button id="nc-invite" class="btn-secondary">Copy Invite Link</button>
        </div>
      </div>
    </section>
  `);const s=g("#nc-peer"),n=g("#nc-start"),r=g("#nc-status"),a=async d=>{r.textContent="",r.classList.remove("error-text");const l=n.textContent;n.disabled=!0,n.textContent="Checking...";try{const h=qn(d);let u;if(h){const f=new j(p.serverUrl);if(u=await Tr(h,f),u===p.userId)throw new Error("You can't chat with yourself");await Br(u),Wt(u),ks("dm",u,!1),as(p.userId,u,"New conversation",!1),jt(p.userId,u)}else u=await bh({rawTarget:d,currentUserId:p.userId},{ensureDirectChatPeerExists:si,resolveInviteToken:async f=>Tr(f),resolvePeerTarget:async f=>Fr(f),addContactSilent:Br,markConversationAccepted:Wt,setConversationArchived:ks,upsertConversation:as,markConversationRead:jt});R({screen:"chat",peerId:u})}catch(h){const u=qn(d)?"private invite":mc(d).replace(/^@/,""),f=Hc(u||"unknown",h);r.textContent=f,r.classList.add("error-text"),D(f,"error")}finally{n.disabled=!1,n.textContent=l}};g("#nc-start").addEventListener("click",()=>{a(s.value.trim())});for(const d of document.querySelectorAll("[data-contact]"))d.addEventListener("click",()=>{a(d.dataset.contact)});g("#nc-invite").addEventListener("click",()=>{(async()=>{try{const d=await J(),l=new j(p.serverUrl),h=tp(d),u=await l.createContactInvite(d.userId,h),f=`${location.origin}/?invite_token=${encodeURIComponent(u.invite_token)}&server=${encodeURIComponent(p.serverUrl)}`;await navigator.clipboard.writeText(f),D("Private invite link copied!","success")}catch{D("Could not create invite link","error")}})()});const i=new URLSearchParams(location.search),o=i.get("invite_token")||i.get("token"),c=i.get("invite");o?s.value=location.href:c&&c!==p.userId&&(s.value=c),s.focus()}async function ed(e){var Bs;const t=Zn(e);if(!t.available){const{counts:S,visibleRows:P}=xs({kind:"group",threadId:e});Ge.innerHTML=`
      <div class="desktop-shell desktop-thread-shell">
        ${Ss(P,S,{kind:"group",threadId:e})}
        <div class="desktop-thread-pane">
          <div class="chat-shell">
            <header class="chat-header">
              <button id="gc-back" class="icon-btn" aria-label="Back to conversations">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
              </button>
              <div class="chat-header-info">
                <span class="chat-header-name">Private Group</span>
                <span class="chat-header-status">${v(t.statusLine)}</span>
              </div>
            </header>
            <div class="messages-container">
              ${xe(t.title,t.body,{eyebrow:"Private group",compact:!0,actionsHtml:'<button id="gc-back-to-inbox" class="btn-secondary">Back to inbox</button>'})}
            </div>
          </div>
        </div>
      </div>
    `,g("#gc-back").addEventListener("click",()=>R({screen:"conversations"})),g("#gc-back-to-inbox").addEventListener("click",()=>R({screen:"conversations"}));return}const s=t.state,n=t.credential,r=!!kt(n).publish_key_base64,a=s.attributes.title||e,i=s,o=((Bs=i.members.find(S=>S.user_id===p.userId))==null?void 0:Bs.role)||"member",c=`${i.members.length} ${i.members.length===1?"member":"members"} / ${o}`,d=Kc({eyebrow:"Private group",avatarText:a.slice(0,2).toUpperCase()||e.slice(0,2).toUpperCase(),title:a,subtitle:c,body:r?"Invite people when you are ready. Group membership and history stay attached to this private group.":"Messages stay available here while membership updates continue from an owner device.",pills:[r?"Can invite":"Member view"],group:!0}),{counts:l,visibleRows:h}=xs({kind:"group",threadId:e});Ge.innerHTML=`
    <div class="desktop-shell desktop-thread-shell">
      ${Ss(h,l,{kind:"group",threadId:e})}
      <div class="desktop-thread-pane">
    <div class="chat-shell">
      <header class="chat-header">
        <button id="gc-back" class="icon-btn" aria-label="Back to conversations">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div class="avatar-wrap">
          <div class="avatar avatar-sm avatar-group">${v(a.slice(0,2).toUpperCase()||e.slice(0,2).toUpperCase())}</div>
        </div>
        <div class="chat-header-info">
          <span class="chat-header-name">${v(a)}</span>
          <span class="chat-header-status" id="gc-member-count">Private group</span>
        </div>
        <button id="gc-search" class="icon-btn" title="Search in conversation" aria-label="Search in conversation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.5-3.5"></path>
          </svg>
        </button>
        <button id="gc-shortcuts" class="icon-btn" title="Keyboard shortcuts" aria-label="Keyboard shortcuts">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="5" width="18" height="14" rx="2"/>
            <path d="M7 9h.01M10 9h.01M13 9h.01M16 9h.01M8 13h8M7 16h4"/>
          </svg>
        </button>
        <button id="gc-info" class="icon-btn" title="Group info" aria-label="Group info">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>
          </svg>
        </button>
      </header>
      <div class="chat-context-strip" role="status" aria-live="polite">
        <span class="context-pill context-pill-secure">${r?"Can invite":"Member view"}</span>
        <span class="chat-context-copy">${r?"Invite people from this browser when you need to.":"Membership changes are managed from an owner device."}</span>
        <button id="gc-open-details-inline" type="button" class="context-pill context-pill-link">Group info</button>
      </div>
      <div id="thread-search-bar" class="thread-search-bar hidden" role="search">
        <input id="thread-search-input" type="text" class="thread-search-input" placeholder="Search in conversation" autocomplete="off" aria-label="Search in conversation" />
        <span id="thread-search-count" class="thread-search-count"></span>
        <div class="thread-search-actions">
          <button id="thread-search-prev" class="icon-btn" title="Previous result" aria-label="Previous result">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m15 18-6-6 6-6"/>
            </svg>
          </button>
          <button id="thread-search-next" class="icon-btn" title="Next result" aria-label="Next result">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </button>
          <button id="thread-search-close" class="icon-btn" title="Close search" aria-label="Close search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>
      <div id="message-selection-bar" class="message-selection-bar hidden">
        <span id="message-selection-count" class="message-selection-count">0 selected</span>
        <div class="message-selection-actions">
          <button id="message-selection-copy" class="btn-secondary">Copy</button>
          <button id="message-selection-share" class="btn-secondary">Share</button>
          <button id="message-selection-delete" class="btn-secondary danger-lite">Delete</button>
          <button id="message-selection-close" class="btn-secondary">Close</button>
        </div>
      </div>
      <div class="messages-container" id="messages-container">
        <div class="messages" id="messages-list" role="log" aria-live="polite"></div>
      </div>
      <div id="group-attachment-preview" class="attachment-preview hidden" aria-live="polite"></div>
      <div id="group-input-bar" class="chat-input-bar">
        <button id="gc-attach" class="icon-btn attach-btn" title="Attach file" aria-label="Attach file">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21.44 11.05l-8.49 8.49a5 5 0 1 1-7.07-7.07l8.49-8.49a3.5 3.5 0 1 1 4.95 4.95l-8.5 8.49a2 2 0 0 1-2.82-2.83l7.78-7.78"/>
          </svg>
        </button>
        <button id="gc-expand-compose" class="icon-btn attach-btn" title="Expand composer" aria-label="Expand composer">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>
          </svg>
        </button>
        <textarea id="gc-input" class="chat-compose-input" rows="1" placeholder="Message ${v(a)}" aria-label="Group message"></textarea>
        <button id="gc-send" class="send-btn" aria-label="Send group message">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        </button>
      </div>
      <input id="group-file-input" type="file" class="hidden" />
      <p id="gc-status" class="text-secondary"></p>
      <div id="group-attachment-sheet" class="attachment-sheet hidden" aria-hidden="true">
        <div class="attachment-sheet-card" role="dialog" aria-modal="true" aria-labelledby="group-attachment-sheet-title">
          <div class="attachment-sheet-head">
            <div>
              <h3 id="group-attachment-sheet-title">Share something</h3>
              <p>Send photos, videos, audio, or files in this private group.</p>
            </div>
            <button id="group-attachment-sheet-close" class="icon-btn" aria-label="Close attachment options">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <div class="attachment-sheet-grid">
            <button class="attachment-option" data-group-attach-kind="camera">
              <span class="attachment-option-icon camera">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M4 7h3l2-2h6l2 2h3v12H4z"/><circle cx="12" cy="13" r="4"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Camera</strong>
                <span>Capture a photo or video</span>
              </span>
            </button>
            <button class="attachment-option" data-group-attach-kind="media">
              <span class="attachment-option-icon media">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Media</strong>
                <span>Choose from your library</span>
              </span>
            </button>
            <button class="attachment-option" data-group-attach-kind="audio">
              <span class="attachment-option-icon audio">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Audio</strong>
                <span>Share voice notes or audio files</span>
              </span>
            </button>
            <button class="attachment-option" data-group-attach-kind="document">
              <span class="attachment-option-icon document">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>
                </svg>
              </span>
              <span class="attachment-option-copy">
                <strong>Document</strong>
                <span>Share PDFs and other files</span>
              </span>
            </button>
          </div>
          <div class="attachment-sheet-actions">
            <button id="group-attachment-sheet-cancel" class="btn-secondary">Cancel</button>
          </div>
        </div>
      </div>
      <div id="gc-expanded-compose" class="expanded-compose-sheet hidden" aria-hidden="true">
        <div class="expanded-compose-card" role="dialog" aria-modal="true" aria-labelledby="gc-expanded-title">
          <div class="expanded-compose-head">
            <div>
              <h3 id="gc-expanded-title">Expanded composer</h3>
              <p>Use Shift+Enter for a new line and Ctrl+Enter to send.</p>
            </div>
            <button id="gc-expanded-close" class="icon-btn" aria-label="Close expanded composer">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <textarea id="gc-expanded-input" class="expanded-compose-input" rows="6" placeholder="Message ${v(a)}"></textarea>
          <div class="expanded-compose-actions">
            <button id="gc-expanded-send" class="btn-primary">Send</button>
          </div>
        </div>
      </div>
    </div>
      </div>
    </div>
  `,Is();const u=g("#messages-list"),f=g("#messages-container"),m=`group:${e}`;u.dataset.conversationId=m;const w=g("#gc-input"),x=g("#gc-send"),_=g("#gc-member-count"),y=g("#gc-attach"),k=g("#gc-expand-compose"),I=g("#group-file-input"),L=g("#gc-status"),B=g("#group-attachment-preview"),$=g("#group-attachment-sheet"),U=g("#message-selection-bar"),A=g("#message-selection-count"),E=g("#message-selection-copy"),G=g("#message-selection-share"),N=g("#message-selection-delete"),M=g("#message-selection-close"),O=g("#group-input-bar"),Z=g("#thread-search-bar"),se=g("#thread-search-input"),de=g("#thread-search-count"),ie=g("#thread-search-prev"),ae=g("#thread-search-next"),Ce=g("#thread-search-close"),he=g("#gc-expanded-compose"),le=g("#gc-expanded-input"),Me=g("#gc-expanded-close"),st=g("#gc-expanded-send");let je=!1,Ae=null,be=null;bv(e),i?_.textContent=`${i.members.length} ${i.members.length===1?"member":"members"} / ${o}`:_.textContent="Private group";const Ut=Er(p.userId,"group",e);Ut&&(w.value=Ut,le.value=Ut,wt(w),wt(le));const We=()=>{const S=je,P=!!(w.value.trim()||Ae);x.disabled=S||!P,y.disabled=S,k.disabled=S,st.disabled=S||!P},nt=(S,P=!0)=>{w.value!==S&&(w.value=S),le.value!==S&&(le.value=S),wt(w),wt(le),We(),P&&ec(p.userId,"group",e,S)},Se=S=>{const P=S.at(-1),H=As(p.userId).find(ge=>ge.groupId===e);zn(p.userId,e,(H==null?void 0:H.ownerUserId)??Qn(s),P?Th(P):"No messages yet",!1,(P==null?void 0:P.timestamp)??(H==null?void 0:H.updatedAt)??Date.now()),Oe()},Ze=async S=>{var H;if(S.length===0)return;await Xo(S),De&&S.includes(De.msgId)&&(De=null,(H=document.querySelector(".reply-compose-bar"))==null||H.remove()),Ve(m);const P=await ze(m);Ks(u,P,d),Se(P),ft(!1),await ve()},rt=()=>{w.placeholder=Ae?`Add a caption for ${a}`:`Message ${a}`},Vt=()=>{be&&(URL.revokeObjectURL(be),be=null),Ae=null,B.classList.add("hidden"),B.innerHTML="",rt(),We(),ve()},Ps=()=>{if(!Ae){B.classList.add("hidden"),B.innerHTML="",rt(),We(),ve();return}be&&(URL.revokeObjectURL(be),be=null);const S=Ae,P=S.type||"application/octet-stream",H=fs(P);(P.startsWith("image/")||P.startsWith("video/")||P.startsWith("audio/"))&&(be=URL.createObjectURL(S));const ge=P.startsWith("image/")&&be?`<img src="${be}" alt="${v(S.name)}" class="attachment-preview-thumb" />`:P.startsWith("video/")&&be?`<video class="attachment-preview-thumb" src="${be}" muted playsinline></video>`:P.startsWith("audio/")&&be?`<audio class="attachment-preview-audio" controls src="${be}"></audio>`:`<div class="attachment-preview-icon">${v(H.slice(0,1))}</div>`;B.classList.remove("hidden"),B.innerHTML=`
      <div class="attachment-preview-card">
        ${ge}
        <div class="attachment-preview-copy">
          <strong>${v(S.name)}</strong>
          <span>${v(H)} - ${ui(S.size)}</span>
        </div>
        <button id="group-attachment-preview-clear" class="icon-btn" type="button" aria-label="Remove attachment">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
    `,g("#group-attachment-preview-clear").addEventListener("click",Vt),rt(),We(),ve()},ln=()=>{he.classList.remove("hidden"),he.setAttribute("aria-hidden","false"),nt(w.value,!1),le.focus();const S=le.value.length;le.setSelectionRange(S,S)},ms=(S=!0)=>{nt(le.value),he.classList.add("hidden"),he.setAttribute("aria-hidden","true"),S&&w.focus()},ve=async()=>{await Xc(m,u,U,A,O,B)};let $e=0;const ft=(S=!0)=>{var gt;if(Z.classList.contains("hidden")){u.dataset.threadSearchQuery="",u.dataset.threadSearchActiveId="",Ne(u);return}const P=se.value.trim();if(u.dataset.threadSearchQuery=P,!P){u.dataset.threadSearchActiveId="",Ne(u),de.textContent="Type to search this conversation",ie.disabled=!0,ae.disabled=!0;return}let H=Ne(u);if(H.length===0){$e=0,u.dataset.threadSearchActiveId="",Ne(u),de.textContent="No matches",ie.disabled=!0,ae.disabled=!0;return}$e>=H.length&&($e=0);const ge=H[$e];u.dataset.threadSearchActiveId=ge,H=Ne(u),de.textContent=`${$e+1} of ${H.length}`,ie.disabled=H.length<2,ae.disabled=H.length<2,S&&((gt=u.querySelector(`#msg-${CSS.escape(ge)}`))==null||gt.scrollIntoView({behavior:"smooth",block:"center"}))},ct=()=>{we(m)&&(Ve(m),ve()),Z.classList.remove("hidden"),se.focus(),se.select(),ft(!1)},_e=(S=!0)=>{$e=0,se.value="",Z.classList.add("hidden"),u.dataset.threadSearchQuery="",u.dataset.threadSearchActiveId="",Ne(u),de.textContent="",ie.disabled=!0,ae.disabled=!0,S&&w.focus()},un=S=>{if(!se.value.trim())return;const H=Ne(u);H.length!==0&&($e=($e+S+H.length)%H.length,ft())};g("#gc-back").addEventListener("click",()=>{Ve(m),Vt(),ws=null,R({screen:"conversations"})}),g("#gc-info").addEventListener("click",()=>{Ve(m),R({screen:"group-info",groupId:e})}),g("#gc-open-details-inline").addEventListener("click",()=>{Ve(m),R({screen:"group-info",groupId:e})}),g("#gc-search").addEventListener("click",()=>{ct()});const Ms=()=>{ci({title:`${a} shared media`,conversationId:m,emptyMessage:"No shared media in this group yet."})},zt=()=>{$.classList.remove("hidden"),$.setAttribute("aria-hidden","false"),g("[data-group-attach-kind='camera']").focus()},mt=()=>{$.classList.add("hidden"),$.setAttribute("aria-hidden","true"),y.focus()},Be={camera:{accept:"image/*,video/*",capture:"environment"},media:{accept:"image/*,video/*"},audio:{accept:"audio/*"},document:{}},pn=S=>{const P=Be[S]??Be.document;P.accept?I.setAttribute("accept",P.accept):I.removeAttribute("accept"),P.capture?I.setAttribute("capture",P.capture):I.removeAttribute("capture"),$.classList.add("hidden"),$.setAttribute("aria-hidden","true"),I.click()};y.addEventListener("click",()=>{zt()}),g("#group-attachment-sheet-close").addEventListener("click",mt),g("#group-attachment-sheet-cancel").addEventListener("click",mt),$.addEventListener("click",S=>{S.target===$&&mt()});for(const S of document.querySelectorAll("[data-group-attach-kind]"))S.addEventListener("click",()=>pn(S.dataset.groupAttachKind||"document"));I.addEventListener("change",()=>{var P;const S=(P=I.files)==null?void 0:P[0];if(S){if(S.size>1e6){D("File too large (max 1 MB)","error"),I.removeAttribute("accept"),I.removeAttribute("capture"),I.value="";return}Ae=S,Ps(),We(),I.removeAttribute("accept"),I.removeAttribute("capture"),I.value="",w.focus()}}),k.addEventListener("click",()=>{ln()}),Me.addEventListener("click",()=>ms()),st.addEventListener("click",()=>{nt(le.value),x.click()}),he.addEventListener("click",S=>{S.target===he&&ms()}),g("#gc-shortcuts").addEventListener("click",()=>{nn()}),se.addEventListener("input",()=>{$e=0,ft(!1)}),se.addEventListener("keydown",S=>{if(S.key==="Enter"){S.preventDefault(),un(S.shiftKey?-1:1);return}S.key==="Escape"&&(S.preventDefault(),_e(!1))}),ie.addEventListener("click",()=>un(-1)),ae.addEventListener("click",()=>un(1)),Ce.addEventListener("click",()=>_e()),await Ec(e).catch(()=>{});const Ue=await ze(m);Ks(u,Ue,d),Se(Ue),await ve(),ft(!1),Ur(f),Zo()||(Qo(),nn()),u.addEventListener("click",S=>{if(!we(m))return;const P=S.target.closest(".bubble");P&&(S.preventDefault(),Lr(m,P.id.replace("msg-","")),ve())}),u.addEventListener("contextmenu",S=>{S.preventDefault();const P=S.target.closest(".bubble");if(!P)return;const H=P.id.replace("msg-","");if(we(m)){Lr(m,H),ve();return}const ge=P.classList.contains("bubble-sent"),gt=P.getAttribute("data-server-mid");Mr(S,H,ge,gt?Number(gt):null,P,w,x,void 0,()=>{ve()},{allowEdit:!1,allowServerDelete:!1,onLocalDelete:async hn=>{await Ze([hn]),D("Message deleted from this device","success")}})}),M.addEventListener("click",()=>{Ve(m),ve()}),E.addEventListener("click",async()=>{if(!we(m))return;const S=(await ze(m)).filter(P=>F==null?void 0:F.selectedIds.has(P.id));await navigator.clipboard.writeText(S.map(P=>ht(P)).join(`

`)),D("Messages copied","success")}),G.addEventListener("click",async()=>{if(!we(m))return;const P=(await ze(m)).filter(H=>F==null?void 0:F.selectedIds.has(H.id)).map(H=>ht(H)).join(`

`);if(navigator.share)try{await navigator.share({text:P})}catch{await navigator.clipboard.writeText(P)}else await navigator.clipboard.writeText(P);D("Selected messages ready to share","success")}),N.addEventListener("click",async()=>{if(!we(m))return;const S=Array.from((F==null?void 0:F.selectedIds)??[]);S.length!==0&&(await Ze(S),D("Messages deleted from this device","success"))});const dt=()=>{if(!we(m))return null;const S=Array.from((F==null?void 0:F.selectedIds)??[])[0];return S?u.querySelector(`#msg-${CSS.escape(S)}`):null},lt=()=>{const S=dt();if(!S)return;const P=S.getBoundingClientRect(),H=S.id.replace("msg-","");Mr({clientX:P.right-12,clientY:P.top+Math.min(P.height/2,28)},H,S.classList.contains("bubble-sent"),S.getAttribute("data-server-mid")?Number(S.getAttribute("data-server-mid")):null,S,w,x,void 0,()=>{ve()},{allowEdit:!1,allowServerDelete:!1,onLocalDelete:async ge=>{await Ze([ge]),D("Message deleted from this device","success")}})},sr=()=>{const S=dt();if(!S)return;const P=S.id.replace("msg-","");Ve(m),ve(),(async()=>{var gt;const H=await ys(P),ge=(H?ht(H):((gt=S.querySelector(".bubble-text"))==null?void 0:gt.textContent)||"").replace(/\s+/g," ").trim();De={msgId:P,preview:ge.slice(0,60)},ai(w),w.focus()})()},nr=()=>{const S=dt();if(!S)return;const P=S.getBoundingClientRect();ii(P.right-12,P.top+Math.min(P.height/2,28),S.id.replace("msg-",""),S)};Zc(S=>{const P=S.ctrlKey||S.metaKey,H=S.key.toLowerCase();if(P&&S.shiftKey&&H==="f"){S.preventDefault(),ct();return}if(P&&S.shiftKey&&H==="m"){S.preventDefault(),Ms();return}if(P&&S.shiftKey&&H==="t"){S.preventDefault(),w.focus();return}if(P&&S.shiftKey&&H==="x"){S.preventDefault(),he.classList.contains("hidden")?ln():ms(!1);return}if(S.key==="Escape"&&!Z.classList.contains("hidden")){S.preventDefault(),_e(!1);return}if(S.key==="Escape"&&!he.classList.contains("hidden")){S.preventDefault(),ms(!1);return}if(we(m)){if(S.key==="Escape"){S.preventDefault(),Ve(m),ve();return}if(P&&S.shiftKey&&H==="s"){S.preventDefault(),G.click();return}if(P&&S.shiftKey&&H==="d"){S.preventDefault(),N.click();return}if(P&&S.shiftKey&&H==="r"&&((F==null?void 0:F.selectedIds.size)??0)===1){S.preventDefault(),sr();return}if(P&&S.shiftKey&&H==="e"&&((F==null?void 0:F.selectedIds.size)??0)===1){S.preventDefault(),nr();return}!P&&S.shiftKey&&S.key==="F10"&&(S.preventDefault(),lt())}}),w.addEventListener("input",()=>{nt(w.value)}),le.addEventListener("input",()=>{nt(le.value)}),w.addEventListener("keydown",S=>{S.key==="Enter"&&!S.shiftKey&&!x.disabled&&!je&&(S.preventDefault(),x.click())}),le.addEventListener("keydown",S=>{if(S.key==="Enter"&&S.ctrlKey&&!st.disabled&&!je){S.preventDefault(),st.click();return}S.key==="Escape"&&(S.preventDefault(),ms(!1))}),nt(w.value,!1),rt(),We(),x.addEventListener("click",()=>{(async()=>{const S=w.value.trim(),P=Ae;if(!(!S&&!P)){je=!0,We(),L.classList.remove("error-text"),L.textContent="Sending...";try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");const H=await Lh(S,P);await Mh(e,H),nt(""),Vt(),L.textContent="Sent.";const ge=await ze(`group:${e}`);Ks(u,ge,d),Ur(f),Oe()}catch(H){L.textContent=X(H),L.classList.add("error-text")}finally{je=!1,nt(w.value,!1)}}})()})}async function bv(e){var a;const t=document.getElementById("gc-member-count");if(!t)return;const s=Zn(e);if(!s.available){t.textContent=s.statusLine;return}const{state:n}=s,r=((a=n.members.find(i=>i.user_id===p.userId))==null?void 0:a.role)||"member";t.textContent=`${n.members.length} members · epoch ${n.epoch} · your role ${r}`}async function La(e){var x,_;const t=Zn(e);if(!t.available){it(`
        <section class="workspace-page-card">
          ${ot("Group info","Review membership, trust, and local state for this private group.",{eyebrow:"Private groups",backButtonId:"gi-back",backButtonLabel:"Back to chat"})}
          <div class="settings-body">
            <div class="settings-section">
              <h3>${v(wc(e))}</h3>
              ${xe(t.title,t.body,{eyebrow:"Private group",compact:!0})}
            </div>
          </div>
        </section>
      `,{activeThread:{kind:"group",threadId:e}}),g("#gi-back").addEventListener("click",()=>R({screen:"group-chat",groupId:e}));return}const{state:s,credential:n}=t,a=!!kt(n).publish_key_base64,i=s.attributes.title||e,o=((x=s.members.find(y=>y.role==="Owner"))==null?void 0:x.user_id)||p.userId,c=((_=s.members.find(y=>y.user_id===p.userId))==null?void 0:_.role)||"Member",l=(await ze(`group:${e}`)).filter(y=>at(y)).length,h=s.members.map(y=>{const k=Pe(y.user_id),I=zh(y.user_id),L=a&&y.user_id!==p.userId&&y.role!=="Owner";return`
      <div class="contact-manage-row">
        <div>
          <span>${v(k.primaryLabel)}</span>
          <span class="text-secondary">${v(y.role)}</span>
          <div class="text-secondary">${v(I.summary)}</div>
          <div class="text-secondary">${v(I.detail)}</div>
        </div>
        <div class="contact-manage-actions">
          ${y.user_id===p.userId?'<span class="text-secondary">you</span>':""}
          ${a&&y.user_id!==p.userId?`<button class="btn-inline" data-private-group-invite="${v(y.user_id)}">Copy Invite</button>`:""}
          ${L?`<button class="btn-inline" data-private-group-remove="${v(y.user_id)}">Remove</button>`:""}
        </div>
      </div>
    `}).join("");it(`
      <section class="workspace-page-card">
        ${ot("Group info",`Epoch ${s.epoch} · ${s.members.length} members · Your role ${v(c)} · Owner ${v(Pe(o).primaryLabel)}`,{eyebrow:"Private groups",backButtonId:"gi-back",backButtonLabel:"Back to chat"})}
        <div class="settings-body">
          <div class="settings-section">
            <h3>${v(i)}</h3>
            <div class="settings-callout">
              <strong>${a?"You can manage invites from this browser.":"This browser can read and send, but not change membership."}</strong>
              <p>Trust for group members follows the same local safety-number and identity checks as your direct chats.</p>
            </div>
            <div id="gi-members">${h}</div>
          </div>
          <div class="settings-section">
            <h3 class="section-label">Shared Media</h3>
            <p class="text-secondary">${l===1?"1 attachment":`${l} attachments`} saved in this group on this device.</p>
            <button id="gi-shared-media" class="btn-secondary">Open Shared Media</button>
          </div>
          ${a?`
            <div class="settings-section">
              <h3 class="section-label">Add Member</h3>
              <label class="field">
                <span>User</span>
                <input id="gi-add-member" type="text" placeholder="@username, user ID, or invite link" autocomplete="off" />
              </label>
              <button id="gi-add-member-btn" class="btn-primary">Create member invite</button>
            </div>
          `:`
            <div class="settings-section">
              <p class="text-secondary">Only an owner or admin device can add people to this group.</p>
            </div>
          `}
          <p id="gi-status" class="text-secondary"></p>
        </div>
      </section>
    `,{activeThread:{kind:"group",threadId:e}}),g("#gi-back").addEventListener("click",()=>R({screen:"group-chat",groupId:e})),g("#gi-shared-media").addEventListener("click",()=>{ci({title:`${i} shared media`,conversationId:`group:${e}`,emptyMessage:"No shared media in this group yet."})});const u=g("#gi-status"),f=(y,k=!1)=>{u.textContent=y,u.classList.toggle("error-text",k)};ao("[data-private-group-invite]").forEach(y=>{y.addEventListener("click",()=>{(async()=>{var k;try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");const I=((k=y.dataset.privateGroupInvite)==null?void 0:k.trim())||"";if(!I)throw new Error("Private-group member ID is missing.");const L=new j(p.serverUrl),B=Ni(s,I),$=await Ji(L,s,n,B);await navigator.clipboard.writeText($),D(`Invite link for @${I} copied.`,"success"),f(`Invite link for @${I} copied.`)}catch(I){f(X(I),!0)}})()})}),ao("[data-private-group-remove]").forEach(y=>{y.addEventListener("click",()=>{(async()=>{var k;try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");const I=((k=y.dataset.privateGroupRemove)==null?void 0:k.trim())||"";if(!I)throw new Error("Private-group member ID is missing.");const L=new j(p.serverUrl),B=Fl(s,I,Math.floor(Date.now()/1e3)),$=Vi(B.member_credentials,p.userId),U=await Yi(L,B.next_state,n,B.member_credentials);Ar(B.next_state,$,U,`Removed @${I}`,!1),D(`Removed @${I} from ${i}.`,"success"),Oe(),await La(e)}catch(I){f(X(I),!0)}})()})});const m=document.getElementById("gi-add-member-btn"),w=document.getElementById("gi-add-member");m&&w&&(w.addEventListener("keydown",y=>{y.key==="Enter"&&(y.preventDefault(),m.click())}),m.addEventListener("click",()=>{(async()=>{try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");const y=w.value.trim();if(!y)throw new Error("Member target is required.");const k=new j(p.serverUrl),I=await Fr(y,k);if(!I)throw new Error("Member target could not be resolved.");if(I===p.userId)throw new Error("You are already in this private group.");if(s.members.some(E=>E.user_id===I))throw new Error(`@${I} is already a member of this private group.`);await si(y);const L=Kl(s,I,"Member",Math.floor(Date.now()/1e3)),B=Vi(L.member_credentials,p.userId),$=await Yi(k,L.next_state,n,L.member_credentials);Ar(L.next_state,B,$,`Added @${I}`,!1);const U=L.added_member_join_package||Ni(L.next_state,I),A=await Ji(k,L.next_state,B,U);await navigator.clipboard.writeText(A),await Br(I),D(`Invite link for @${I} copied.`,"success"),Oe(),await La(e)}catch(y){f(X(y),!0)}})()}))}async function _v(){const e=$s(await Xe());if(!e.groupMessagingAllowed){it(`
      <section class="workspace-page-card">
        ${ot("Private groups unavailable","This server is not exposing private-group messaging on the current web path.",{eyebrow:"Groups",backButtonId:"cg-back",backButtonLabel:"Back to inbox"})}
        ${xe(e.title,e.detail,{eyebrow:"Private groups",compact:!0,actionsHtml:`
              <button id="cg-open-settings" class="btn-primary" type="button">Open settings</button>
              <button id="cg-back-to-inbox" class="btn-secondary" type="button">Back to inbox</button>
            `})}
      </section>
    `),g("#cg-back").addEventListener("click",()=>R({screen:"conversations"})),g("#cg-open-settings").addEventListener("click",()=>R({screen:"settings"})),g("#cg-back-to-inbox").addEventListener("click",()=>R({screen:"conversations"}));return}const t=zi(),s=ue.map(i=>{const o=Pe(i.contact_user_id);return`
      <label class="contact-row contact-checkbox">
        <input type="checkbox" value="${v(i.contact_user_id)}" class="cg-member-cb" />
        <div class="avatar avatar-sm">${v(o.avatarText)}</div>
        <span class="contact-name">${v(o.primaryLabel)}</span>
      </label>
    `}).join("");Ge.innerHTML=`
    <div class="app-shell">
      <header class="topbar">
        <button id="cg-back" class="icon-btn" aria-label="Back">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 class="topbar-title">New Group</h1>
      </header>
      <div class="settings-body">
        <div class="beta-banner beta-banner-warning">
          <strong>Private groups stay client-managed</strong>
          <p>Creation and join use opaque group state plus share links. The server stores encrypted state and invite ciphertext only.</p>
        </div>
        <label class="field">
          <span>Group Name</span>
          <input id="cg-name" type="text" placeholder="e.g. project-team" autocomplete="off" />
        </label>
        ${ue.length>0?`
          <div class="contacts-section">
            <h3 class="section-label">Select Members</h3>
            <div class="contacts-list">${s}</div>
          </div>
        `:""}
        <button id="cg-create" class="btn-primary">Create Private Group</button>
        <div class="settings-section">
          <h3 class="section-label">Join Group Link</h3>
          <label class="field">
            <span>Share Link</span>
            <input id="cg-join-link" type="text" placeholder="Paste a private-group link" value="${v(t?location.href:"")}" autocomplete="off" />
          </label>
          <button id="cg-join" class="btn-secondary">Join Private Group</button>
        </div>
        <p id="cg-status" class="text-secondary"></p>
      </div>
    </div>
  `,av(),g("#cg-back").addEventListener("click",()=>R({screen:"conversations"}));const n=g("#cg-status"),r=g("#cg-name"),a=g("#cg-join-link");g("#cg-create").addEventListener("click",()=>{(async()=>{try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");if(!tt())throw new Error("Private-group bindings are unavailable in this browser.");const i=r.value.trim();if(!i)throw new Error("Group name is required.");const c=[...document.querySelectorAll(".cg-member-cb:checked")].map(m=>m.value.trim()).filter(m=>m&&m!==p.userId).map(m=>({user_id:m,role:"Member"})),d=Hl(p.userId,{title:i,description:null,avatar_hash_sha256:null,disappearing_message_timer_seconds:null},c,Math.floor(Date.now()/1e3)),l=jl(d,p.userId),h=new j(p.serverUrl),u=await Ih(h,l);Ar(d,l.authorizing_member_credential,u,"Private group created",!1);const f=[];for(const m of l.member_join_packages){if(m.member_user_id===p.userId)continue;const w=Bo(m.join_package),x=kt(l.authorizing_member_credential);if(!x.publish_key_base64)throw new Error("Current private-group credential cannot issue invites.");const _=await h.createPrivateGroupInvite({group_id:d.group_id,epoch:d.epoch,invite_commitment_sha256:Le(Uint8Array.from(w.envelope.invite_commitment_sha256)),invite_ciphertext_nonce_base64:C(Uint8Array.from(w.envelope.ciphertext.nonce)),invite_ciphertext_base64:C(Uint8Array.from(w.envelope.ciphertext.ciphertext)),invite_ciphertext_aad_base64:C(Uint8Array.from(w.envelope.ciphertext.aad)),authorizing_membership_handle_sha256:x.membership_handle_sha256,authorizing_publish_key_base64:x.publish_key_base64});f.push(`${m.member_user_id}: ${xc(p.serverUrl,_.invite_token,C(Uint8Array.from(w.invite_secret)))}`)}f.length>0?(await navigator.clipboard.writeText(f.join(`
`)),D("Private group created. Invite links copied.","success")):D("Private group created.","success"),n.textContent=f.length>0?"Group created. Invite links were copied to your clipboard.":"Group created.",R({screen:"group-chat",groupId:d.group_id})}catch(i){n.textContent=X(i),n.classList.add("error-text")}})()}),g("#cg-join").addEventListener("click",()=>{(async()=>{try{if(!await us("group"))throw new Error("Private-group messaging is disabled for this web profile.");if(!tt())throw new Error("Private-group bindings are unavailable in this browser.");const i=zi(a.value.trim());if(!i)throw new Error("Private-group link is invalid or missing its secret fragment.");const o=pt(p.serverUrl).toString().replace(/\/+$/,""),c=pt(i.serverUrl).toString().replace(/\/+$/,"");if(o!==c)throw new Error("Private-group links must target the current account server.");const d=new j(i.serverUrl),l=await d.resolvePrivateGroupInvite(i.inviteToken),h=Wl({group_id:l.group_id,epoch:l.epoch,invite_commitment_sha256:xh(l.invite_commitment_sha256),ciphertext:{nonce:[...W(l.invite_ciphertext_nonce_base64)],ciphertext:[...W(l.invite_ciphertext_base64)],aad:[...W(l.invite_ciphertext_aad_base64)]}},i.inviteSecretBase64),u=Gl(h),f=kt(u.member_credential),m=await d.fetchPrivateGroupState({membership_handle_sha256:f.membership_handle_sha256,fetch_key_base64:f.fetch_key_base64}),w=Le(Uint8Array.from(h.invite.snapshot.state_commitment_sha256));if(m.group_id!==u.state.group_id||m.epoch!==u.state.epoch)throw new Error("Private-group state fetch does not match the invite package.");if(w&&m.state_commitment_sha256!==w)throw new Error("Private-group state fetch failed commitment verification.");await d.consumePrivateGroupInvite(i.inviteToken),Ar(u.state,u.member_credential,m.state_commitment_sha256,"Joined private group",!1),D("Joined private group.","success"),n.textContent="Private group joined.",R({screen:"group-chat",groupId:u.state.group_id})}catch(i){n.textContent=X(i),n.classList.add("error-text")}})()})}function wv(e,t){var n;(n=document.querySelector(".delete-popup"))==null||n.remove();const s=document.createElement("div");s.className="delete-popup",s.innerHTML=`
    <button class="delete-popup-btn delete-popup-delete">Delete</button>
    <button class="delete-popup-btn delete-popup-cancel">Cancel</button>
  `,e.style.position="relative",e.appendChild(s),s.querySelector(".delete-popup-cancel").addEventListener("click",()=>s.remove()),s.querySelector(".delete-popup-delete").addEventListener("click",async()=>{s.remove();try{const r=await J(),a=new j(p.serverUrl),i=ap(r,[t]);await api.deleteInboxMessages(r.userId,{message_ids:[t]},i);const o=e.parentElement;e.remove(),o instanceof HTMLElement&&Vr(o),D("Message deleted","success")}catch(r){D(`Delete failed: ${X(r)}`,"error")}})}function kv(e,t){return{service_origin:e,manifest_issuer_ed25519_pub:t.manifest_issuer_ed25519_pub,ticket_issuer_ed25519_pub:t.ticket_issuer_ed25519_pub,protocol_version:t.protocol_version,ticket_format:t.ticket_format,lookup_protocol:t.lookup_protocol,privacy_mode:t.privacy_mode,directory_backend:t.directory_backend,host_enclave_protocol_version:t.host_enclave_protocol_version,host_release_id:t.host_release_id,enclave_release_id:t.enclave_release_id,match_result_format:t.match_result_format,oprf_suite:t.oprf_suite,evaluation_proof_mode:t.evaluation_proof_mode,oprf_public_key_ristretto255:t.oprf_public_key_ristretto255,attestation_mode:t.attestation_mode,attestation_verifier:t.attestation_verifier??null,enclave_measurement_hex:t.enclave_measurement_hex??null,attestation_pcrs_sha384:Pr(t.attestation_pcrs_sha384),attestation_document_format:t.attestation_document_format??null,attestation_document_sha256:t.attestation_document_sha256??null,attestation_challenge_mode:t.attestation_challenge_mode??null,observed_at:new Date().toISOString()}}function xv(e,t){const s=[];return e.service_origin!==t.service_origin&&s.push("service_origin"),e.manifest_issuer_ed25519_pub!==t.manifest_issuer_ed25519_pub&&s.push("manifest_issuer_ed25519_pub"),e.ticket_issuer_ed25519_pub!==t.ticket_issuer_ed25519_pub&&s.push("ticket_issuer_ed25519_pub"),e.protocol_version!==t.protocol_version&&s.push("protocol_version"),e.ticket_format!==t.ticket_format&&s.push("ticket_format"),e.lookup_protocol!==t.lookup_protocol&&s.push("lookup_protocol"),e.privacy_mode!==t.privacy_mode&&s.push("privacy_mode"),e.directory_backend!==t.directory_backend&&s.push("directory_backend"),e.host_enclave_protocol_version!==t.host_enclave_protocol_version&&s.push("host_enclave_protocol_version"),e.host_release_id!==t.host_release_id&&s.push("host_release_id"),e.enclave_release_id!==t.enclave_release_id&&s.push("enclave_release_id"),e.match_result_format!==t.match_result_format&&s.push("match_result_format"),e.oprf_suite!==t.oprf_suite&&s.push("oprf_suite"),e.evaluation_proof_mode!==t.evaluation_proof_mode&&s.push("evaluation_proof_mode"),e.oprf_public_key_ristretto255!==t.oprf_public_key_ristretto255&&s.push("oprf_public_key_ristretto255"),e.attestation_mode!==t.attestation_mode&&s.push("attestation_mode"),e.attestation_verifier!==t.attestation_verifier&&s.push("attestation_verifier"),e.enclave_measurement_hex!==t.enclave_measurement_hex&&s.push("enclave_measurement_hex"),JSON.stringify(Pr(e.attestation_pcrs_sha384))!==JSON.stringify(Pr(t.attestation_pcrs_sha384))&&s.push("attestation_pcrs_sha384"),e.attestation_document_format!==t.attestation_document_format&&s.push("attestation_document_format"),e.attestation_document_sha256!==t.attestation_document_sha256&&s.push("attestation_document_sha256"),e.attestation_challenge_mode!==t.attestation_challenge_mode&&s.push("attestation_challenge_mode"),s}async function td(e){if(e.contact_discovery_mode!=="private_service"||!e.contact_discovery_service_origin)throw new Error("Private contact discovery is not configured");const t=new j(p.serverUrl),s=pt(e.contact_discovery_service_origin).origin,n=[e.contact_discovery_attestation_verifier,e.contact_discovery_expected_measurement_hex,e.contact_discovery_attestation_document_sha256,e.contact_discovery_attestation_max_age_seconds].map(o=>o!=null&&o!=="");if(n.some(Boolean)&&!n.every(Boolean))throw new Error("Private contact discovery attestation contract is incomplete");const r=await t.getContactDiscoveryManifest(s);if(Ip(r,e.contact_discovery_ticket_issuer_ed25519_pub,e.contact_discovery_manifest_issuer_ed25519_pub||"",e.contact_discovery_attestation_verifier,e.contact_discovery_expected_measurement_hex,e.contact_discovery_expected_pcrs_sha384,e.contact_discovery_attestation_document_sha256),!e.contact_discovery_directory_backend||!e.contact_discovery_host_enclave_protocol_version||!e.contact_discovery_host_release_id||!e.contact_discovery_enclave_release_id||!e.contact_discovery_expected_manifest_contract_sha256||!e.contact_discovery_attestation_verifier||!e.contact_discovery_expected_measurement_hex||!e.contact_discovery_attestation_document_sha256||!e.contact_discovery_attestation_max_age_seconds)throw new Error("Private contact discovery backend contract is incomplete");const a=Sa(r);if(r.lookup_protocol!=="attested_enclave_voprf_directory_v1"||r.privacy_mode!=="enclave_backed_private_discovery_v1"||r.directory_backend!=="attested_enclave_directory_v1"||r.host_enclave_protocol_version!==1||!r.host_release_id||!r.enclave_release_id||r.match_result_format!=="contact_invite_token"||r.oprf_suite!=="ristretto255-sha512-v1"||r.evaluation_proof_mode!=="dleq_per_element_v1"||!r.oprf_public_key_ristretto255||r.attestation_mode!=="attested_enclave_v1"||!r.attestation_verifier||!r.enclave_measurement_hex||!r.attestation_document_format||!r.attestation_document_sha256||!r.attestation_challenge_mode)throw new Error("Unsupported contact discovery manifest");if(r.attestation_challenge_mode!=="nonce_b64_required_v1")throw new Error("Unsupported contact discovery attestation challenge mode");if(r.directory_backend!==e.contact_discovery_directory_backend||r.host_enclave_protocol_version!==e.contact_discovery_host_enclave_protocol_version||r.host_release_id!==e.contact_discovery_host_release_id||r.enclave_release_id!==e.contact_discovery_enclave_release_id||a!==e.contact_discovery_expected_manifest_contract_sha256)throw new Error("Contact discovery backend contract mismatch");if(r.attestation_document_sha256){const o=Cp(),c=await t.getContactDiscoveryAttestation(s,o);Ep(c,r.attestation_mode,r.attestation_verifier||"",r.enclave_measurement_hex||"",r.attestation_pcrs_sha384??null,r.manifest_issuer_ed25519_pub,o,a,r.host_release_id,r.enclave_release_id,r.oprf_public_key_ristretto255,r.attestation_document_sha256,e.contact_discovery_attestation_max_age_seconds||0)}let i="Not pinned";if(p.userId.trim()){const o=kv(s,r),c=ch(p.serverUrl,p.userId);if(c){const d=xv(c,o);if(d.length)throw new Error(`Contact discovery manifest continuity changed: ${d.join(", ")}`);i="Pinned on this device"}else i="Saved on this device";dh(p.serverUrl,p.userId,o)}return{manifest:r,continuityStatus:i}}function Pr(e){if(!e)return null;const t=Object.entries(e).sort(([s],[n])=>s.localeCompare(n));return t.length?Object.fromEntries(t):null}function sd(e){const t=Pr(e);return t?Object.entries(t).map(([s,n])=>`${s}=${n}`).join(", "):"not advertised"}function mn(e,t,s){if(t!==e)throw new Error(`Contact discovery ${s} contract mismatch`)}function gn(e,t,s){if(t!==e)throw new Error(`Contact discovery ${s} ticket mismatch`)}async function gr(){var u,f,m,w,x;const e=He?Cs(He.identityX25519Pub,He.identityPqSigPub):"not available",t=await Xe(),s=$s(t),n=(t==null?void 0:t.contact_discovery_supported)??!1,r=(t==null?void 0:t.contact_discovery_mode)??"manual_only";let a=null,i=r==="private_service"?"Unavailable":"N/A",o=r==="private_service"?"Manifest unavailable":"Manual-only";if(r==="private_service"&&(t!=null&&t.contact_discovery_service_origin))try{const _=await td(t);a=_.manifest,o=`Verified (${a.attestation_mode})`,i=_.continuityStatus}catch(_){o=_ instanceof Error?_.message:"Manifest unavailable",i=o.includes("continuity changed")?"Changed on this device":"Unavailable"}const c=ue.length,d=`
    <div class="settings-overview-list">
      <article class="settings-overview-row">
        <div class="settings-overview-copy">
          <span class="settings-summary-kicker">People</span>
          <strong>${c} ${c===1?"trusted contact":"trusted contacts"}</strong>
          <p>${v(r==="private_service"?"Manual contacts stay primary. Discovery remains a secondary privacy surface.":"Add people by exact username or invite link.")}</p>
        </div>
        <span class="settings-overview-meta">${v(r==="private_service"?"advanced discovery available":"invite-first")}</span>
      </article>
      <article class="settings-overview-row">
        <div class="settings-overview-copy">
          <span class="settings-summary-kicker">Privacy</span>
          <strong>${v(r==="private_service"?"Hardened discovery checks":"Manual privacy flow")}</strong>
          <p>${v(r==="private_service"?"Manifest continuity and attestation are checked before future private lookups.":"Share usernames and private invites instead of raw-hash discovery.")}</p>
        </div>
        <span class="settings-overview-meta">${v(r==="private_service"?i:"exact username lookup")}</span>
      </article>
      <article class="settings-overview-row">
        <div class="settings-overview-copy">
          <span class="settings-summary-kicker">Devices</span>
          <strong>${v(p.deviceId)}</strong>
          <p>Manage linked devices, revoke old browsers, and keep this local profile protected.</p>
        </div>
        <span class="settings-overview-meta">current browser profile</span>
      </article>
    </div>
  `,l=r==="private_service"?`
        <details class="settings-inline-details">
          <summary>Technical contract</summary>
          <div class="settings-inline-details-body">
            <div class="settings-row"><span>Service Origin</span><span class="mono">${v((t==null?void 0:t.contact_discovery_service_origin)||"not configured")}</span></div>
            <div class="settings-row"><span>Lookup Protocol</span><span>${v((a==null?void 0:a.lookup_protocol)||"unknown")}</span></div>
            <div class="settings-row"><span>Evaluation Proof</span><span>${v((a==null?void 0:a.evaluation_proof_mode)||"unknown")}</span></div>
            <div class="settings-row"><span>Attestation Verifier</span><span class="mono">${v((a==null?void 0:a.attestation_verifier)||"not advertised")}</span></div>
            <div class="settings-row"><span>Enclave Measurement</span><span class="mono">${v((a==null?void 0:a.enclave_measurement_hex)||"not advertised")}</span></div>
            <div class="settings-row"><span>Attestation PCRs</span><span class="mono">${v(sd(a==null?void 0:a.attestation_pcrs_sha384))}</span></div>
            <div class="settings-row"><span>Attestation Max Age</span><span>${v(t!=null&&t.contact_discovery_attestation_max_age_seconds?`${t.contact_discovery_attestation_max_age_seconds}s`:"not advertised")}</span></div>
          </div>
        </details>
      `:"";it(`
    <section class="workspace-page-card">
      ${ot("Settings","Account, people, devices, and privacy for this browser.",{eyebrow:"Your account"})}
      <div class="settings-body">
        <div class="settings-hero">
          <div>
            <span class="settings-eyebrow">Your account</span>
            <h2>${v(p.displayName||p.userId)}</h2>
            <p class="settings-hero-copy">${p.username?`Shareable username <span class="mono">@${v(p.username)}</span> ${p.usernameLookupEnabled?"· exact lookup on":"· invite-only"} · Account ID <span class="mono">@${v(p.userId)}</span> on <span class="mono">${v(p.deviceId)}</span>`:`Account ID <span class="mono">@${v(p.userId)}</span> on <span class="mono">${v(p.deviceId)}</span>. Claim a shareable @username below.`}</p>
          </div>
          <button data-open-devices="1" class="summary-link-btn" type="button">Devices</button>
        </div>
        ${d}
        <div class="settings-section">
          <h3>Web access</h3>
          <p class="settings-section-intro">This browser follows the server’s published web policy. Treat the web client as a companion surface and keep your primary trust decisions on a protected device.</p>
          <div class="settings-callout settings-callout-subtle">
            <strong>${v(s.title)}</strong>
            <p>${v(s.detail)}</p>
          </div>
        </div>
        <div class="settings-section">
          <h3>Account</h3>
          <p class="settings-section-intro">Keep your everyday identity simple here: display name, shareable username, and this browser profile.</p>
          <div class="profile-edit-row">
            <label class="field">
              <span>Display Name</span>
              <input id="set-name" type="text" value="${v(p.displayName||p.userId)}" />
            </label>
            <label class="field">
              <span>Shareable Username</span>
              <input id="set-username" type="text" value="${v(p.username||"")}" placeholder="@yourname" autocomplete="off" />
            </label>
            <label class="switch-inline">
              <input id="set-username-lookup-enabled" type="checkbox" ${p.username&&p.usernameLookupEnabled?"checked":""} ${p.username?"":"disabled"} />
              <span>Allow exact @username lookup</span>
            </label>
            <button id="set-save-profile" class="btn-sm">Save</button>
          </div>
          <div class="settings-row"><span>User ID</span><span class="mono">${v(p.userId)}</span></div>
          <div class="settings-row"><span>Device</span><span class="mono">${v(p.deviceId)}</span></div>
        </div>
        <div class="settings-section">
          <h3>Session</h3>
          <p class="settings-section-intro">Sign out of this browser while keeping your encrypted local keys available for a later sign-in.</p>
          <button id="set-logout" class="btn-secondary">Log Out</button>
        </div>
        <div class="settings-section">
          <h3>People</h3>
          <p class="settings-section-intro">${r==="private_service"?"Add people by username or invite link first. Contact discovery stays secondary and experimental on web.":"Add people by exact @username or invite link. Manual contacts stay primary in this privacy profile."}</p>
          <div class="settings-section-actions">
            <button id="set-discovery-top" class="btn-secondary" ${n?"":"disabled"}>${n?"Open Contact Discovery":"Discovery Unavailable"}</button>
          </div>
          <div id="contacts-manage" class="settings-utility-list">
            ${ue.length===0?xe("No contacts yet","Add someone by exact @username or paste a private invite link to start building this browser’s trusted people list.",{eyebrow:"People",compact:!0,actionsHtml:Kr().directMessagingAllowed?'<button id="set-empty-new-chat" class="btn-secondary" type="button">Start new chat</button>':""}):`<div class="utility-list">${ue.map(_=>{var I;const y=Pe(_.contact_user_id),k=((I=_.alias)==null?void 0:I.trim())||"";return`
                  <div class="utility-list-item">
                    <div class="utility-list-body">
                      <div class="utility-list-title">
                        <span>${v(y.primaryLabel)}</span>
                        ${y.isVerified?'<span class="utility-status-pill success">Verified</span>':'<span class="utility-status-pill subtle">Manual</span>'}
                      </div>
                      <div class="utility-list-meta">
                        ${y.secondaryLabel?`<span class="mono">${v(y.secondaryLabel)}</span>`:""}
                        ${k&&k!==y.primaryLabel?`<span>Alias ${v(k)}</span>`:""}
                      </div>
                      <p class="utility-list-note">${v(y.isVerified?"This contact has a local trust checkpoint on this browser.":"This contact is saved locally, but not yet safety-number verified here.")}</p>
                    </div>
                    <div class="utility-list-actions">
                      <button class="btn-sm btn-danger-sm" data-remove-contact="${v(_.contact_user_id)}">Remove</button>
                    </div>
                  </div>
                `}).join("")}</div>`}
          </div>
          <div class="settings-inline-form">
            <label class="field">
              <span>@username or invite link</span>
              <input id="set-add-contact-id" type="text" placeholder="@username or invite link" class="input-sm" />
            </label>
            <label class="field">
              <span>Alias (optional)</span>
              <input id="set-add-contact-alias" type="text" placeholder="Alias (optional)" class="input-sm" />
            </label>
            <button id="set-add-contact" class="btn-sm">Add</button>
          </div>
        </div>
        <div class="settings-section">
          <h3>Privacy & Trust</h3>
          <p class="settings-section-intro">Review the active identity fingerprint, current server, and local trust state for this browser profile.</p>
          <div class="settings-row"><span>Encryption</span><span>Post-quantum (ML-KEM-768)</span></div>
          <div class="settings-row"><span>Mode</span><span>Mandatory WASM PQ runtime</span></div>
          <div class="settings-row column"><span>Identity Fingerprint</span><span class="mono fingerprint">${v(e)}</span></div>
          <div class="settings-row"><span>Server</span><span class="mono">${v(p.serverUrl)}</span></div>
          <div class="settings-row">
            <button id="set-rotate-key" class="btn-sm">Rotate Identity Key</button>
            <button id="set-identity-log" class="btn-sm">Identity Log</button>
          </div>
          <div id="rotate-status"></div>
        </div>
        <details class="settings-foldout">
          <summary>Privacy, devices, and advanced</summary>
          <div class="settings-foldout-body">
        <div class="settings-section">
          <h3>Key Health</h3>
          <div id="prekey-status"><p class="text-secondary">Loading…</p></div>
        </div>
        <div class="settings-section">
          <h3>Advanced Discovery</h3>
          <p class="text-secondary settings-desc">${n?"Use discovery only when you need the experimental hashed-handle path. Username and invite links stay easier and primary.":r==="private_service"?"Raw-hash discovery stays disabled. This screen only verifies the separate service contract before any future private lookup is allowed.":"Raw-hash discovery is disabled. Share your @username or a private invite link and manage contacts manually."}</p>
          ${r==="private_service"?`<div class="settings-row"><span>Manifest</span><span>${v(o)}</span></div>
          <div class="settings-row"><span>Manifest Continuity</span><span>${v(i)}</span></div>`:""}
          <div class="settings-row">
            <button id="set-discovery" class="btn-sm" ${n?"":"disabled"}>${n?"Contact Discovery":"Unavailable"}</button>
          </div>
          ${l}
        </div>
        <div class="settings-section">
          <h3>Advanced Push</h3>
          <div class="push-token-row">
            <input id="set-push-token" type="text" placeholder="FCM / APNs token" class="input-sm push-input" />
            <select id="set-push-provider" class="ephem-select">
              <option value="fcm">FCM</option>
              <option value="apns">APNs</option>
            </select>
            <button id="set-push-register" class="btn-sm">Register</button>
          </div>
          <div id="push-status"></div>
        </div>
        <div class="settings-section">
          <h3>Devices</h3>
          <p class="text-secondary settings-desc">Manage linked devices for your account.</p>
          <div class="settings-row">
            <button id="set-devices" class="btn-sm">Manage Devices</button>
          </div>
        </div>
        <div class="settings-section">
          <h3>Advanced Server</h3>
          <div class="settings-row">
            <button id="set-server-info" class="btn-sm">Server Info</button>
          </div>
        </div>
          </div>
        </details>
        <div class="settings-section">
          <h3>Danger Zone</h3>
          <button id="set-reset" class="btn-danger">Delete Account & Data</button>
        </div>
      </div>
    </section>
  `);const h=document.querySelector(".settings-hero-copy");h&&(h.innerHTML=p.username?`People can find you with <span class="mono">@${v(p.username)}</span>. This browser keeps its own local encrypted profile for <span class="mono">@${v(p.userId)}</span>.`:`This browser has a local encrypted profile for <span class="mono">@${v(p.userId)}</span>. Add a shareable @username when you want people to find you more easily.`);for(const _ of document.querySelectorAll(".settings-section")){const y=(f=(u=_.querySelector("h3"))==null?void 0:u.textContent)==null?void 0:f.trim(),k=_.querySelector(".settings-section-intro");y==="Web access"&&k&&(k.textContent="This server decides which web features are available right now.")}(m=g("#set-devices"))==null||m.replaceChildren("Devices"),(w=g("#set-server-info"))==null||w.replaceChildren("Server details"),g("#set-username").addEventListener("input",()=>{const _=g("#set-username"),y=g("#set-username-lookup-enabled"),k=_.value.trim().length>0;y.disabled=!k,k||(y.checked=!1)}),g("#set-save-profile").addEventListener("click",async()=>{var $,U;const _=g("#set-name"),y=g("#set-username"),k=g("#set-username-lookup-enabled"),I=_.value.trim(),L=y.value.trim(),B=!!L&&k.checked;if(!I){_.focus();return}try{const A=await J(),E=new j(p.serverUrl),G=Wa(A,I,L,B,"",""),N=await E.upsertProfile(A.userId,{display_name:I,username:L||void 0,username_lookup_enabled:B},G);p.displayName=(($=N.display_name)==null?void 0:$.trim())||I,p.username=((U=N.username)==null?void 0:U.trim())||"",p.usernameLookupEnabled=!!(N.username_lookup_enabled&&p.username),Mt(p),Je[A.userId]=p.displayName,on(A.userId,A.userId,p.displayName),Oe(),gr(),D("Profile updated","success")}catch(A){D(`Profile update failed: ${X(A)}`,"error")}}),(x=g("#set-empty-new-chat"))==null||x.addEventListener("click",()=>R({screen:"new-chat"})),g("#set-add-contact").addEventListener("click",async()=>{const _=g("#set-add-contact-id").value.trim(),y=g("#set-add-contact-alias").value.trim();if(!_){g("#set-add-contact-id").focus();return}try{const k=await J(),I=new j(p.serverUrl),L=qn(_),B=L?await Tr(L,I):await Fr(_,I);L||await si(_);const $=Hr(k,B,y,!1,"");await I.upsertContact(k.userId,{contact_user_id:B,alias:y||void 0},$),D("Contact added","success"),Es(),Ts(B),gr()}catch(k){D(`Add contact failed: ${Hc(_,k)}`,"error")}});for(const _ of document.querySelectorAll("[data-remove-contact]"))_.addEventListener("click",async()=>{const y=_.dataset.removeContact;try{const k=await J(),I=new j(p.serverUrl),L=sp(k,y);await I.removeContact(k.userId,{contact_user_id:y},L),D("Contact removed","success"),Es(),gr()}catch(k){D(`Remove failed: ${X(k)}`,"error")}});Vv(),g("#set-identity-log").addEventListener("click",()=>R({screen:"identity-log"}));for(const _ of document.querySelectorAll("#set-discovery, #set-discovery-top"))_.disabled||_.addEventListener("click",()=>R({screen:"discovery"}));g("#set-server-info").addEventListener("click",()=>R({screen:"server-info"}));for(const _ of document.querySelectorAll("[data-open-devices], #set-devices"))_.addEventListener("click",()=>R({screen:"devices"}));g("#set-logout").addEventListener("click",async()=>{await Fv()}),g("#set-push-register").addEventListener("click",async()=>{const _=g("#set-push-token").value.trim(),y=g("#set-push-provider").value,k=document.getElementById("push-status");if(!_){g("#set-push-token").focus();return}try{const I=await J(),L=new j(p.serverUrl),B=pp(I,_),$=await L.registerPushToken(I.userId,{device_id:I.deviceId,provider:y,token:_},B);k.innerHTML=`<span class="text-success">✓ Registered ${v($.provider)} push token</span>`}catch(I){k.innerHTML=`<span class="text-danger">Failed: ${v(X(I))}</span>`}}),g("#set-rotate-key").addEventListener("click",async()=>{const _=document.getElementById("rotate-status");_.textContent="Generating new identity keys…";try{const y=await J(),k=new j(p.serverUrl),I=Do(y.userId,y.deviceId,y.suite,4),L=op(y,I.identityX25519Pub,I.identitySigPub,I.identityPqSigPub);_.textContent="Requesting rotation challenge…";const B=await k.rotateInit(y.userId,{new_identity_x25519_pub:I.identityX25519Pub,new_identity_sig_pub:I.identitySigPub,new_identity_pq_sig_pub:I.identityPqSigPub,new_device_id:y.deviceId},L),$=dp(y,I,B.challenge_id,B.challenge_nonce);_.textContent="Confirming rotation…";const U=cp(y,$.challenge_id,$.sig_by_current_identity,$.sig_by_new_identity,$.pq_sig_by_current_identity,$.pq_sig_by_new_identity),A=await k.rotateConfirm(y.userId,$,U),E={...y,...I},G=dn();await Gr(y.userId,G,E),await nc(y.userId),He=E,_.innerHTML=`<span class="text-success">✓ Rotated to v${A.identity_key_version}</span>`,D("Identity key rotated successfully","success")}catch(y){_.innerHTML=`<span class="text-danger">Rotation failed: ${v(X(y))}</span>`}}),g("#set-reset").addEventListener("click",async()=>{if(confirm("Delete all local data and retire your device from the server?")){try{if(Kn(p.userId)){const _=await J();await new j(p.serverUrl).retireCurrentDevice(p.userId,Vu(_))}}catch{}await za(p.userId),await Hp(p.userId),await Rp(),He=null,Ct&&(Ct.disconnect(),Ct=null),ad(),ue=[],Xn={},p={...Ke,serverUrl:p.serverUrl,suiteLabel:p.suiteLabel,displayName:""},Mt(p),R({screen:"onboarding"}),D("Account deleted","info")}})}async function Pa(){it(`
    <section class="workspace-page-card">
      ${ot("Devices","Review this browser, linked sessions, and device access.",{eyebrow:"Linked devices",backButtonId:"dev-back",backButtonLabel:"Back to settings",actionsHtml:'<button id="dev-link" class="btn-primary" type="button">Link device</button>'})}
      <div class="settings-body">
        <div class="settings-overview-list" id="device-summary">
          <article class="settings-overview-row">
            <div class="settings-overview-copy">
              <span class="settings-summary-kicker">Current device</span>
              <strong>This browser</strong>
              <p>Your local encrypted keys stay on this browser profile.</p>
            </div>
            <span class="settings-overview-meta mono">${v(p.deviceId)}</span>
          </article>
          <article class="settings-overview-row">
            <div class="settings-overview-copy">
              <span class="settings-summary-kicker">Linked sessions</span>
              <strong>Loading linked sessions</strong>
              <p>Review every browser or device currently linked to this account.</p>
            </div>
            <span class="settings-overview-meta">checking account devices</span>
          </article>
        </div>
        <div class="settings-section">
          <h3>Linked sessions</h3>
          <p class="text-secondary settings-desc">Keep only the devices you recognize. Remove old browsers or test devices as soon as you are done with them.</p>
          <div id="device-list" class="utility-list">
            ${xe("Loading devices","Checking linked sessions for this account.",{eyebrow:"Devices",compact:!0})}
          </div>
        </div>
      </div>
    </section>
  `),g("#dev-back").addEventListener("click",()=>R({screen:"settings"})),g("#dev-link").addEventListener("click",()=>R({screen:"link-device"}));try{const e=await J(),t=new j(p.serverUrl),s=Wu(e),n=await t.listDevices(e.userId,s),r=n.devices.filter(o=>o.active).length,a=n.devices.filter(o=>!o.active).length;g("#device-summary").innerHTML=`
      <article class="settings-overview-row">
        <div class="settings-overview-copy">
          <span class="settings-summary-kicker">Current device</span>
          <strong>This browser</strong>
          <p>Your local encrypted keys stay on this browser profile.</p>
        </div>
        <span class="settings-overview-meta mono">${v(p.deviceId)}</span>
      </article>
      <article class="settings-overview-row">
        <div class="settings-overview-copy">
          <span class="settings-summary-kicker">Linked sessions</span>
          <strong>${n.devices.length} ${n.devices.length===1?"device":"devices"}</strong>
        <span>${r} active${a?` · ${a} revoked`:""}</span>
        <p>${v(r===1?"Only this browser is active right now.":"Review older browsers and remove anything you do not recognize.")}</p>
        </div>
        <span class="settings-overview-meta">${r} active${a?` · ${a} revoked`:""}</span>
      </article>
    `;const i=g("#device-list");if(n.devices.length===0){i.innerHTML=xe("No linked devices yet","This browser is your only active session right now.",{eyebrow:"Devices",compact:!0,actionsHtml:'<button id="dev-empty-link" class="btn-secondary" type="button">Link another device</button>'}),g("#dev-empty-link").addEventListener("click",()=>R({screen:"link-device"}));return}i.innerHTML=n.devices.map(o=>{const c=o.device_id===p.deviceId,d=o.active?c?"This device":"Active":"Revoked",l=o.active?c?"success":"neutral":"danger",h=new Date(o.linked_at).toLocaleDateString(),u=o.active&&!c?`<button class="btn-sm btn-danger-sm" data-revoke-device="${v(o.device_id)}">Revoke</button>`:"";return`
        <div class="device-row utility-list-item">
          <div class="device-info utility-list-body">
            <div class="utility-list-title">
              <span class="mono">${v(o.device_id)}</span>
              <span class="utility-status-pill ${l}">${d}</span>
            </div>
            <div class="utility-list-meta">
              <span>Linked ${h}</span>
              ${o.revoked_at?`<span>Revoked ${new Date(o.revoked_at).toLocaleDateString()}</span>`:""}
            </div>
            <p class="utility-list-note">${v(c?"This browser holds your current local profile.":o.active?"This linked device can still receive updates until it is revoked.":"This device has already been removed from active access.")}</p>
          </div>
          <div class="utility-list-actions">
            ${u}
          </div>
        </div>
      `}).join(""),i.querySelectorAll("[data-revoke-device]").forEach(o=>{o.addEventListener("click",async c=>{const d=c.currentTarget.dataset.revokeDevice;if(confirm(`Revoke device "${d}"? This cannot be undone.`))try{const l=await J(),h=Fu(l,d);await t.revokeDevice(l.userId,d,h),D(`Device ${d} revoked`,"success"),Pa()}catch(l){D(`Revoke failed: ${X(l)}`,"error")}})})}catch(e){g("#device-list").innerHTML=xe("Could not load devices",`We could not fetch your linked sessions: ${X(e)}`,{eyebrow:"Devices",compact:!0,actionsHtml:'<button id="dev-retry" class="btn-secondary" type="button">Try again</button>'}),g("#dev-retry").addEventListener("click",()=>void Pa())}}function Sv(){it(`
    <section class="workspace-page-card">
      ${ot("Link device","Create another device entry for this account while keeping your current browser signed in.",{eyebrow:"Linked devices",backButtonId:"ld-back",backButtonLabel:"Back to devices"})}
      <div class="settings-body">
        <div class="settings-callout settings-callout-subtle">
          <strong>Add another session for the same account.</strong>
          <p>Use clear device names like <span class="mono">work-laptop</span> so old browsers are easy to review and revoke later.</p>
        </div>
        <div class="settings-overview-list">
          <article class="settings-overview-row">
            <div class="settings-overview-copy">
              <span class="settings-summary-kicker">Best use</span>
              <strong>Secondary browser or test device</strong>
              <p>The new session gets its own device ID while staying part of the same account.</p>
            </div>
            <span class="settings-overview-meta">same account, separate session</span>
          </article>
        </div>
        <div class="settings-section">
          <h3>New device</h3>
          <p class="text-secondary settings-desc">Enter a short device label. This browser will ask the server to provision a new linked session for the same account.</p>
          <label class="field">
            <span>New Device ID</span>
            <input id="ld-device-id" type="text" placeholder="e.g. work-laptop" />
          </label>
          <div class="settings-section-actions">
            <button id="ld-submit" class="btn-primary" type="button">Link Device</button>
          </div>
          <div id="ld-status"></div>
        </div>
      </div>
    </section>
  `),g("#ld-back").addEventListener("click",()=>R({screen:"devices"})),g("#ld-submit").addEventListener("click",async()=>{const e=g("#ld-device-id").value.trim();if(!e){g("#ld-device-id").focus();return}const t=g("#ld-status");t.innerHTML='<p class="text-secondary">Linking device...</p>';try{const s=await J(),n=new j(p.serverUrl),r=Ku(s,e),a=await n.linkDevice(s.userId,e,r);t.innerHTML=`<p class="text-success">Device "${v(a.linked_device_id)}" linked at ${new Date(a.linked_at).toLocaleString()}</p>`,D(`Device ${a.linked_device_id} linked`,"success")}catch(s){t.innerHTML=`<p class="text-danger">Link failed: ${v(X(s))}</p>`}})}async function Iv(e,t){const s=Pe(e).primaryLabel,n=t==="video"?"Video":"Audio";Ge.innerHTML=`
    <div class="call-shell">
      <div class="call-overlay">
        <div class="call-avatar">
          <div class="avatar avatar-lg">${s.slice(0,2).toUpperCase()}</div>
        </div>
        <h2 class="call-name">${v(s)}</h2>
        <div class="beta-banner beta-banner-warning">
          <strong>${n} calling is unavailable on web</strong>
          <p>Use the supported messaging path instead. Web calling stays disabled in this beta.</p>
        </div>
        <div class="call-controls">
          <button id="call-back-chat" class="btn-secondary">Back to chat</button>
        </div>
      </div>
    </div>
  `,g("#call-back-chat").addEventListener("click",()=>{R({screen:"chat",peerId:e})})}async function Ev(e,t,s,n){const r=Pe(t).primaryLabel,a=s==="video"?"video":"audio";Ge.innerHTML=`
    <div class="call-shell">
      <div class="call-overlay">
        <div class="call-avatar">
          <div class="avatar avatar-lg">${r.slice(0,2).toUpperCase()}</div>
        </div>
        <h2 class="call-name">${v(r)}</h2>
        <div class="beta-banner beta-banner-warning">
          <strong>Incoming ${a} calls are disabled on web</strong>
          <p>Calling is out of scope for this beta. Return to conversations and continue on the messaging path.</p>
        </div>
        <div class="call-controls">
          <button id="call-back-conversations" class="btn-secondary">Back to conversations</button>
        </div>
      </div>
    </div>
  `,g("#call-back-conversations").addEventListener("click",()=>{R({screen:"conversations"})})}async function Cv(){if(!Ct)try{const e=await Xe(),t=await J();if((e==null?void 0:e.sealed_sender_required)!==!0)return;Ct=new vh(p.serverUrl,t),Ct.onMessage(Av),Ct.connect()}catch{}}async function Av(e){var t;try{const s=await J(),n=await Tc(s,e.message_bytes_base64,e.sender_user_id,e.sender_identity_x25519_pub);if(n.kind==="ignored"){const u=xn(s.userId,s.deviceId);e.message_id>u&&Sn(s.userId,e.message_id,s.deviceId);return}const r=n.plaintext,a=n.senderUserId,i=n.kind==="dm",o=i?null:n.recipient,c=i?Mn(s.userId,a):`group:${o}`;if((await ze(c)).some(u=>u.serverMessageId===e.message_id)){const u=xn(s.userId,s.deviceId);e.message_id>u&&Sn(s.userId,e.message_id,s.deviceId);return}const l={id:`srv-${e.message_id}`,conversationId:c,sender:a,recipient:i?s.userId:n.recipient,text:i?r:`${Pe(a).primaryLabel}: ${r}`,timestamp:new Date(e.received_at).getTime()||Date.now(),status:"delivered",serverMessageId:e.message_id};await Ys(l),i&&Ov(e.message_id);const h=xn(s.userId,s.deviceId);if(e.message_id>h&&Sn(s.userId,e.message_id,s.deviceId),i){const u=cn===a;if(Rc(a,r,!u),u){jt(s.userId,a);const f=document.getElementById("messages-list"),m=document.getElementById("messages-container");f&&m&&rn(f,l,m)}else D(`${Pe(a).primaryLabel}: ${r.slice(0,50)}`,"info")}else if(o){const u=e.sender_user_id??a,f=ws===o;if(ti(o,u,r,!f),Ts(u),f){Yn(s.userId,o);const m=document.getElementById("messages-list"),w=document.getElementById("messages-container");m&&w&&rn(m,l,w)}else{const m=((t=As(s.userId).find(x=>x.groupId===o))==null?void 0:t.ownerUserId)||u,w=Qa(o,m).primaryLabel;D(`${w} · ${Pe(u).primaryLabel}: ${r.slice(0,50)}`,"info")}}Oe()}catch(s){console.warn("realtime message handling failed",s)}}async function $v(){try{const e=await Xe();if((e==null?void 0:e.sealed_sender_required)!==!0)return;await Ma()}catch{}}const Tv=["👍","❤️","😂","😮","😢","🔥"];let De=null,Qe=null;const Gn=new Map;let F=null;function Mr(e,t,s,n,r,a,i,o,c,d){var x;(x=document.querySelector(".ctx-menu"))==null||x.remove();const l=document.createElement("div");l.className="ctx-menu",l.style.top=`${e.clientY}px`,l.style.left=`${e.clientX}px`;const h=(d==null?void 0:d.allowEdit)??!1,u=(d==null?void 0:d.allowServerDelete)??!1,f=r.dataset.hasAttachment==="1";let m=`<div class="ctx-item" data-action="reply">↩️ Reply</div>
    <div class="ctx-item" data-action="react">😀 React</div>`;f&&(m+='<div class="ctx-item" data-action="open">📎 Open attachment</div>'),m+=`<div class="ctx-item" data-action="copy">Copy</div>
    <div class="ctx-item" data-action="share">Share</div>
    <div class="ctx-item ctx-danger" data-action="delete-local">Delete from this device</div>`,s&&h&&(m+='<div class="ctx-item" data-action="edit">✏️ Edit</div>'),s&&u&&n&&(m+='<div class="ctx-item ctx-danger" data-action="delete">🗑️ Delete</div>'),m+='<div class="ctx-item" data-action="select">Select messages</div>',l.innerHTML=m,document.body.appendChild(l);const w=()=>l.remove();setTimeout(()=>document.addEventListener("click",w,{once:!0}),0),l.addEventListener("click",async _=>{var k,I,L,B;const y=_.target.dataset.action;if(l.remove(),!!y){if(y==="reply"){const $=await ys(t),U=($?ht($):((k=r.querySelector(".bubble-text"))==null?void 0:k.textContent)||"").replace(/\s+/g," ").trim();De={msgId:t,preview:U.slice(0,60)},ai(a),a.focus()}if(y==="react"&&ii(e.clientX,e.clientY,t,r),y==="open"){const $=await ys(t);$&&at($)&&ri($)}if(y==="copy"){const $=await ys(t),U=($?ht($):((I=r.querySelector(".bubble-text"))==null?void 0:I.textContent)||"").trim();U&&(await navigator.clipboard.writeText(U),D("Message copied","success"))}if(y==="share"){const $=await ys(t),U=($?ht($):((L=r.querySelector(".bubble-text"))==null?void 0:L.textContent)||"").trim();if(!U)return;if(navigator.share)try{await navigator.share({text:U})}catch{await navigator.clipboard.writeText(U)}else await navigator.clipboard.writeText(U);D("Message ready to share","success")}if(y==="delete-local"&&await((B=d==null?void 0:d.onLocalDelete)==null?void 0:B.call(d,t)),y==="edit"){const $=await ys(t);if(!$)return;const U=at($)?($.attachmentNoteText??$.text).trim():$.text.trim();Qe={msgId:t,originalText:U,allowEmptyText:at($)},a.value=U,wt(a),i.disabled=!1,i.textContent="Save",a.focus()}if(y==="delete"&&n&&wv(r,n),y==="select"){const $=r.dataset.conversationId||"";if(!$)return;Jc($,t),c==null||c()}}})}function ai(e){var s;if((s=document.querySelector(".reply-compose-bar"))==null||s.remove(),!De)return;const t=document.createElement("div");t.className="reply-compose-bar",t.innerHTML=`<span class="reply-bar-text">↩️ ${v(De.preview)}</span>
    <button class="reply-bar-close icon-btn" aria-label="Cancel reply">✕</button>`,t.querySelector(".reply-bar-close").addEventListener("click",()=>{De=null,t.remove()}),e.parentElement.insertBefore(t,e.parentElement.firstChild)}function wt(e){e instanceof HTMLTextAreaElement&&(e.style.height="0px",e.style.height=`${Math.min(e.scrollHeight,144)}px`)}function ii(e,t,s,n,r){var i;(i=document.querySelector(".reaction-picker"))==null||i.remove();const a=document.createElement("div");a.className="reaction-picker",a.style.top=`${t}px`,a.style.left=`${e}px`,a.innerHTML=Tv.map(o=>`<span class="reaction-option" data-emoji="${o}">${o}</span>`).join(""),document.body.appendChild(a),setTimeout(()=>document.addEventListener("click",()=>a.remove(),{once:!0}),0),a.addEventListener("click",async o=>{const c=o.target.dataset.emoji;if(!c)return;a.remove();const d=await ji(s,c,p.userId);if(d){let l=n.querySelector(".reaction-pills");l&&l.remove();const h=Ta(d);h&&n.insertAdjacentHTML("beforeend",h),n.querySelectorAll(".reaction-pill").forEach(u=>{u.addEventListener("click",async()=>{var w;const f=u.dataset.emoji,m=await ji(s,f,p.userId);if(m){(w=n.querySelector(".reaction-pills"))==null||w.remove();const x=Ta(m);x&&n.insertAdjacentHTML("beforeend",x)}})})}})}async function nd(e,t){try{const s=await J(),n=new j(p.serverUrl),r=Ho(s,e),a=await n.downloadFile(e,r),i=Uint8Array.from(atob(a.file_bytes_base64),l=>l.charCodeAt(0)),o=new Blob([i],{type:a.mime_type}),c=URL.createObjectURL(o);Fs.set(e,c);const d=t.querySelector(`[data-file-id="${e}"]`);if(d){if(a.mime_type.startsWith("image/")){const l=document.createElement("img");l.src=c,l.className="media-img",l.loading="lazy",l.addEventListener("click",()=>oi(c)),d.replaceWith(l)}else if(a.mime_type.startsWith("audio/")){const l=document.createElement("audio");l.controls=!0,l.src=c,l.className="media-audio",d.replaceWith(l)}else if(a.mime_type.startsWith("video/")){const l=document.createElement("video");l.controls=!0,l.src=c,l.className="media-video",d.replaceWith(l)}}}catch{}}function oi(e){const t=document.createElement("div");t.className="media-lightbox",t.innerHTML=`<img src="${e}" class="lightbox-img" />`,t.addEventListener("click",()=>t.remove()),document.addEventListener("keydown",function s(n){n.key==="Escape"&&(t.remove(),document.removeEventListener("keydown",s))}),document.body.appendChild(t)}async function Lv(e){try{const t=await J(),s=new j(p.serverUrl),n=Ho(t,e),r=await s.downloadFile(e,n),a=Uint8Array.from(atob(r.file_bytes_base64),d=>d.charCodeAt(0)),i=new Blob([a],{type:r.mime_type}),o=URL.createObjectURL(i),c=document.createElement("a");c.href=o,c.download=e,c.click(),setTimeout(()=>URL.revokeObjectURL(o),6e4)}catch(t){D(`Download failed: ${X(t)}`,"error")}}function _n(){const e=Cr;Gs==null||Gs.remove(),Gs=null,Cr=null,In&&(document.removeEventListener("keydown",In),In=null),Ln(e)}function yn(e){if(!at(e))return null;const t=Ls(e);return t.startsWith("image/")||t.startsWith("video/")?"media":t.startsWith("audio/")?"audio":"files"}function to(e){switch(e){case"media":return"Media";case"files":return"Files";case"audio":return"Audio";default:return"All"}}function Pv(e){if(!at(e))return'<div class="shared-media-empty">No preview available</div>';const t=e.fileId,s=Ls(e),n=er(e),r=Vc(e);if(s.startsWith("image/")&&r)return`<img src="${r}" alt="${v(n)}" class="media-img" loading="lazy" />`;if(s.startsWith("audio/")&&r)return`<audio controls src="${r}" class="media-audio"></audio>`;if(s.startsWith("video/")&&r)return`<video controls src="${r}" class="media-video"></video>`;if(t&&(s.startsWith("image/")||s.startsWith("audio/")||s.startsWith("video/")))return`<div class="shared-media-loading" data-file-id="${v(t)}">Loading preview…</div>`;const a=fs(s);return`
    <div class="shared-media-file-tile">
      <span class="shared-media-file-glyph">${v(a.slice(0,1))}</span>
      <span class="shared-media-file-name">${v(n)}</span>
    </div>
  `}function Mv(e){const t=[fs(Ls(e))];return e.conversationId.startsWith("group:")&&t.push(e.sender===p.userId?"You":Pe(e.sender).primaryLabel),t.push(new Date(e.timestamp).toLocaleString([],{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})),t.join(" · ")}async function ci(e){var d;const t=(await ze(e.conversationId)).filter(l=>at(l)).sort((l,h)=>h.timestamp-l.timestamp);if(t.length===0){D(e.emptyMessage,"info");return}_n();let s="all";const n={all:t.length,media:t.filter(l=>yn(l)==="media").length,files:t.filter(l=>yn(l)==="files").length,audio:t.filter(l=>yn(l)==="audio").length},r=document.createElement("div");r.className="shared-media-sheet",r.setAttribute("role","dialog"),r.setAttribute("aria-modal","true"),r.setAttribute("aria-labelledby","shared-media-title"),r.innerHTML=`
    <div class="shared-media-card">
      <div class="shared-media-head">
        <div>
          <h3 id="shared-media-title">${v(e.title)}</h3>
          <p>Browse the attachments saved in this conversation on this device.</p>
        </div>
        <button id="shared-media-close" class="icon-btn" aria-label="Close shared media">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
      <div class="shared-media-tabs">
        ${["all","media","files","audio"].map(l=>`
            <button type="button" class="shared-media-tab" data-shared-media-filter="${l}">
              ${to(l)} <span>${n[l]}</span>
            </button>
          `).join("")}
      </div>
      <div id="shared-media-grid" class="shared-media-grid"></div>
    </div>
  `;const a=iv();a?(r.classList.add("desktop-side-panel"),a.appendChild(r),Cr=a,Ln(a)):(document.body.appendChild(r),Cr=null),Gs=r;const i=r.querySelector("#shared-media-grid"),o=Array.from(r.querySelectorAll("[data-shared-media-filter]")),c=()=>{o.forEach(h=>{h.classList.toggle("active",h.dataset.sharedMediaFilter===s)});const l=t.filter(h=>s==="all"||yn(h)===s);if(l.length===0){i.innerHTML=`<div class="shared-media-empty">No ${to(s).toLowerCase()} in this conversation yet.</div>`;return}i.innerHTML=l.map(h=>`
        <article class="shared-media-item">
          <div class="shared-media-preview">
            ${Pv(h)}
          </div>
          <div class="shared-media-copy">
            <div class="shared-media-item-title">${v(er(h))}</div>
            <div class="shared-media-item-meta">${v(Mv(h))}</div>
            ${$a(h).trim()?`<div class="shared-media-item-note">${v($a(h).trim())}</div>`:""}
          </div>
          <div class="shared-media-actions">
            <button type="button" class="btn-secondary shared-media-open" data-message-id="${v(h.id)}">Open</button>
          </div>
        </article>
      `).join(""),i.querySelectorAll(".shared-media-open").forEach(h=>{h.addEventListener("click",()=>{const u=h.dataset.messageId,f=l.find(m=>m.id===u);f&&ri(f)})}),i.querySelectorAll(".shared-media-preview .media-img").forEach(h=>{h.addEventListener("click",()=>oi(h.src))}),l.forEach(h=>{var f;if(!h.fileId)return;const u=(f=i.querySelector(`.shared-media-item .shared-media-preview [data-file-id="${CSS.escape(h.fileId)}"]`))==null?void 0:f.closest(".shared-media-preview");u&&!Fs.has(h.fileId)&&yn(h)!=="files"&&nd(h.fileId,u)})};o.forEach(l=>{l.addEventListener("click",()=>{s=l.dataset.sharedMediaFilter||"all",c()})}),(d=r.querySelector("#shared-media-close"))==null||d.addEventListener("click",_n),r.addEventListener("click",l=>{l.target===r&&_n()}),In=l=>{l.key==="Escape"&&Gs&&(l.preventDefault(),_n())},document.addEventListener("keydown",In),c()}let va=null;function Bv(){const e=Kr(),t=()=>xe("Search your messages","Type a name, message phrase, or attachment filename to search this browser profile.",{eyebrow:"Search",compact:!0,actionsHtml:e.directMessagingAllowed?`
              <button id="search-empty-new-chat" class="btn-primary" type="button">Start new chat</button>
              <button id="search-empty-settings" class="btn-secondary" type="button">Open settings</button>
            `:`
              <button id="search-empty-settings" class="btn-secondary" type="button">Open settings</button>
            `}),s=d=>xe(`No results for "${d}"`,"Try a different name, a broader phrase, or part of an attachment filename.",{eyebrow:"Search",compact:!0,actionsHtml:e.directMessagingAllowed?`
              <button id="search-clear" class="btn-secondary" type="button">Clear search</button>
              <button id="search-no-results-new-chat" class="btn-primary" type="button">Start new chat</button>
            `:`
              <button id="search-clear" class="btn-secondary" type="button">Clear search</button>
            `});it(`
    <section class="workspace-page-card">
      ${ot("Search","Find messages, names, and attachment details stored on this browser profile.",{eyebrow:"Search",backButtonId:"search-back",backButtonLabel:"Back to inbox",actionsHtml:`
            <label class="workspace-search-field" aria-label="Search messages">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="M21 21l-4.35-4.35"></path>
              </svg>
              <input id="search-input" type="text" class="search-input" placeholder="Search messages..." autocomplete="off" aria-label="Search messages" />
            </label>
          `})}
      <div class="search-results utility-search-results" id="search-results" role="list">
        ${t()}
      </div>
    </section>
  `);const n=g("#search-input"),r=g("#search-results"),a=new Map(As(p.userId).map(d=>[d.groupId,d.ownerUserId])),i=()=>{var d,l,h,u;(d=r.querySelector("#search-empty-new-chat"))==null||d.addEventListener("click",()=>{R({screen:"new-chat"})}),(l=r.querySelector("#search-empty-settings"))==null||l.addEventListener("click",()=>{R({screen:"settings"})}),(h=r.querySelector("#search-clear"))==null||h.addEventListener("click",()=>{n.value="",r.innerHTML=t(),i(),n.focus()}),(u=r.querySelector("#search-no-results-new-chat"))==null||u.addEventListener("click",()=>{R({screen:"new-chat"})})},o=()=>{for(const d of r.querySelectorAll(".search-result-item")){const l=()=>{const h=d.dataset.searchThreadId;if((d.dataset.searchThreadKind==="group"?"group":"dm")==="group"){R({screen:"group-chat",groupId:h});return}R({screen:"chat",peerId:h})};d.addEventListener("click",l),d.addEventListener("keydown",h=>{(h.key==="Enter"||h.key===" ")&&(h.preventDefault(),l())})}},c=d=>{const l=d.conversationId.startsWith("group:"),h=l?d.conversationId.replace("group:",""):d.sender===p.userId?d.recipient:d.sender,u=new Date(d.timestamp).toLocaleDateString([],{month:"short",day:"numeric"}),f=ht(d).replace(/\s+/g," ").trim(),m=f.length>96?`${f.slice(0,96)}...`:f;if(l){const x=Wr(h),_=x?Qn(x):a.get(h)||p.userId,y=Qa(h,_);return`
        <div class="search-result-item" tabindex="0" role="listitem" data-search-thread-id="${v(h)}" data-search-thread-kind="group">
          <div class="avatar avatar-sm">${v(y.avatarText)}</div>
          <div class="search-result-body">
            <div class="search-result-header">
              <span class="search-result-name">
                ${v(y.primaryLabel)}
                <span class="utility-status-pill subtle">Group</span>
              </span>
              <span class="search-result-time">${v(u)}</span>
            </div>
            <div class="search-result-meta">${v(y.secondaryLabel||"Private group")}</div>
            <div class="search-result-preview">${v(m||"Open the thread to review this message.")}</div>
          </div>
        </div>
      `}const w=Pe(h);return`
      <div class="search-result-item" tabindex="0" role="listitem" data-search-thread-id="${v(h)}" data-search-thread-kind="dm">
        <div class="avatar avatar-sm">${v(w.avatarText)}</div>
        <div class="search-result-body">
          <div class="search-result-header">
            <span class="search-result-name">
              ${v(w.primaryLabel)}
              <span class="utility-status-pill subtle">Direct</span>
            </span>
            <span class="search-result-time">${v(u)}</span>
          </div>
          <div class="search-result-meta">${v(w.secondaryLabel||(w.isVerified?"Verified contact":"Direct conversation"))}</div>
          <div class="search-result-preview">${v(m||"Open the thread to review this message.")}</div>
        </div>
      </div>
    `};g("#search-back").addEventListener("click",()=>R({screen:"conversations"})),i(),n.addEventListener("input",()=>{va&&clearTimeout(va);const d=n.value.trim();if(!d){r.innerHTML=t(),i();return}va=setTimeout(async()=>{const l=await Np(d);if(l.length===0){r.innerHTML=s(d),i();return}r.innerHTML=l.slice(0,50).map(h=>c(h)).join(""),o()},300)}),n.focus()}function rd(e){let t=document.getElementById("offline-banner");e?t||(t=document.createElement("div"),t.id="offline-banner",t.className="offline-banner",t.setAttribute("role","status"),t.textContent="No internet connection",document.body.appendChild(t)):t==null||t.remove()}async function Uv(){try{const e=await J();if(!await us("direct")){const n=await Gi(e.userId);for(const r of n)await pa(r.id),await kn(r.id,"failed"),Vs(r.id,"failed");return}const t=new j(p.serverUrl),s=await Gi(e.userId);for(const n of s)try{if(n.groupId){await pa(n.id),await kn(n.id,"failed"),Vs(n.id,"failed");continue}else{const r=await $c(e,n.peerId,n.text),a=await Pc(e,n.peerId,t);await t.sealedRelay(n.peerId,{delivery_token:a,message_bytes_base64:r})}await pa(n.id),await kn(n.id,"sent"),Vs(n.id,"sent")}catch{}}catch{}}function qv(e){let t=document.getElementById("toast");t||(t=document.createElement("div"),t.id="toast",t.setAttribute("role","alert"),t.setAttribute("aria-live","assertive"),document.body.appendChild(t)),vr=e.action??null,t.innerHTML="";const s=document.createElement("span");if(s.className="toast-text",s.textContent=e.text,t.appendChild(s),e.actionLabel&&e.action){const n=document.createElement("button");n.type="button",n.className="toast-action",n.textContent=e.actionLabel,n.addEventListener("click",()=>{const r=vr;vr=null,t.classList.remove("toast-show"),Hs&&(clearTimeout(Hs),Hs=null),r==null||r()}),t.appendChild(n)}t.className=`toast toast-${e.type} toast-show`,Hs&&clearTimeout(Hs),Hs=setTimeout(()=>{vr=null,t.classList.remove("toast-show")},3500)}function Dv(){ls()&&(En||(so("online"),En=setInterval(()=>{so("online")},12e4)))}async function so(e){if(ls())try{const t=await J(),s=new j(p.serverUrl),n=Yu(t,e);await s.updatePresence(t.userId,{status:e},n)}catch{}}async function Rv(e){if(ls())try{const t=await J(),s=new j(p.serverUrl),n=zu(t),r=await s.getPresence(e,n);Xn[e]={status:r.status,updated:Date.now()};const a=document.getElementById("chat-status");a&&cn===e&&(a.textContent=r.status==="online"?"online":r.status==="away"?"away":"encrypted",a.className=`chat-header-status ${r.status==="offline"?"":`presence-${r.status}`}`)}catch{}}function no(e,t){Nn()&&(Ws&&clearTimeout(Ws),Ws=setTimeout(()=>{ro(e,!1)},1e4),ro(e,t))}async function ro(e,t){if(Nn())try{const s=await J(),n=new j(p.serverUrl),r=Xu(s,e,t);await n.updateTyping(e,{is_typing:t},r)}catch{}}function Nv(e){if(!Nn())return;di();const t=async()=>{try{const s=await J(),n=new j(p.serverUrl),r=Ju(s),a=await n.getTyping(s.userId,r),i=document.getElementById("typing-indicator");if(!i)return;const o=a.typing.some(c=>c.user_id===e&&c.is_typing);i.classList.toggle("hidden",!o)}catch{}};t(),mr=setInterval(t,3e3)}function Hv(){if(!Ja()||Cn)return;const e=async()=>{try{const t=await J(),s=new j(p.serverUrl),n=Qu(t,bn),r=await s.getReceipts(t.userId,bn,n);for(const a of r.receipts){bn=Math.max(bn,a.receipt_id);const i=(a.receipt_type==="read","delivered"),o=document.querySelector(`[data-server-mid="${a.message_id}"]`);if(o){const c=a.receipt_type==="read"?"read":"delivered";Vs(o.id.replace("msg-",""),c)}}}catch{}};e(),Cn=setInterval(e,5e3)}async function Ov(e){if(Ja())try{const t=await J(),s=new j(p.serverUrl),n=Zu(t,e,"delivered");await s.sendReceipt(t.userId,{message_id:e,receipt_type:"delivered"},n)}catch{}}async function Es(){try{const e=await J(),t=new j(p.serverUrl),s=ep(e),n=await t.listContacts(e.userId,s),r=JSON.stringify(ue)!==JSON.stringify(n.contacts);ue=n.contacts,Qh(),r&&Oe()}catch{}}async function Gv(){it(`
    <section class="workspace-page-card">
      ${ot("Identity log","Review local identity history, key rotations, and the latest transparency verification state for this account.",{eyebrow:"Trust history",backButtonId:"idlog-back",backButtonLabel:"Back to settings"})}
      <div class="settings-body" id="idlog-body">
        ${xe("Loading identity history","Checking saved key events and any available transparency proof.",{eyebrow:"Identity log",compact:!0})}
      </div>
    </section>
  `),g("#idlog-back").addEventListener("click",()=>R({screen:"settings"}));try{const e=await J(),t=new j(p.serverUrl),s=lp(e),n=await t.getIdentityLog(e.userId,s),r=await Xe(),a=document.getElementById("idlog-body");let i="";if(r!=null&&r.key_transparency_supported&&r.transparency_log_issuer_ed25519_pub)try{const o=jr(p.serverUrl,e.userId),c=await Lc(t,e.userId,o),d=Fo(JSON.stringify(c),r.transparency_log_issuer_ed25519_pub,o?JSON.stringify(o):null);oc(p.serverUrl,e.userId,c.signed_tree_head);const l=n.events[0]?Cs(c.leaf.identity_x25519_pub,c.leaf.identity_pq_sig_pub??void 0).toLowerCase()===n.events[0].identity_fingerprint_sha256.toLowerCase():!0,h=n.events[0]?n.events[0].version===d.leafVersion:!0,u=o?d.consistencyVerified?"Append-only growth verified against the last saved checkpoint.":"Proof verified, but append-only growth was not checked.":"First verified transparency checkpoint saved on this device.";i=`
          <div class="settings-section">
            <h3>Transparency</h3>
            <p class="text-secondary settings-desc">
              <strong>Verified.</strong> Current identity version v${d.leafVersion} is included in signed tree #${d.treeSize}.
            </p>
            <p class="text-secondary settings-desc">${v(u)}</p>
            <p class="text-secondary settings-desc">${l&&h?"Identity log matches the signed transparency leaf.":"Warning: identity log and transparency leaf do not match exactly on this device."}</p>
          </div>
        `}catch(o){i=`
          <div class="settings-section">
            <h3>Transparency</h3>
            <p class="text-danger">Verification failed: ${v(X(o))}</p>
          </div>
        `}if(n.events.length===0){a.innerHTML=`${i}${xe("No identity events recorded","Rotate or reprovision this account later to see its local identity history here.",{eyebrow:"Identity log",compact:!0})}`;return}a.innerHTML=`
      ${i}
      <table class="idlog-table">
        <thead>
          <tr><th>Ver</th><th>Event</th><th>Device</th><th>Date</th><th>Fingerprint</th></tr>
        </thead>
        <tbody>
          ${n.events.map(o=>`
            <tr>
              <td>${o.version}</td>
              <td><span class="badge badge-${o.event_type==="rotation"?"warn":"info"}">${v(o.event_type)}</span></td>
              <td class="mono">${v(o.device_id)}</td>
              <td>${new Date(o.changed_at).toLocaleString()}</td>
              <td class="mono fingerprint">${v(o.identity_fingerprint_sha256)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `}catch(e){document.getElementById("idlog-body").innerHTML=xe("Could not load identity history",`We could not fetch the identity log: ${X(e)}`,{eyebrow:"Identity log",compact:!0})}}async function Ma(){if(He)try{const e=await J(),t=xn(e.userId,e.deviceId);t>Et&&(Et=t);const s=new j(p.serverUrl),n=Oo(e,Et),r=await s.sealedInbox(e.userId,Et,n);let a=Et,i=!1;for(const o of r.messages)try{const c=await Tc(e,o.message_bytes_base64,void 0,o.sender_identity_x25519_pub);if(c.kind==="ignored"){a=Math.max(a,o.message_id);continue}const d=c.senderUserId,l=c.plaintext,h=c.kind==="dm",u=h?null:c.recipient,f=h?Mn(e.userId,d):`group:${u}`;if((await ze(f)).some(x=>x.serverMessageId===o.message_id)){a=Math.max(a,o.message_id);continue}const w={id:`sealed-${o.message_id}`,conversationId:f,sender:d,recipient:h?e.userId:c.recipient,text:h?l:`${Pe(d).primaryLabel}: ${l}`,timestamp:new Date(o.received_at).getTime(),status:"delivered",serverMessageId:o.message_id};if(await Ys(w),Ts(d),h){const x=cn===d;if(Rc(d,l,!x),x){jt(e.userId,d);const _=document.getElementById("messages-list"),y=document.getElementById("messages-container");_&&y&&rn(_,w,y)}}else if(u){const x=ws===u;if(ti(u,d,l,!x),x){Yn(e.userId,u);const _=document.getElementById("messages-list"),y=document.getElementById("messages-container");_&&y&&rn(_,w,y)}}i=!0,a=Math.max(a,o.message_id)}catch{}a>Et&&(Et=a,Sn(e.userId,Et,e.deviceId)),i&&Oe()}catch{}}async function Br(e){if(!ue.some(t=>t.contact_user_id===e))try{const t=await J(),s=new j(p.serverUrl),n=Hr(t,e,"",!1,"");await s.upsertContact(t.userId,{contact_user_id:e},n),Wt(e),Es(),Ts(e)}catch{}}async function jv(){var i,o,c,d;const e=await Xe(),t=(e==null?void 0:e.contact_discovery_mode)??"manual_only",s=((i=e==null?void 0:e.contact_discovery_service_origin)==null?void 0:i.trim())??"";if(!(e!=null&&e.contact_discovery_supported)){const l=$s(e);it(`
      <section class="workspace-page-card">
        ${ot("Contact discovery","Use usernames and invite links first. Discovery stays secondary on web.",{eyebrow:"People",backButtonId:"disc-back",backButtonLabel:"Back to settings"})}
        <div class="settings-body">
          <div class="settings-section">
            <h3>Use instead</h3>
            <p class="settings-section-intro">This server keeps discovery off on web, so start with exact @usernames or private invite links.</p>
            <div class="settings-callout settings-callout-subtle">
              <strong>Discovery is unavailable on this server</strong>
              <p>${v(l.directMessagingAllowed?"Open Settings to copy your shareable @username, or start a chat with someone who already shared theirs.":"Open Settings to copy your shareable @username, then continue on the supported Android messaging path.")}</p>
            </div>
            <div class="settings-section-actions">
              <button id="disc-open-settings" class="btn-primary" type="button">Open settings</button>
              ${l.directMessagingAllowed?'<button id="disc-new-chat" class="btn-secondary" type="button">Start new chat</button>':'<button id="disc-back-to-inbox" class="btn-secondary" type="button">Back to inbox</button>'}
            </div>
          </div>
        </div>
      </section>
    `),g("#disc-back").addEventListener("click",()=>R({screen:"settings"})),(o=g("#disc-open-settings"))==null||o.addEventListener("click",()=>R({screen:"settings"})),(c=g("#disc-new-chat"))==null||c.addEventListener("click",()=>R({screen:"new-chat"})),(d=g("#disc-back-to-inbox"))==null||d.addEventListener("click",()=>R({screen:"conversations"}));return}const n=`
    <div class="settings-summary-grid settings-summary-grid-compact">
      <article class="settings-summary-card">
        <span class="settings-summary-kicker">Primary path</span>
        <strong>Usernames</strong>
        <span>and invite links</span>
        <p>Keep manual contacts as the default. Discovery stays secondary and advanced on web.</p>
      </article>
      <article class="settings-summary-card">
        <span class="settings-summary-kicker">Mode</span>
        <strong>${v(t==="private_service"?"Separate service":"Hash lookup")}</strong>
        <span>${v(t==="private_service"?"short-lived tickets":"manual hashes")}</span>
        <p>${v(t==="private_service"?"The app server issues tickets, while the separate service evaluates blinded handle material.":"Discovery is limited to raw-hash entry and manual lookup.")}</p>
      </article>
      <article class="settings-summary-card">
        <span class="settings-summary-kicker">Matches</span>
        <strong>${v(t==="private_service"?"Opaque invites":"Hash results")}</strong>
        <span>not contact profiles</span>
        <p>${v(t==="private_service"?"Matches return opaque invite bootstraps instead of stable account IDs.":"Any discovered handles still need manual confirmation and contact acceptance.")}</p>
      </article>
    </div>
  `,r=t==="private_service"?`
      <details class="settings-inline-details">
        <summary>Technical contract</summary>
        <div class="settings-inline-details-body">
          <div class="settings-row"><span>Service Origin</span><span class="mono">${v(s||"not configured")}</span></div>
          <div class="settings-row"><span>Backend</span><span>${v((e==null?void 0:e.contact_discovery_directory_backend)||"not advertised")}</span></div>
          <div class="settings-row"><span>Host Release</span><span class="mono">${v((e==null?void 0:e.contact_discovery_host_release_id)||"not advertised")}</span></div>
          <div class="settings-row"><span>Enclave Release</span><span class="mono">${v((e==null?void 0:e.contact_discovery_enclave_release_id)||"not advertised")}</span></div>
          <div class="settings-row"><span>Manifest Contract</span><span class="mono">${v((e==null?void 0:e.contact_discovery_expected_manifest_contract_sha256)||"not advertised")}</span></div>
          <div class="settings-row"><span>Attestation Verifier</span><span class="mono">${v((e==null?void 0:e.contact_discovery_attestation_verifier)||"not advertised")}</span></div>
        </div>
      </details>
    `:"";it(`
    <section class="workspace-page-card">
      ${ot("Contact discovery","Use usernames and invite links first. Open discovery only when you need the separate hashed-handle flow.",{eyebrow:"People",backButtonId:"disc-back",backButtonLabel:"Back to settings"})}
      <div class="settings-body">
        <div class="settings-callout">
          <strong>Use this only when someone already shared hashed handles with you.</strong>
          <p>Usernames and private invites stay faster and easier for everyday contact setup on web.</p>
        </div>
        <div class="settings-section">
          <h3>How it works</h3>
          <p class="settings-section-intro">This flow stays separate from your main contact list. Review the mode, then upload handles or search only when you need it.</p>
          ${n}
          ${r}
        </div>
        <div class="settings-section-grid">
          <section class="settings-section">
            <h3>Upload handles</h3>
            <p class="settings-section-intro">${t==="private_service"?"Upload SHA-256 phone or email hashes through the separate service using a short-lived ticket from the app server.":"Share hashed phone or email handles so existing contacts can look them up."}</p>
            <label class="field">
              <span>Phone hashes (one per line, SHA-256 hex)</span>
              <textarea id="disc-phones" rows="3" class="input-sm disc-textarea" placeholder="e.g. a1b2c3d4..."></textarea>
            </label>
            <label class="field">
              <span>Email hashes (one per line, SHA-256 hex)</span>
              <textarea id="disc-emails" rows="3" class="input-sm disc-textarea" placeholder="e.g. f5e6d7c8..."></textarea>
            </label>
            <button id="disc-upload" class="btn-sm">Upload handles</button>
            <div id="disc-upload-status" class="settings-status-note"></div>
          </section>
          <section class="settings-section">
            <h3>Find contacts</h3>
            <p class="settings-section-intro">${t==="private_service"?"Search with local hashes. Matching entries return opaque invite bundles instead of plain contact profiles.":"Enter hashes to check whether someone is registered on this server."}</p>
            <label class="field">
              <span>Query hashes (one per line, SHA-256 hex)</span>
              <textarea id="disc-query" rows="3" class="input-sm disc-textarea" placeholder="e.g. a1b2c3d4..."></textarea>
            </label>
            <button id="disc-match" class="btn-sm">Search</button>
            <div id="disc-results" class="settings-card-stack"></div>
          </section>
        </div>
      </div>
    </section>
  `),g("#disc-back").addEventListener("click",()=>R({screen:"settings"}));async function a(l,h,u){const f=up(h,u),m=await l.issueContactDiscoveryTicket(h.userId,f,{purpose:u}),w=s?pt(s).origin:null,x=pt(m.service_origin).origin;if(w&&w!==x)throw new Error("Contact discovery service origin mismatch");const _=await td(e);return{serviceOrigin:x,ticket:m.ticket,ticketNonce:m.ticket_nonce,manifest:_.manifest}}g("#disc-upload").addEventListener("click",async()=>{const l=document.getElementById("disc-upload-status"),h=g("#disc-phones").value.split(`
`).map(f=>f.trim()).filter(Boolean),u=g("#disc-emails").value.split(`
`).map(f=>f.trim()).filter(Boolean);if(h.length===0&&u.length===0){D("Enter at least one hash","error");return}try{const f=await J(),m=new j(p.serverUrl),{serviceOrigin:w,ticket:x,ticketNonce:_,manifest:y}=await a(m,f,"upload"),k=Sa(y),I=da(h),L=da(u),B=I.blindedElementsBase64.length===0?{ticket_nonce:_,manifest_contract_sha256:k,evaluation_proof_mode:y.evaluation_proof_mode,evaluated_elements_base64:[],dleq_proofs:[]}:await m.evaluateDiscoveryElementsAtService(w,{ticket:x,blinded_elements_base64:I.blindedElementsBase64}),$=L.blindedElementsBase64.length===0?{ticket_nonce:_,manifest_contract_sha256:k,evaluation_proof_mode:y.evaluation_proof_mode,evaluated_elements_base64:[],dleq_proofs:[]}:await m.evaluateDiscoveryElementsAtService(w,{ticket:x,blinded_elements_base64:L.blindedElementsBase64});mn(k,B.manifest_contract_sha256,"evaluate"),gn(_,B.ticket_nonce,"evaluate"),mn(k,$.manifest_contract_sha256,"evaluate"),gn(_,$.ticket_nonce,"evaluate"),ua(I.blindedElementsBase64,B,y.oprf_public_key_ristretto255),ua(L.blindedElementsBase64,$,y.oprf_public_key_ristretto255);const U=la(I.blindingScalarsBase64,B.evaluated_elements_base64),A=la(L.blindingScalarsBase64,$.evaluated_elements_base64),E=await m.uploadDiscoveryHandlesToService(w,{ticket:x,phone_tokens_sha256:U,email_tokens_sha256:A});mn(k,E.manifest_contract_sha256,"upload"),gn(_,E.ticket_nonce,"upload"),l.innerHTML=`<span class="text-success">Blind-evaluated and uploaded ${E.uploaded_phone_tokens} phone + ${E.uploaded_email_tokens} email tokens</span>`}catch(f){l.innerHTML=`<span class="text-danger">Upload failed: ${v(X(f))}</span>`}}),g("#disc-match").addEventListener("click",async()=>{const l=document.getElementById("disc-results"),h=g("#disc-query").value.split(`
`).map(u=>u.trim()).filter(Boolean);if(h.length===0){D("Enter at least one hash","error");return}l.innerHTML=xe("Searching discovery handles","Blind-evaluating your local hashes against the configured discovery service.",{eyebrow:"Discovery",compact:!0});try{const u=await J(),f=new j(p.serverUrl),{serviceOrigin:m,ticket:w,ticketNonce:x,manifest:_}=await a(f,u,"match"),y=Sa(_),k=da(h),I=await f.evaluateDiscoveryElementsAtService(m,{ticket:w,blinded_elements_base64:k.blindedElementsBase64});mn(y,I.manifest_contract_sha256,"evaluate"),gn(x,I.ticket_nonce,"evaluate"),ua(k.blindedElementsBase64,I,_.oprf_public_key_ristretto255);const L=la(k.blindingScalarsBase64,I.evaluated_elements_base64),B=new Map;L.forEach((U,A)=>{B.set(U,h[A])});const $=await f.matchDiscoveryHashesAtService(m,{ticket:w,tokens_sha256:L});if(mn(y,$.manifest_contract_sha256,"match"),gn(x,$.ticket_nonce,"match"),$.matches.length===0){l.innerHTML=xe("No matches found","No uploaded discovery handles matched the hashes you searched for.",{eyebrow:"Discovery",compact:!0});return}l.innerHTML=`
        <div class="utility-list">
          ${$.matches.map(U=>`
            <div class="utility-list-item">
              <div class="utility-list-body">
                <div class="utility-list-title">
                  <span class="mono">${v(B.get(U.token_sha256)||U.token_sha256)}</span>
                  <span class="utility-status-pill subtle">${v(U.handle_kind)}</span>
                </div>
                <div class="utility-list-meta">
                  <span class="mono">invite:${v(U.contact_invite_token.slice(-8))}</span>
                  <span>opaque bootstrap</span>
                </div>
                <p class="utility-list-note">Resolve this invite locally and add the discovered person to your saved contacts list on this browser.</p>
              </div>
              <div class="utility-list-actions">
                <button class="btn-sm" data-add-discovered="${v(U.contact_invite_token)}">Add</button>
              </div>
            </div>
          `).join("")}
        </div>
      `;for(const U of document.querySelectorAll("[data-add-discovered]"))U.addEventListener("click",async()=>{const A=U.dataset.addDiscovered;try{const G=(await f.getContactInviteBundle(A)).user_id.trim();await Br(G),D(`Added ${G} as contact`,"success"),U.disabled=!0,U.textContent="Added"}catch(E){D(`Could not resolve match bootstrap: ${X(E)}`,"error")}})}catch(u){l.innerHTML=xe("Discovery search failed",`We could not complete the search: ${X(u)}`,{eyebrow:"Discovery",compact:!0})}})}async function Wv(){it(`
    <section class="workspace-page-card">
      ${ot("Server","See what this connection supports on web right now.",{eyebrow:"Server",backButtonId:"sinfo-back",backButtonLabel:"Back to settings"})}
      <div class="settings-body" id="sinfo-body">
        ${xe("Loading server status","Checking this connection and the web features it currently publishes.",{eyebrow:"Server",compact:!0})}
      </div>
    </section>
  `),g("#sinfo-back").addEventListener("click",()=>R({screen:"settings"}));const e=document.getElementById("sinfo-body");try{const t=new j(p.serverUrl),[s,n]=await Promise.all([t.getHealth().catch(()=>null),t.getCapabilities().catch(()=>null)]);let r="";if(s||n){if(r+=`
        <div class="settings-card-stack">
          <div class="settings-overview-list">
            <article class="settings-overview-row">
              <div class="settings-overview-copy">
                <span class="settings-summary-kicker">Connection</span>
                <strong>${v(s?s.status==="ok"?"Healthy":s.status:"Unavailable")}</strong>
                <p>${v(s?`${s.security_profile} security profile with ${s.db_backend} storage.`:"The browser could not read a live health response from this server.")}</p>
              </div>
              <span class="settings-overview-meta">${v(s?s.deployment_mode:"no health response")}</span>
            </article>
            <article class="settings-overview-row">
              <div class="settings-overview-copy">
                <span class="settings-summary-kicker">Web access</span>
                <strong>${v((n==null?void 0:n.web_client_policy)||"unknown")}</strong>
                <p>${v(n?"This server decides how much of the messenger the web client can use.":"Capability policy is unavailable until the server advertises it.")}</p>
              </div>
              <span class="settings-overview-meta">${v((n==null?void 0:n.supported_beta_clients.join(", "))||"no beta clients advertised")}</span>
            </article>
            <article class="settings-overview-row">
              <div class="settings-overview-copy">
                <span class="settings-summary-kicker">Discovery</span>
                <strong>${v(n?n.contact_discovery_mode==="private_service"?"Separate service":n.contact_discovery_supported?"Manual lookup":"Disabled":"Unavailable")}</strong>
                <p>${v(n?"Discovery stays secondary on web. Use usernames and private invites first.":"The current server did not advertise discovery policy.")}</p>
              </div>
              <span class="settings-overview-meta">${v(n!=null&&n.contact_discovery_ticket_supported?"tickets available":"no discovery tickets")}</span>
            </article>
          </div>
      `,s&&(r+=`
          <details class="settings-inline-details">
            <summary>Connection snapshot</summary>
            <div class="settings-inline-details-body server-inline-details-body">
            <p class="settings-section-intro">A quick view of transport, storage, and server posture for this connection.</p>
            <div class="settings-kv-grid">
              <article class="settings-kv-card">
                <span class="settings-summary-kicker">Database</span>
                <strong>${v(s.db_backend)}</strong>
                <p>${s.db_ready?"Ready for requests.":"Not ready for requests."} Pool: ${s.db_pool_idle} idle / ${s.db_pool_size} total.</p>
              </article>
              <article class="settings-kv-card">
                <span class="settings-summary-kicker">Delivery</span>
                <strong>${v(s.realtime_mode)}</strong>
                <p>Push ${s.push_enabled?s.push_providers.join(", "):"disabled"} · TLS ${s.tls_enabled?"enabled":"disabled"}.</p>
              </article>
              <article class="settings-kv-card">
                <span class="settings-summary-kicker">Protection</span>
                <strong>${v(s.rate_limiter_mode)}</strong>
                <p>Replay cache ${s.replay_cache_mode} · registration proof-of-work ${s.registration_pow_bits} bits.</p>
              </article>
              <article class="settings-kv-card">
                <span class="settings-summary-kicker">Deployment</span>
                <strong>${v(s.security_profile)}</strong>
                <p>${v(s.deployment_mode)} deployment with ${s.status==="ok"?"healthy":"degraded"} status.</p>
              </article>
            </div>
            </div>
          </details>
        `),n){const a=n.runtime_crypto_profile,i=$s(n),o=i.directMessagingAllowed?i.groupMessagingAllowed?"Messaging on":"Direct messaging only":"Messaging blocked",c=i.directMessagingAllowed?i.groupMessagingAllowed?"Direct and private groups":"Private groups unavailable":"Demo-only web mode";r+=`
          <details class="settings-inline-details">
            <summary>What works on web</summary>
            <div class="settings-inline-details-body server-inline-details-body">
            <p class="settings-section-intro">These are the user-facing features and product boundaries this server currently publishes to the web client.</p>
            <div class="settings-status-grid">
              <article class="settings-status-card">
                <strong>${v(o)}</strong>
                <span>${v(c)}</span>
                <p>${v(i.detail)}</p>
              </article>
              <article class="settings-status-card">
                <strong>${n.contact_discovery_supported?"Discovery on":"Discovery off"}</strong>
                <span>${v(n.contact_discovery_mode==="private_service"?"Separate service":"Manual lookup")}</span>
                <p>Discovery remains secondary on web even when the server supports it.</p>
              </article>
              <article class="settings-status-card">
                <strong>${n.sealed_sender_required?"Sealed sender":"Sender visible"}</strong>
                <span>${n.sender_certificate_supported?"Certificates enabled":"Certificates disabled"}</span>
                <p>Sender protection and certificate policy shape message delivery behavior.</p>
              </article>
              <article class="settings-status-card">
                <strong>${n.presence_supported?"Presence on":"Presence off"}</strong>
                <span>${n.typing_indicators_supported?"Typing on":"Typing off"}</span>
                <p>Conversation awareness signals available to this browser client.</p>
              </article>
              <article class="settings-status-card">
                <strong>${n.read_receipts_supported?"Receipts on":"Receipts off"}</strong>
                <span>${n.ephemeral_messaging_supported?"Ephemeral DM on":"Ephemeral DM off"}</span>
                <p>Receipt and expiry features depend on the server’s beta policy.</p>
              </article>
              <article class="settings-status-card">
                <strong>${n.calling_supported?"Calling on":"Calling off"}</strong>
                <span>${n.channels_supported?"Channels on":"Channels off"}</span>
                <p>Calling and broadcast-style surfaces stay outside the supported web beta today.</p>
              </article>
            </div>
            </div>
          </details>
          <div class="settings-section">
            <h3>Crypto profile</h3>
            <p class="settings-section-intro">A short summary of the hybrid crypto runtime this server advertises for the current session.</p>
            <div class="settings-overview-list">
              <article class="settings-overview-row">
                <div class="settings-overview-copy">
                  <span class="settings-summary-kicker">Key exchange</span>
                  <strong class="mono">${v(a.kem)}</strong>
                  <p>Hybrid session setup for this browser connection.</p>
                </div>
                <span class="settings-overview-meta">KEM</span>
              </article>
              <article class="settings-overview-row">
                <div class="settings-overview-copy">
                  <span class="settings-summary-kicker">Transport</span>
                  <strong class="mono">${v(a.signature)} + ${v(a.aead)}</strong>
                  <p>Identity signatures paired with ${v(a.dh)} and ${v(a.kdf)} transport derivation.</p>
                </div>
                <span class="settings-overview-meta">signing + confidentiality</span>
              </article>
              <article class="settings-overview-row">
                <div class="settings-overview-copy">
                  <span class="settings-summary-kicker">Compliance</span>
                  <strong>${a.fips_mode?"FIPS mode":"Standard mode"}</strong>
                  <p>PQ OQS runtime ${a.pq_oqs_enabled?"enabled":"disabled"} for this server profile.</p>
                </div>
                <span class="settings-overview-meta">${a.pq_oqs_enabled?"PQ runtime on":"PQ runtime off"}</span>
              </article>
            </div>
          </div>
          <details class="settings-inline-details">
            <summary>Advanced details</summary>
            <div class="settings-inline-details-body">
              <div class="settings-row"><span>Schema</span><span>v${n.capability_schema_version}</span></div>
              <div class="settings-row"><span>Suites</span><span class="mono">${n.supported_suite_ids.join(", ")}</span></div>
              <div class="settings-row"><span>PQ Ratchet</span><span>${n.pq_ratchet_interval===1?"every message":`every ${n.pq_ratchet_interval} msgs`}</span></div>
              <div class="settings-row"><span>Stories</span><span>${n.stories_supported?"Enabled":"Disabled"}</span></div>
              <div class="settings-row"><span>Discovery Tickets</span><span>${n.contact_discovery_ticket_supported?"Available":"Unavailable"}</span></div>
              <div class="settings-row"><span>Discovery Ticket Issuer</span><span class="mono">${v(n.contact_discovery_ticket_issuer_ed25519_pub)}</span></div>
              <div class="settings-row"><span>Discovery Manifest Issuer</span><span class="mono">${v(n.contact_discovery_manifest_issuer_ed25519_pub||"not advertised")}</span></div>
              <div class="settings-row"><span>Discovery Backend</span><span>${v(n.contact_discovery_directory_backend||"not advertised")}</span></div>
              <div class="settings-row"><span>Host/Enclave Protocol</span><span>${v(n.contact_discovery_host_enclave_protocol_version?`${n.contact_discovery_host_enclave_protocol_version}`:"not advertised")}</span></div>
              <div class="settings-row"><span>Host Release</span><span class="mono">${v(n.contact_discovery_host_release_id||"not advertised")}</span></div>
              <div class="settings-row"><span>Enclave Release</span><span class="mono">${v(n.contact_discovery_enclave_release_id||"not advertised")}</span></div>
              <div class="settings-row"><span>Manifest Contract</span><span class="mono">${v(n.contact_discovery_expected_manifest_contract_sha256||"not advertised")}</span></div>
              <div class="settings-row"><span>Attestation Verifier</span><span class="mono">${v(n.contact_discovery_attestation_verifier||"not advertised")}</span></div>
              <div class="settings-row"><span>Expected Measurement</span><span class="mono">${v(n.contact_discovery_expected_measurement_hex||"not advertised")}</span></div>
              <div class="settings-row"><span>Attestation PCRs</span><span class="mono">${v(sd(n.contact_discovery_expected_pcrs_sha384))}</span></div>
              <div class="settings-row"><span>Attestation Max Age</span><span>${v(n.contact_discovery_attestation_max_age_seconds?`${n.contact_discovery_attestation_max_age_seconds}s`:"not advertised")}</span></div>
              <div class="settings-row"><span>Prod Baseline</span><span>${n.production_baseline_met?"Met":"Not met"}</span></div>
            </div>
          </details>
        `}r+="</div>"}!s&&!n&&(r=xe("Could not reach the server","Check your server URL, make sure the backend is running, and try again.",{eyebrow:"Server",compact:!0})),e.innerHTML=r}catch(t){e.innerHTML=xe("Server status failed",`We could not load server info: ${X(t)}`,{eyebrow:"Server",compact:!0})}}function di(){Ws&&(clearTimeout(Ws),Ws=null),mr&&(clearInterval(mr),mr=null),Cn&&(clearInterval(Cn),Cn=null)}function ad(){di(),En&&(clearInterval(En),En=null),$n&&(clearInterval($n),$n=null),An&&(clearInterval(An),An=null)}function Oe(){const e=Jn();if(e.screen==="conversations"){ni();return}id(e)}function Ot(){const e=Jn();e.screen==="conversations"?ni():e.screen==="chat"?On(e.peerId):e.screen==="group-chat"&&ed(e.groupId)}function Kv(e){return e.screen==="chat"?{kind:"dm",threadId:e.peerId}:e.screen==="group-chat"?{kind:"group",threadId:e.groupId}:null}function id(e=Jn()){const t=document.querySelector(".desktop-sidebar");if(!t||!p.userId)return;const{counts:s,visibleRows:n}=xs();t.outerHTML=Ss(n,s,Kv(e)),Is()}async function Fv(){const e=p.serverUrl,t=p.suiteLabel;Ct&&(Ct.disconnect(),Ct=null),ad(),He=null,cn=null,ws=null,ue=[],Je={},Dn={},Rn={},Xn={},bn=0,Et=0,Ee=null,Tn=null,At="all",sessionStorage.removeItem("pqmsg.passphrase"),p={...Ke,serverUrl:e,suiteLabel:t,peerUserId:""},Mt(p),R({screen:"onboarding"}),D("Logged out","info")}async function Vv(){try{const e=await J(),t=new j(p.serverUrl),s=ip(e),n=await t.getPrekeysStatus(e.userId,s),r=document.getElementById("prekey-status");if(!r)return;const a=n.low_one_time_prekeys?"prekey-low":"prekey-ok";r.innerHTML=`
      <div class="settings-row"><span>X25519 OTPs</span><span class="${a}">${n.remaining_one_time_prekeys_x25519}</span></div>
      <div class="settings-row"><span>ML-KEM-768 OTPs</span><span class="${a}">${n.remaining_one_time_prekeys_mlkem768}</span></div>
      <div class="settings-row"><span>Status</span><span class="${a}">${n.low_one_time_prekeys?"⚠️ Low — publish more":"✓ Healthy"}</span></div>
    `}catch(e){const t=document.getElementById("prekey-status");t&&(t.innerHTML=`<p class="error-text">Failed: ${v(X(e))}</p>`)}}function zr(e,t,s,n,r,a,i){const o=xt(p.userId,e);if(!o){Ki(p.userId,e,{fingerprintSha256:r,identityKeyVersion:a,identityX25519Pub:t,identitySigPub:s,identityPqSigPub:n,observedAt:i});return}if(o.fingerprintSha256===r)return;if(!confirm(`⚠️ Security Alert

${e}'s security key has changed.

This could mean they reinstalled the app, or someone may be intercepting your messages.

Do you trust the new key?`))throw new Error(`identity changed for ${e}; action blocked`);Ki(p.userId,e,{fingerprintSha256:r,identityKeyVersion:a,identityX25519Pub:t,identitySigPub:s,identityPqSigPub:n,observedAt:i})}async function li(e,t){var i;const s=xt(p.userId,e);if((i=s==null?void 0:s.identityPqSigPub)!=null&&i.trim())return s;const n=Rn[e]??await t.getBundle(e),r=n.identity_fingerprint_sha256||Cs(n.identity_x25519_pub,n.identity_pq_sig_pub);zr(e,n.identity_x25519_pub,n.identity_sig_pub,n.identity_pq_sig_pub,r,n.identity_key_version,n.bundle_generated_at);const a=xt(p.userId,e);if(!a)throw new Error(`Unable to pin identity for ${e}`);return a}async function zv(e){var l,h;await Ft();const t=await J(),s=new j(p.serverUrl),n=await li(e,s);if(!n.identityPqSigPub.trim())throw new Error("Peer PQ identity key is unavailable for safety-number verification.");const r=Ko(t,e,n.identityX25519Pub,n.identityPqSigPub),a=ue.find(u=>u.contact_user_id===e),i=((l=a==null?void 0:a.alias)==null?void 0:l.trim())||((h=Je[e])==null?void 0:h.trim())||e,o=ei(a,n);if(!(o||confirm(`Safety number for ${i}

${r}

Mark this contact as verified against the current fingerprint?`))){D("Safety-number verification canceled","info");return}if(!o){const u=Hr(t,e,(a==null?void 0:a.alias)||"",!0,n.fingerprintSha256);await s.upsertContact(t.userId,{contact_user_id:e,alias:(a==null?void 0:a.alias)||void 0,verified_by_qr:!0,verified_fingerprint_sha256:n.fingerprintSha256},u);const f=new Date().toISOString();Zh({contact_user_id:e,username:(a==null?void 0:a.username)||null,alias:(a==null?void 0:a.alias)||null,verified_by_qr:!0,verified_fingerprint_sha256:n.fingerprintSha256,created_at:(a==null?void 0:a.created_at)||f,updated_at:f}),Wt(e),Es()}D(o?"Safety number matches the saved verification":"Contact verified via safety number","success");const d=Jn();d.screen==="chat"&&d.peerId===e&&On(e)}async function J(){if(He)return He;const e=dn();return He=await tc(p.userId,e),He}function dn(){const e=sessionStorage.getItem("pqmsg.passphrase");if(e)return e;const t=prompt("Enter your passphrase to unlock your keys:");if(!t)throw new Error("Passphrase required");return sessionStorage.setItem("pqmsg.passphrase",t),t}function Mn(e,t){return[e,t].sort().join(":")}function Ur(e){requestAnimationFrame(()=>{e.scrollTop=e.scrollHeight})}function Nt(e,t){const s=e.querySelector(".progress-fill");s&&(s.style.width=`${t}%`)}function Yv(e){const t=Date.now()-e;return t<6e4?"now":t<36e5?`${Math.floor(t/6e4)}m`:t<864e5?new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):t<1728e5?"yesterday":t<6048e5?new Date(e).toLocaleDateString([],{weekday:"short"}):new Date(e).toLocaleDateString([],{month:"short",day:"numeric"})}function od(e){const t=new Date().toLocaleDateString(),s=new Date(Date.now()-864e5).toLocaleDateString(),n=new Date(e).toLocaleDateString();return n===t?"Today":n===s?"Yesterday":new Date(e).toLocaleDateString([],{weekday:"long",month:"long",day:"numeric"})}function ui(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(1)} MB`}function fs(e){return e.startsWith("image/")?"Photo":e.startsWith("video/")?"Video":e.startsWith("audio/")?"Audio":e==="application/pdf"?"PDF":"Document"}function g(e){const t=document.querySelector(e);if(!t)throw new Error(`missing element: ${e}`);return t}function ao(e){return Array.from(document.querySelectorAll(e))}function v(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function X(e){return e instanceof Error?e.message:String(e)}function Ba(e){return e.includes("x-pqmsg-auth-signature verification failed")}function Jv(e){return e.includes("immutable identity")}function tr(e){return(e==null?void 0:e.security_profile)==="research"&&(e==null?void 0:e.deployment_mode)==="development"}async function Ua(e,t,s){await e.registerUser({user_id:t.userId,identity_x25519_pub:t.identityX25519Pub,identity_sig_pub:t.identitySigPub,identity_pq_sig_pub:t.identityPqSigPub,device_id:t.deviceId});const n=Ro(t),r=No(t,n);await e.publishPrekeys(t.userId,n,r);try{const a=Wa(t,s,"",!1,"","");await e.upsertProfile(t.userId,{display_name:s,username_lookup_enabled:!1},a)}catch{D("Your account is ready, but the display name could not be synced yet.","info")}}async function cd(e,t,s){const n=await Xe();if(!tr(n))throw new Error("This relay does not allow same-username repair.");await Ft();const r=new j(p.serverUrl),a=hp(e);return await r.resetDevUserIdentity(e.userId),ic(e.userId,0,e.deviceId),Sn(e.userId,0,e.deviceId),Et=0,await Ua(r,a,t),await Gr(e.userId,s,a),sessionStorage.setItem("pqmsg.passphrase",s),He=a,p={...p,userId:a.userId,deviceId:a.deviceId,suiteLabel:a.suite,displayName:t},Mt(p),Je[a.userId]=t,on(a.userId,a.userId,t),a}function qa(e){return tr(Ee)?`Saved local keys for @${e} do not match the server record. Use Repair saved keys to reset the development-relay record for @${e} and re-publish the keys already saved in this browser.`:`Saved local keys for @${e} do not match the server record. This usually happens after an earlier failed registration left stale browser keys behind. Use Forget profile next to @${e} on the sign-in screen, then create the account again.`}function dd(e){const t=new Uint8Array(e);let s="";for(let n=0;n<t.byteLength;n++)s+=String.fromCharCode(t[n]);return btoa(s)}if("serviceWorker"in navigator){const e=Jo(),t=Yo(location),s=location.protocol==="http:"&&Or(location.hostname);!t||e||(s?navigator.serviceWorker.getRegistrations().then(n=>Promise.all(n.map(r=>r.unregister()))).catch(()=>{}):navigator.serviceWorker.register("/sw.js").catch(()=>{}))}
